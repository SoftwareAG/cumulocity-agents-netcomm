name "cumulocity-test-singlenode"

description "Single Node Installation"
