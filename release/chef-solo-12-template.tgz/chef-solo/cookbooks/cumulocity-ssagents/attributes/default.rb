# List of installed microservices
default['cumulocity-ssagents']['scriptDir'] = "/tmp"
default["cumulocity-ssagents"]["agent_daemon_list"]=[]
default["cumulocity-ssagents"]["useTags"]=true

# Default credentials for system users:
default["cumulocity-ssagents"]["devicebootstrap"]["tenant"]="management"
default["cumulocity-ssagents"]["devicebootstrap"]["username"]="devicebootstrap"
default["cumulocity-ssagents"]["devicebootstrap"]["password"]="Fhdt1bb1f"

default["cumulocity-ssagents"]["servicebootstrap"]["tenant"]="management"
default["cumulocity-ssagents"]["servicebootstrap"]["username"]="servicebootstrap"
default["cumulocity-ssagents"]["servicebootstrap"]["password"]="!j5iBT0GE7,a73s2;4q51h_52m&6%#"

default["cumulocity-ssagents"]["mailerreport"]["tenant"]="management"
default["cumulocity-ssagents"]["mailerreport"]["username"]="sysreader"
default["cumulocity-ssagents"]["mailerreport"]["password"]="uncytCiWoaw6"

# Old style mapping
# Agent map as fix for non-standardized ssagents:
default["cumulocity-ssagents"]["agent_map"] = [
    # { "name" => "tracker", "link" => "tracker-agent" },
    # { "name" => "smartrule", "link" => "smartrule-esper" },
    # { "name" => "agent-name", "link" => "the-proper-dir"}
]

# Old style mapping
# Config file map as fix for non-standardized ssagents:
default["cumulocity-ssagents"]["config_map"] = [
    # { "name" => "cumulocity-report-mailer", "link" => "cumulocity-report-mailer.json" },
    # { "name" => "mapcluster", "link" => "map-cluster-agent-server.properties" },
    # { "name" => "agent-name", "link" => "config-file-name.ext"}
]

# Agent map as fix for non-standardized ssagents:
# Example usage:
# for agents in version 9.4+
# default['cumulocity-ssagents']['ss_agent_map'] = {
#     'smartrule-agent-server-esper' => { 'agent_name' => 'smartrule', 'config_directory' => 'smartrule-esper', 'config_file' => 'smartrule-agent-server-esper.properties' },
#     'device-simulator-agent-server' => { 'agent_name' => 'device-simulator'}
# }

# Extra settings for some ssagents:
default["cumulocity-ssagents"]["mqtt"]["mysql_conn"]="jdbc:mysql://localhost:3306/mqtt?useSSL=false"
default["cumulocity-ssagents"]["mqtt"]["mysql_username"]="root"
default["cumulocity-ssagents"]["mqtt"]["mysql_password"]="cumulus"
default["cumulocity-ssagents"]["push"]["provider"]="https://tpns-preprod.molutions.de/TPNS/"
default["cumulocity-ssagents"]["sslmanagement"]["password"]="756064302374265f"
default["cumulocity-ssagents"]["sslmanagement"]["salt"]="7340643d3d376c6b"
default["cumulocity-ssagents"]["sslmanagement"]['activation']["useHttps"]="true"
default["cumulocity-ssagents"]["sslmanagement"]["disableSSLValidation"]="true"
default["cumulocity-ssagents"]["device-simulator"]["platform.bootstrap.agent.delay"]="120000"

#LWM2M Settings
default["cumulocity-ssagents"]["lwm2m-agent"]["port_bootstrapCoap"]=5683
default["cumulocity-ssagents"]["lwm2m-agent"]["port_bootstrapCoapS"]=5684
default["cumulocity-ssagents"]["lwm2m-agent"]['port_lwm2mCoap']=5783
default["cumulocity-ssagents"]["lwm2m-agent"]["port_lwm2mCoapS"]=5784
default["cumulocity-ssagents"]["lwm2m-agent"]["port_fwUpdateHTTP"]=8773
default["cumulocity-ssagents"]["lwm2m-agent"]["port_fwUpdateHTTPS"]=8774

default["cumulocity-ssagents"]["lwm2m-agent"]["host_fwUpdate"]="lwm2m.cumulocity.com"
default["cumulocity-ssagents"]["lwm2m-agent"]["leshan_cluster_tenant"] = ""
default["cumulocity-ssagents"]["lwm2m-agent"]["leshan_cluster_tenant_username"] = ""
default["cumulocity-ssagents"]["lwm2m-agent"]["leshan_cluster_tenant_password"] = ""

default["cumulocity-ssagents"]["lwm2m-agent"]["subscriptions_fetch_delay"]=3600000
default["cumulocity-ssagents"]["lwm2m-agent"]["device-tenant_mapping_reload_delay"]=900000
default["cumulocity-ssagents"]["lwm2m-agent"]["C8Y_lwm2mEventLoggingEnabled"]=false
