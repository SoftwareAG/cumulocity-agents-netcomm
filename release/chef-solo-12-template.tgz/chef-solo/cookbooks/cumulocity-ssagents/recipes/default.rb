#
# Cookbook Name:: cumulocity-ssagents
# Recipe:: default
#
# Copyright 2017, Cumulocity GmbH
#
# All rights reserved - Do Not Redistribute
#

include_recipe "yum"

yum_repository 'cumulocity' do
  description 'cumulocity Repository'
  baseurl node['yum']['repositories']['cumulocity']['url']
  gpgcheck false
  enabled true
  action :create
end

package "redhat-lsb-core"
extra_params = nil

if node["cumulocity-ssagents"]["useTags"]
    agent_daemons = node.tags
else
    agent_daemons = node["cumulocity-ssagents"]["agent_daemon_list"]
end

OnTopLBNodes = []
OnTopLBList = ""
if agent_daemons.include?("ssl-management-agent-server")
    OnTopLBNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-ontop-lb")
    OnTopLBList = OnTopLBNodes.collect{|x| x['ipaddress']}.sort.join(',')
end

agent_daemons.each do |agent_daemon| if ["-server", "-agent", "-mailer"].any? { |x| agent_daemon.include?(x) }
    agent_daemon.downcase!

        ss_agent agent_daemon do
            script_dir node['cumulocity-ssagents']['scriptDir']
            on_top_lb_list OnTopLBList
            agent_map lazy { node["cumulocity-ssagents"]["agent_map"] }
            version node['cumulocity-karaf']['ssa-version']
            action :install
        end
    end
end

# agent_daemons.each do |agent_daemon| if ["-server", "-agent", "-mailer"].any? { |x| agent_daemon.include?(x) }
#     agent_daemon.downcase!

#     agent_name = agent_daemon.split("-server").first.split("-agent").first
#     if agent_link = node["cumulocity-ssagents"]["agent_map"].find { |name| name['name'] == agent_name }
# 	agent_name_with_link = agent_link['link']
#     else
# 	agent_name_with_link = agent_name
#     end

#     service "start_daemon"  do
#         service_name agent_name_with_link
#         action [ :start ]
#         Chef::Log.info("Started daemon: #{agent_name_with_link}")
#     end
    

# end
# end

