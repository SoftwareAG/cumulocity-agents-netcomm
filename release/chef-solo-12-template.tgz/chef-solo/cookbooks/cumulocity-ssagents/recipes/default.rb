#
# Cookbook Name:: cumulocity-ssagents
# Recipe:: default
#
# Copyright 2017, Cumulocity GmbH
#
# All rights reserved - Do Not Redistribute
#

include_recipe "yum"

yum_repository 'cumulocity' do
  description 'cumulocity Repository'
  baseurl node['yum']['repositories']['cumulocity']['url']
  gpgcheck false
  enabled true
  action :create
end

package "redhat-lsb-core"
extra_params = nil

if node["cumulocity-ssagents"]["useTags"]
    agent_daemons = node.tags
else
    agent_daemons = node["cumulocity-ssagents"]["agent_daemon_list"]
end

OnTopLBNodes = []
OnTopLBList = ""

if agent_daemons.include?("ssl-management-agent-server")
    OnTopLBNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-ontop-lb")
    OnTopLBList = OnTopLBNodes.collect{|x| x['ipaddress']}.sort.join(',')
end

node['cumulocity-ssagents']['agent_map'].each do |agent|
    node.default['cumulocity-ssagents']['ss_agent_map'][agent['name']]['agent_name'] = agent['link']
end

node['cumulocity-ssagents']['config_map'].each do |agent|
    node.default['cumulocity-ssagents']['ss_agent_map'][agent['name']]['config_file'] = agent['link']
end

agent_daemons.each do |agent_daemon| if ["-server", "-agent", "-mailer"].any? { |x| agent_daemon.include?(x) }
    agent_daemon.downcase!

        ss_agent agent_daemon do
            script_dir node['cumulocity-ssagents']['scriptDir']
            on_top_lb_list OnTopLBList
            agent_map lazy { node["cumulocity-ssagents"]["ss_agent_map"] }
            version node['cumulocity-karaf']['ssa-version']
            action :install
        end
    end
end