name             "cumulocity-ssagents"
maintainer       "NSN"
maintainer_email "developers@telcoassetmarketplace.com"
license          "All rights reserved"
description      "Installs/Configures Cumulocity Agents"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.4.0"

