module CumulocitySSAgent
    class SSAgent < Chef::Resource
        resource_name :ss_agent
        provides :ss_agent
        
        property :name, kind_of: String, name_property: true
        property :agent_map, kind_of: Array, required: false, default: nil
        property :script_dir, kind_of: String, required: false, default: '/tmp'
        property :version, kind_of: String, required: false, default: nil
        property :on_top_lb_list, kind_of: String, required: false, default: nil

        action :install do
            
            Chef::Log.info("Agent name #{agent_name}")

            template "#{new_resource.script_dir}/restart_daemon.sh" do
                source "restart.sh.erb"
                mode "0700"
                variables(
                    :agent_daemon => agent_name
                )
            end

            yum_package agent_name  do
                version new_resource.version unless new_resource.version.nil?
                ignore_failure true
                allow_downgrade true
                action :install
                notifies :run, 'execute[restart_daemon_after_update]', :immediate
            end

            cookbook_file "/etc/#{config_directory}/#{new_resource.name}-logging.xml" do
                source "#{agent_name}/#{new_resource.name}-logging.xml"
                owner 'root'
                group 'root'
                mode '0640'
                ignore_failure true
            end

            template "/etc/#{config_directory}/#{config_file}" do
                source "#{agent_name}/#{config_file}.erb"
                owner 'root'
                group 'root'
                mode '0640'
                variables(
                    :agent_name_with_link => config_directory,
                    :OnTopLBList => new_resource.on_top_lb_list
                )
                ignore_failure true
                notifies :run, 'execute[restart_daemon_after_update]', :immediate
            end

            execute 'restart_daemon_after_update' do
                command "#{new_resource.script_dir}/restart_daemon.sh"
                Chef::Log.info("Restarted daemon: #{agent_name}")
                action :nothing
                user 'root'
            end

            service agent_name do
                action :start
                Chef::Log.info("Started daemon: #{agent_name}")
            end
            
        end

        def agent_name
            value = map_value('agent_name') 

            if value.nil?
                return name
            else
                return value
            end
        end

        def config_file
            value = map_value('config_file') 
            
            if value.nil?
                return "#{name}.properties"
            else
                return value
            end
        end

        def config_directory
            value = map_value('config_directory') 
            
            if value.nil?
                return agent_name
            else
                return value
            end
        end

        def map_value(key) 
            if agent_map.nil?
                Chef::Log.info("Agent map is empty")

                return nil
            end

            map = agent_map.find { |v| v['name'] == name }

            if map.nil?
                Chef::Log.info("Agent map is not empty but does not contain value for #{name}")
                return nil
            end

            Chef::Log.info("New agent name is #{map[key]}")

            return map[key]
        end
    end
end