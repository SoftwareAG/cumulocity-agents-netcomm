#
# Cookbook Name:: cumulocity-rsyslog
# Recipe:: default
#
# Copyright 2013, NSN
#
# All rights reserved - Do Not Redistribute
#

if !node.roles.include?('cumulocity-syslog-ng-monitoring-part')

    service 'auditd' do
        action [:enable, :start]
    end

    file '/etc/audisp/plugins.d/syslog.conf' do
        content '# This file controls the configuration of the syslog plugin.
# It simply takes events and writes them to syslog. The
# arguments provided can be the default priority that you
# want the events written with. And optionally, you can give
# a second argument indicating the facility that you want events
# logged to. Valid options are LOG_LOCAL0 through 7, LOG_AUTH,
# LOG_AUTHPRIV, LOG_DAEMON, LOG_SYSLOG, and LOG_USER.

active = yes
direction = out
path = builtin_syslog
type = builtin
args = LOG_INFO LOG_LOCAL6
format = string'
        mode '0640'
        owner 'root'
        group 'root'
        notifies :reload, 'service[auditd]'
    end

    service "rsyslog" do
        action :enable
    end

    package "rsyslog-gnutls" do
        action :install
    end

    if node['cumulocity-rsyslog']['cross-env-log-server'].nil?
        chef_env_log_server = node.chef_environment
    else
        chef_env_log_server = node['cumulocity-rsyslog']['cross-env-log-server']
    end

    log_server=search(:node, "chef_environment:#{chef_env_log_server} AND role:#{node['cumulocity-rsyslog']['log-server-role']}")
    log_server_ip = nil

    if log_server.length > 0 || !node['cumulocity-rsyslog']['log-server-ext-address'].nil?

        if node['cumulocity-rsyslog']['log-server-ext-address'].nil?
    	log_server_ip = log_server.first['ipaddress']
        else
    	log_server_ip = node['cumulocity-rsyslog']['log-server-ext-address']
        end

        cookbook_file node['cumulocity-rsyslog']['CAfile'] do
	  action :create
	  mode '0644'
          owner 'root'
          group 'root'
	  source 'gd_bundle.crt'
        end
    end

    template "/etc/rsyslog.conf" do
      source "rsyslog.conf.erb"
      owner "root"
      group "root"
      mode "0640"
      variables(:log_server_ip => log_server_ip)
      notifies :restart, "service[rsyslog]"
    end

end


