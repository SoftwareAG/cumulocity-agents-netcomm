default['cumulocity-rsyslog']['CAfile']="/etc/pki/tls/certs/gd_bundle.crt"
default['cumulocity-rsyslog']['log-server-role']="cumulocity-syslog-ng-forwarder"
default['cumulocity-rsyslog']['cross-env-log-server']=nil
default['cumulocity-rsyslog']['log-server-ext-address']=nil

default['cumulocity-rsyslog']['log-sms-gateway'] = false

default['cumulocity-rsyslog']['forward-on-tcp'] = true
default['cumulocity-rsyslog']['forward-on-port'] = "5514"
default['cumulocity-rsyslog']['forward-to-graylog'] = false
