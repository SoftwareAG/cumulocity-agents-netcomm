# cumulocity CHANGELOG

## 9.0.16 for release pack
- [Lukasz Pospiech] - add mqtt port to k8s external service
- [Luca Fuso]       - made mongod limits configurable for startup scripts plus cleanup of unused template
- [Jacek Rzeznik]   - Improvements: Disabling SELinux (no more restarts); Upload docker images only if k8s.conf exists
- [Jacek Rzeznik]   - Prevent NGinx/OpenResty from restarting if there is no cores in cumulocity-mn-active-core role
- [Jacek Rzeznik]   - Add gcc as a default package to install

## 9.8.3 for release pack
- [Jacek Rzeznik]   - MTM-12930: Include more headers in access-control-allow-headers (proxy.conf)
- [Jacek Rzeznik]   - MTM-21511: NGinx should not stop when ssl microservice runs out of memory (dynSSLcerts.lua)

## 9.12.2 for release pack
- [Jacek Rzeznik]   - MTM-21400: As Cumulocity customer, I want to use a supported version of MongoDB (3.6)
- [Jacek Rzeznik]   - Change the log level for limit.lua
