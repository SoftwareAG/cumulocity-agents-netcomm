override['cumulocity-karaf']['properties-filenames'] = ["cumulocity-core.properties"]
override['cumulocity-karaf']['package-name'] = "cumulocity-core-karaf"

#default['cumulocity-core']['properties']['contextService.rdbmsPassword'] = ""
default['cumulocity-core']['properties']['mongodb.user'] = ""
#default['cumulocity-core']['properties']['mongodb.password'] = ""
default['cumulocity-core']['properties']['mongodb.admindb'] = "admin"

default['cumulocity-core']['properties']['couchClient.poolMaxSize'] = "500"
default['cumulocity-core']['properties']['couchClient.poolMinIdle'] = "200"
default['cumulocity-core']['properties']['couchClient.poolMaxIdle'] = "300"

default['cumulocity-core']['properties']['rdbmsClient.poolMaxIdle'] = "200"
default['cumulocity-core']['properties']['rdbmsClient.poolMaxActive'] = "200"
default['cumulocity-core']['properties']['rdbmsClient.poolMaxWait'] = "10000"

default['cumulocity-core']['properties']['dbinit.enabled'] = "false"

default['cumulocity-core']['properties']['userCache.enabled'] = "true"
default['cumulocity-core']['properties']['tenantCache.timeToIdleSeconds'] = "1"
default['cumulocity-core']['properties']['tenantCache.timeToLiveSeconds'] = "1"
default['cumulocity-core']['properties']['userCache.timeToIdleSeconds'] = "1"
default['cumulocity-core']['properties']['userCache.timeToLiveSeconds'] = "1"
default['cumulocity-core']['properties']['email.protocol']="smtp"
default['cumulocity-core']['properties']['email.host']="localhost"
default['cumulocity-core']['properties']['email.port']="25"
default['cumulocity-core']['properties']['email.username']=""
default['cumulocity-core']['properties']['email.password']=""
default['cumulocity-core']['properties']['email.from']="support@cumulocity.com"
default['cumulocity-core']['properties']['cumulocity.environment']="DEVELOPMENT"
default['cumulocity-core']['properties']['default.tenant.applications']="administration,devicemanagement,cockpit,feature-microservice-hosting,feature-cep-custom-rules"

#default['cumulocity-core']['properties']['paypal.client.address']="https://api.sandbox.paypal.com"
#default['cumulocity-core']['properties']['paypal.client.tokenService']="${paypal.client.address}/v1/identity/openidconnect/tokenservice"

default['cumulocity-core']['properties']['paypal.client.address']="http://localhost:8083"
default['cumulocity-core']['properties']['paypal.client.tokenService']="${paypal.client.address}/webapps/auth/protocol/openidconnect/v1/tokenservice"
default['cumulocity-core']['properties']['paypal.client.id']="AZ76HhA83EVxnszAm0pkAnWaj1UhabcH-YVmeZWyTIg-AH4kHfpmS-rfn7wl"
default['cumulocity-core']['properties']['paypal.client.secret']="EJnzUhDdTybz6_TPA9szWCR-QKu0lm_yWD-CLmP7AH2KYa2SrD14WmxJ9RRi"

#default['cumulocity-cep']['properties']['contextService.rdbmsPassword'] = ""

default['cumulocity-cep']['package_name'] = "cumulocity-cep-server"

default['cumulocity-core']['properties']['smart.host']="127.0.0.1"
default['cumulocity-core']['properties']['smart.port']="8181"

default['cumulocity-core']['properties']['simulator.host']="127.0.0.1"
default['cumulocity-core']['properties']['simulator.port']="8181"

default['cumulocity-core']['properties']['cepServer.baseURL']="127.0.0.1:8989"
default['cumulocity-core']['properties']['cepServer.login']="cep"
default['cumulocity-core']['properties']['cepServer.password']="Toymr1fds"
default['cumulocity-core']['properties']['cepServer.tenants']=""

default['cumulocity-core']['properties']['passwordReset.sendNotificationToUnknownEmails']="true"
default['cumulocity-core']['properties']['auth.checkBlockingFromOutside']="false"
default['cumulocity-core']['properties']['smsGateway.host']="http://127.0.0.1:8688/sms-gateway"

default['cumulocity-core']['properties']['system.password.enforce.strength']="false"
default['cumulocity-core']['properties']['system.plugin.eventprocessing.enabled']="true"
default['cumulocity-core']['properties']['speechAgent.baseURL']="127.0.0.1:8030"

default['cumulocity-core']['properties']['management.admin.password']="b7596fe7ffdf9bf476d0dfb947090a56e4d5009bf7bd790abf8d658859966304"
default['cumulocity-core']['properties']['admin.password']="5096543b42e7e9e30f6ce66ce63f601658705692f11602cafa6d470a5ac2d673"
default['cumulocity-core']['properties']['sysadmin.password']="f583317686078173618779b01c5c143028328116222da6a9deab6db2ce208ac4"
default['cumulocity-core']['properties']['sendDashboardAgent.url']="http://localhost:19191"
default['cumulocity-core']['properties']['unpackApplicationsDir']="/webapps"
default['cumulocity-core']['properties']['system.reportMailer.available']="false"
