default['yum']['repositories']['mongodb']['url'] = "https://repo.mongodb.org/yum/redhat/$releasever/mongodb-org/#{node["cumulocity-mongo"]["version"]}/x86_64/"
default['yum']['repositories']['mongodb']['gpgkey'] = "https://www.mongodb.org/static/pgp/server-#{node["cumulocity-mongo"]["version"]}.asc"

default["cumulocity-mongo"]["installEnterprise"] = false

default['cumulocity-mongo']['mongodb.initUser'] = ""
default['cumulocity-mongo']['mongodb.initPassword'] = ""

default['cumulocity-mongo']['sharedkey-file'] = "/etc/mongo/shared-keyfile"
default['cumulocity-mongo']['sharedkey-content'] = ""

default['cumulocity-mongo']['members-check'] = true
default['cumulocity-mongo']['total-members'] = 3

default['cumulocity-mongo']['status-dir'] = "/var/run/mongodb/status"

default['cumulocity-mongo']['wiredtiger-cache'] = nil

default['cumulocity-mongo']['initRunUser'] = 'root'
default['cumulocity-mongo']['initRunGroup'] = 'root'
