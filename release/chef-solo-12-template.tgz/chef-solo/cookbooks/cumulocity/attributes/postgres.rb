default['cumulocity-postgres']['max_connections'] = "1000"
default['cumulocity-postgres']['c8ydbadmin.password'] = ""
default['cumulocity-postgres']['c8ymonitoring.password'] = ""

default['cumulocity-postgres']['isMasterHotStandby'] = false

if node['el7']
  default['cumulocity-postgres']['version'] = '9.3'
  default['yum']['repositories']['postgres']['url'] = "http://yum.postgresql.org/9.3/redhat/rhel-$releasever-$basearch"
else
  default['cumulocity-postgres']['version'] = '9.1'
  default['yum']['repositories']['postgres']['url'] = "http://yum.postgresql.org/9.1/redhat/rhel-$releasever-$basearch"
end

default['cumulocity-postgres']['failover_log'] = '/var/log/pg_failover.log'
default['cumulocity-postgres']['conf_dir'] = '/var/lib/pgsql'
default['cumulocity-postgres']['data_directory'] = "#{node['cumulocity-postgres']['conf_dir']}/#{node['cumulocity-postgres']['version']}/data"
default['cumulocity-postgres']['master_copy'] = "#{node['cumulocity-postgres']['conf_dir']}/#{node['cumulocity-postgres']['version']}"

default['cumulocity-postgres']['max_wal_senders'] = 5
default['cumulocity-postgres']['wal_keep_segments'] = 16
default['cumulocity-postgres']['replicator.password'] = ""

default['cumulocity-postgres']['extraHostsAccess'] = []
