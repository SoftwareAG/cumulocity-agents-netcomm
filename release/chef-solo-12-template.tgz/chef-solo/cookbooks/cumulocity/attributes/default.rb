default['java']['jdk_version'] = '8'
default["cumulocity-mongo"]["version"] = "3.2"

default['cumulocity-base']['configureHostsFile'] = nil

default['fixhostname'] = nil
default['fixhostsfile'] = nil

default['swapfilename'] = "/swapfile1"
default['swapfilesize'] = 1024

if node[:platform_version].split('.').first == '7'
  default['el7'] = true
else
  default['el7'] = false
end

if Chef::Config[:solo]
  default['useVaults'] = false
  default['useTenantId'] = true
else
  default['useVaults'] = true
  default['useTenantId'] = false
end

default['systemd']['ulimits'] = nil