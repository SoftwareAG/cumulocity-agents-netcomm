default['cumulocity-karaf']['version'] = nil
default['environment']['address'] = "localhost:8181"

default['cumulocity-karaf']['properties-filenames'] = []
default['cumulocity-karaf']['package-name'] = "cumulocity-base-karaf"


default['cumulocity-karaf']['karaf']['memory']['xms'] = nil
default['cumulocity-karaf']['karaf']['memory']['min_perm_gen'] = "16M"
default['cumulocity-karaf']['karaf']['memory']['max_perm_gen'] = "512M"

default['cumulocity-karaf']['memory_left_for_system'] = "4096"

default['cumulocity-application']['vendme'] = nil

default['cumulocity-karaf']['notification'] = false
default['cumulocity-karaf']['myhostname'] = "myhostname"
default['cumulocity-karaf']['mydomain'] = "mydomain"

default['cumulocity-karaf']['oort-enabled'] = nil
default['cumulocity-karaf']['cep-server-enabled'] = nil

default['cumulocity-karaf']['openrelayIP'] = nil
default['cumulocity-karaf']['openrelayPORT'] = "25"
default['cumulocity-karaf']['revDNSname'] = nil

default['cumulocity-karaf']['DisableUsageStatistics'] = false
default['cumulocity-karaf']['CUMULOCITY_LICENCE_DIR'] = nil
default['cumulocity-karaf']['CUMULOCITY_LICENCE_KEY'] = nil

default['postfix']['smtp_sasl_security_options'] = "noanonymous"
default['postfix']['smtp_sasl_auth_enable'] = false
default['postfix']['smtp_relay_username'] = nil
default['postfix']['smtp_relay_password'] = nil

default['agent_server_list'] = []
default['cumulocity-ssagents']['ssAgentsIP']="127.0.0.1"
default['cumulocity-ssagents']['k8sAgentsIP']="127.0.0.1"

default['cumulocity-GUI']['version'] = nil
default['cumulocity-GUI']['connString'] = "https://${RESCREDENTIALS}@resources.cumulocity.com/targets/${TARGET}/${HASH}"

#default['cumulocity-kubernetes']['images-version'] = nil
#default['cumulocity-kubernetes']['images-connString'] = "https://${RESCREDENTIALS}@resources.cumulocity.com/kubernetes-images"
