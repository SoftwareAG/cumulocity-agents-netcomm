#!/bin/bash
# Security checklist for PostgreSQL
PSQLDIR=/var/lib/pgsql
PSQLPAS=$1

# Remove history 
if [ ! -s  $PSQLDIR/.bash_history ]; then
    echo -e  "OK\t.bash_history is empty"
else
    echo -e  "FAILED\t.bash_history is not empty"
fi

if [ ! -s $PSQLDIR/.psql_history ]; then
    echo -e  "OK\t.psql_history is empty"
else
    echo -e  "FAILED\t.psql_history is not empty"
fi

# Accessing Postgres folders 
RES_PERM=`stat --format="%a %U %G" /var/lib/pgsql`
if [ "$RES_PERM" == "700 postgres postgres" ]; then
    echo -e  "OK\tPostgres home folder has proper permissions"
else
    echo -e  "FAILED\tPostgres home folder permissions are invalid"
fi

# No databases must be located on system partition 
RES_ROOTPART=`stat --printf '%D' $PSQLDIR`
RES_DATAPART=`stat --printf '%D' /`
if [ "$RES_ROOTPART" != "$RESDATAPART" ]; then
    echo -e  "OK\tPostgres has separate device for storing data"
else
    echo -e  "FAILED\tPostgres data is located on system root device"
fi

# Change default postgres password
unset PGPASSWORD
/usr/bin/psql -q -U postgres -w -c "SELECT 1" 2>/dev/null >/dev/null
RES_CONN=$?
if [ "$RES_CONN" == 2 ]; then
    echo -e  "OK\tCannot connect to postgres database without password"
else
    echo -e  "FAILED\tUnathorized access to postgres database"
fi

# Change default postgres password
export PGPASSWORD=$PSQLPAS
/usr/bin/psql -U postgres -q -w -c "SELECT 1" 2>/dev/null >/dev/null
RES_CONN=$?
if [ "$RES_CONN" == 0 ]; then
    echo -e  "OK\tCan connect to postgres database using <password>"
else
    echo -e  "FAILED\tCannot connect to postgres database using <password>"
fi
unset PGPASSWORD

# PostgreSQL must run as unprivileged user 
RES_PID=`ps -eo pid,args | grep postmaster | grep -v grep | cut -c1-6`
RES_OWNER=`ps axu |egrep "$RES_PID.*postmaster" |grep -v "grep" |awk -F " " '{print $1}'`
if [ "$RES_OWNER" != "root" ]; then
    echo -e  "OK\tPostgreSQL server is running as unprivileged user $RES_OWNER"
else 
    echo -e  "FAILED\tPostgreSQL server is running as privileged user"
fi


