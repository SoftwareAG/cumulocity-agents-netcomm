name "cumulocity-base"
description "Base role applied to all nodes"
