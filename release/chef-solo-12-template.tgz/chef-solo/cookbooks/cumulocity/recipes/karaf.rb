Chef::Config[:yum_timeout] = 300
if node['useVaults']
  include_recipe "chef-vault"
end

if node['cumulocity-karaf']['notification']
  include_recipe "cumulocity::karaf_notification"
end

available_memory = node["memory"]["total"][0..-3].to_i/1024
memory_for_system = node["cumulocity-karaf"]["memory_left_for_system"].to_i
karaf_xmx = "#{available_memory-memory_for_system}M"
if node['cumulocity-karaf']['karaf']['memory']['xms'].nil?
  karaf_xms = "#{((available_memory-memory_for_system)*0.5).to_i}M"
else
  karaf_xms = node['cumulocity-karaf']['karaf']['memory']['xms']
end
karaf_env = {"JAVA_MIN_MEM" => karaf_xms,
             "JAVA_MAX_MEM" => karaf_xmx,
             "JAVA_PERM_MEM" => node["cumulocity-karaf"]["karaf"]["memory"]["min_perm_gen"],
             "JAVA_MAX_PERM_MEM" => node["cumulocity-karaf"]["karaf"]["memory"]["max_perm_gen"]
}

coreNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-mn-active-core")

node.default['cumulocity-core']['properties']['local.ip.address']=node['ipaddress']
node.default['cumulocity-core']['properties']['local.port']="8181"
node.default['cumulocity-core']['properties']['node.ip.list']=coreNodes.collect{|x| x['ipaddress']}.sort.join(',')

unless node['cumulocity-external-lb']['basefolder4apps'].nil?
    node.default['cumulocity-core']['properties']['unpackApplicationsDir']=node['cumulocity-external-lb']['basefolder4apps']
end
basefolder4apps = node['cumulocity-core']['properties']['unpackApplicationsDir']
node.default['cumulocity-core']['properties']['installApplicationsDir']="#{basefolder4apps}/2Install"
node.default['cumulocity-core']['properties']['installMicroservicesDir']="#{basefolder4apps}/2Images"

mongodbnodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-mongo-standalone")
if mongodbnodes.length >0 && mongodbnodes.first.name != node.name
  node.default["cumulocity-core"]["properties"]["mongodb.host"] = mongodbnodes.first['ipaddress']
else
  node.default["cumulocity-core"]["properties"]["mongodb.host"] = "localhost"
end

unless node['cumulocity-karaf']['cep-server-enabled'].nil?
    cepNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-cep-server")
    if  cepNodes.length>0
	node.override['cumulocity-core']['properties']['cepServer.baseURL']="#{cepNodes.first['ipaddress']}:8989"
    end
end

syslog_enabled = node['recipes'].include?'cumulocity-rsyslog'

package_name = node['cumulocity-karaf']['package-name']

if node.chef_environment.index(/non.?prod/)
  branch = "develop"
else
  branch = "default"
end

include_recipe "java::openjdk"

directory "/usr/java" do
  owner "root"
  group "root"
  mode "0755"
  action :create
end

link "/usr/java/default" do
  to node['java']['java_home']
end

yum_repository 'cumulocity' do
  description 'cumulocity Repository'
  baseurl node['yum']['repositories']['cumulocity']['url']
  gpgcheck false
  enabled true
  action :create
end

if node[:roles].include? "cumulocity-dev-singlenode" and package_name == "cumulocity-core-karaf" and branch == "develop"
  execute "install-karaf" do 	# workaround for installing version 6.* for cucumber test!
    command "yum install cumulocity-core-karaf --exclude=cumulocity-core-karaf-6* -y"
  end
else
  package package_name do
    unless node['cumulocity-karaf']['version'].nil?
      if not node[:roles].include? "cumulocity-mn-active-core"
        version node['cumulocity-karaf']['version']
      end
      allow_downgrade true
    end
  end
end


if coreNodes.length > 0
    if node.name == coreNodes.sort {|n1,n2| n1.name <=> n2.name}.first.name
        if not node['cumulocity-GUI']['version'].nil?
            bash "getGUIpackage" do
                cwd Chef::Config[:file_cache_path]
                user "karaf"
                group "karaf"
                code <<-EOH
touch "#{basefolder4apps}/2Install/.lockFile"
cd "#{basefolder4apps}/2Install"
wget "#{node['cumulocity-GUI']['connString']}/#{node['cumulocity-GUI']['version']}.zip"
rm -f "#{basefolder4apps}/2Install/.lockFile"
                EOH
                not_if { Dir.glob("#{basefolder4apps}/2Install/#{node['cumulocity-GUI']['version']}.*").any?}
                only_if { Dir.glob("#{basefolder4apps}/2Install").any?}
            end
        end
        if not node['cumulocity-kubernetes'].nil? and not node['cumulocity-kubernetes']['images-version'].nil? and node[:roles].include? "cumulocity-kubernetes"
            bash "getK8Simages" do
                cwd Chef::Config[:file_cache_path]
                user "karaf"
                group "karaf"
                code <<-EOH
touch "#{basefolder4apps}/2Images/.lockFile"
images2install=( #{node['cumulocity-kubernetes']['images2install'].map(&:to_s).join(" ")} )
cd "#{basefolder4apps}/2Images"
for ii in "${images2install[@]}"
do
wget "#{node['cumulocity-kubernetes']['images-connString']}/${ii}-#{node['cumulocity-kubernetes']['images-version']}.zip"
done
rm -f "#{basefolder4apps}/2Images/.lockFile"
                EOH
                not_if { Dir.glob("#{basefolder4apps}/2Images/*-#{node['cumulocity-kubernetes']['images-version']}.*").any?}
                only_if { Dir.glob("#{basefolder4apps}/2Images").any?}
                only_if { File.exists?("/etc/cumulocity/k8s.conf") }
            end

        end
    end
end

unless node['cumulocity-kubernetes'].nil? 
    node.default['cumulocity-core']['properties']['microservice.kubernetes.config']="/etc/cumulocity/k8s.conf"
    node.default['cumulocity-core']['properties']['microservice.kubernetes.namespace']="#{node.chef_environment}"
    node.default['cumulocity-core']['properties']['microservice.provider']="kubernetes"
    node.default['cumulocity-core']['properties']['microservice.kubernetes.baseURL']="http://#{node.chef_environment}.svc.cluster.local"
    node.default['cumulocity-core']['properties']['microservice.docker.host']="unix:///var/run/docker.sock"
    node.default['cumulocity-core']['properties']['microservice.docker.registry.secrets']="#{node.chef_environment}-secret"
    node.default['cumulocity-core']['properties']['microservice.docker.registry.host']="https://kube-registry-persistent-secure.#{node.chef_environment}.svc.cluster.local:5000"
end



# loop over node[cumulocity-karaf][properties-filenames]
include_recipe "cumulocity::karaf_common-core"

if node['useVaults']
  vault = begin
          chef_vault_item(:secrets, "#{node.chef_environment}.core")
          rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
          nil
  end
end

properties_filenames = node['cumulocity-karaf']['properties-filenames']
properties_filenames.each do |property_file|
  template "/etc/cumulocity/#{property_file}" do
    source "karaf/#{property_file}.erb"
    owner "karaf"
    group "root"
    mode "0640"
    variables( :ssAgentsIP => node['ssAgentsIP'],
               :k8sAgentsIP => node['k8sAgentsIP'],
               :taggednodes => node['taggednodes'],
               :vault => vault)
  end
end

execute "prepare_for_clean_boot" do
  command "rm -rf /usr/share/#{package_name}/data/cache"
  action :run
  not_if "/etc/init.d/#{package_name} status"
end

template "/etc/cumulocity/cumulocity-application-default.properties" do
  source "karaf/cumulocity-application-default.properties.erb"
  owner "karaf"
  group "root"
  mode "0640"
  variables :branch => branch
end

template "/usr/share/#{package_name}/bin/setenv" do
  source "karaf/setenv.erb"
  owner "root"
  group "root"
  mode "0644"
  variables(:karaf_xmx => karaf_xmx, :karaf_xms => karaf_xms, :branch => branch)
end

template "/usr/share/#{package_name}/etc/org.ops4j.pax.logging.cfg" do
  source "karaf/org.ops4j.pax.logging.cfg.erb"
  owner "root"
  group "root"
  mode "0644"
  variables(:branch => branch)
end


unless node['cumulocity-karaf']['CUMULOCITY_LICENCE_KEY'].nil?
    unless node['cumulocity-karaf']['CUMULOCITY_LICENCE_DIR'].nil?
      licencePATH=node['cumulocity-karaf']['CUMULOCITY_LICENCE_DIR']
    else
      licencePATH="/etc/cumulocity"
    end
    directory "#{licencePATH}" do
      recursive true
    end
    file "#{licencePATH}/c8y.licence" do
        owner "karaf"
        group "root"
        mode "0640"
        content "c8y.licence=#{node['cumulocity-karaf']['CUMULOCITY_LICENCE_KEY']}"
    end
end


service package_name do
  supports :restart => false, :status => false
  action [ :enable ]
end


if (node[:roles].include? "cumulocity-common-cores" and not node[:roles].include? "cumulocity-mn-active-core")
  Chef::Log.info('Karaf will NOT be run, because it is not active node in this environment')
  Chef::Log.info('You can run Karaf manually for test or update')
  service "postfix" do
    action :stop
  end
else
  execute "nohup /etc/init.d/#{package_name} start" do
    environment karaf_env
    action :run
    not_if "/etc/init.d/#{package_name} status"
  end
  if node['cumulocity-karaf']['notification']
    service "postfix" do
      action :start
    end
  end
end

unless node[:roles].include? "cumulocity-cep-server" or node[:roles].include? "cumulocity-dev-singlenode"
    node.default['taggednodes'] = nil
end
