yum_repository 'cumulocity' do
  description 'cumulocity Repository'
  baseurl node['yum']['repositories']['cumulocity']['url']
  gpgcheck false
  enabled true
  action :create
end

if node['cumulocity-external-lb']['nginx']['NGinxPort'].nil?
    NGinxPortPack = "nginx"
    %w{openssl openssl-static openssl-devel}.each do |pkg|
        yum_package pkg do
            action :install
            options "--skip-broken"
        end
    end

    yum_package "openresty" do
        action :remove
    end

    package "nginx" do
        version node['cumulocity-external-lb']['nginx']['version']
        action :install
    end
else
    NGinxPortPack = node['cumulocity-external-lb']['nginx']['NGinxPort']
    %w{openresty-pcre-devel openresty-zlib-devel}.each do |pkg|
        yum_package pkg do
            action :install
        end
    end

    yum_package "nginx" do
        action :remove
    end

    package "#{node['cumulocity-external-lb']['nginx']['NGinxPort']}" do
        version node['cumulocity-external-lb']['nginx']['version']
        action :install
    end
end

directory "/etc/nginx/certs/" do
  owner "root"
  group "root"
  mode "0600"
  action :create
end

if node.chef_environment.index 'prod'
  basenameforapps = node['environment']['address']
else
  basenameforapps = node.name.split("_").first + "." + node['domainname']
end

domain = node['cumulocity-external-lb']['certificate_domain']
basefolder4apps = node['cumulocity-external-lb']['basefolder4apps']


directory "/usr/share/nginx/html/" do
    action :create
    recursive true
end

cookbook_file "/usr/share/nginx/html/apps-error.html" do
  owner "root"
  group "root"
  mode "0644"
  source "external-lb/apps-error.html"
end

cookbook_file "/usr/share/nginx/html/maintenance-break.html" do
  owner "root"
  group "root"
  mode "0644"
  source "external-lb/maintenance-break.html"
end

unless File.exists? "/etc/nginx/dhparams.pem"
  execute "generate_dhparam_pem" do
    command "openssl dhparam -out /etc/nginx/dhparams.pem 2048"
    action :run
    user "root"
  end
  isdhparams = false
else
  isdhparams = true
end

service "#{NGinxPortPack}" do
  service_name #{NGinxPortPack}
  supports :status => true, :restart => true, :reload => true
  action [ :enable, :start ]
end

coreNodes = []
cepNode = []
sqlNodes = []
specialNodes = []
sslmanagementNode = []
ontopLBNodes = 0

if node['cumulocity-external-lb']['usePostgresForPaaS']
  sqlNodes = search(:node, "chef_environment:#{node.chef_environment} AND roles:cumulocity-sql-db")
end
specialNodes = search(:node, "chef_environment:#{node.chef_environment} AND (role:cumulocity-cms-yum-part OR role:cumulocity-ssagents OR role:cumulocity-kubernetes)")
useIPaddress = node['cumulocity-external-lb']['useIPAddress']

unless node['cumulocity-karaf']['cep-server-enabled'].nil?
  cepNode = search(:node, "chef_environment:#{node.chef_environment} AND roles:cumulocity-cep-server")
end

unless node['cumulocity-karaf']['management-access'].nil?
    admin_nodes = node['cumulocity-karaf']['management-access']
end

unless node['cumulocity-external-lb']['useLUAforSSLcerts'].nil?
    sslmanagementNode = search(:node, "chef_environment:#{node.chef_environment} AND roles:cumulocity-ssagents AND tags:ssl-management-agent-server")
end

unless node['cumulocity-external-lb']['useLUAforLimits'].nil?
    ontopLBNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-ontop-lb").length
    if ontopLBNodes == 0
        ontopLBNodes = 1
    end
end

if (node[:roles].include? "cumulocity-common-cores" or node[:roles].include? "cumulocity-dev-singlenode" )
  coreNodes << node
  if not node[:roles].include? "cumulocity-mn-active-core"
    useIPaddress = true
  end
else
  coreNodes = search(:node, "chef_environment:#{node.chef_environment} AND (role:cumulocity-core OR role:cumulocity-mn-active-core)")
end

coreNodes.sort! {|n1,n2| n1.name <=> n2.name}
specialNodes.sort! {|n1,n2| n1.name <=> n2.name}

if not node[:roles].include? "cumulocity-ontop-lb"
  directory basefolder4apps do
    owner "nginx"
    group "karaf"
    mode "0770"
    action :create
  end
  directory "#{basefolder4apps}/2Install" do
    owner "nginx"
    group "karaf"
    mode "0770"
    action :create
  end
  directory "#{basefolder4apps}/2Images" do
    owner "nginx"
    group "karaf"
    mode "0770"
    action :create
  end
end

if coreNodes.length > 0
template "/etc/nginx/nginx.conf" do
  source "external-lb/nginx.conf.erb"
  variables(
    :coreNodes => coreNodes,
    :sqlNodes => sqlNodes,
    :domain => domain,
    :basenameforapps => basenameforapps,
    :specialNodes => specialNodes,
    :admin_nodes => admin_nodes,
    :useIPaddress => useIPaddress,
    :cepNode => cepNode,
    :isdhparams => isdhparams,
    :basefolder4apps => basefolder4apps
  )
  owner "root"
  group "root"
  mode "0644"
  notifies :reload, "service[#{NGinxPortPack}]"
end

if node['cumulocity-external-lb']['useSSL']
  certificate = search(:certs, "domain:#{domain}").first
  concentrate = certificate['cert'] + certificate['chain']

  file "/etc/nginx/certs/#{domain}.key" do
    owner "root"
    group "root"
    mode 0600
    content certificate['key']
  end

  file "/etc/nginx/certs/#{domain}.cert" do
    owner "root"
    group "root"
    mode 0600
    content concentrate
    notifies :restart, "service[#{NGinxPortPack}]"
  end
end


unless node['nagios']['performance_monitoring'].nil?
  template "/etc/nginx/nagios.conf" do
    source "external-lb/nagios.conf.erb"
    owner "root"
    group "root"
    mode "0644"
    notifies :reload, "service[#{NGinxPortPack}]"
  end
end

template "/etc/nginx/proxy.conf" do
  source "external-lb/proxy.conf.erb"
  owner "root"
  group "root"
  mode "0644"
  notifies :reload, "service[#{NGinxPortPack}]"
end

if node['cumulocity-external-lb']['useLUAforLimits'] and not node['cumulocity-external-lb']['temp_chunkin'] and node[:roles].include?('cumulocity-ontop-lb')
template "/etc/nginx/limits.lua" do
  source "external-lb/limits.lua.erb"
  variables(:ontopLBNodes => ontopLBNodes)
  owner "root"
  group "root"
  mode "0644"
  notifies :reload, "service[#{NGinxPortPack}]"
end
end

if node['cumulocity-external-lb']['useLUAforSSLcerts'] and not node['cumulocity-external-lb']['temp_chunkin'] and node[:roles].include?('cumulocity-ontop-lb')
template "/etc/nginx/dynSSLcerts.lua" do
  source "external-lb/dynSSLcerts.lua.erb"
  variables(:sslmanagementNode => sslmanagementNode)
  owner "root"
  group "root"
  mode "0644"
  notifies :reload, "service[#{NGinxPortPack}]"
end
end

if node['cumulocity-external-lb']['useLUAforHealthCheck'] and not node['cumulocity-external-lb']['temp_chunkin'] and node[:roles].include?('cumulocity-ontop-lb')
template "/etc/nginx/healthcheck.lua" do
  source "external-lb/healthcheck.lua.erb"
  owner "root"
  group "root"
  mode "0644"
  notifies :reload, "service[#{NGinxPortPack}]"
end
end
end
