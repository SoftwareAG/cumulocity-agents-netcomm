include_recipe "cumulocity::karaf"
