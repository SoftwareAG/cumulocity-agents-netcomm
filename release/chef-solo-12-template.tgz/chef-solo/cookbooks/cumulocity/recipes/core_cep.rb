# do nothing, read only its default atributes
