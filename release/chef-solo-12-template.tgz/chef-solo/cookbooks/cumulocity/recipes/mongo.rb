include_recipe "yum"
if node['useVaults']
  include_recipe "chef-vault"
end

if node['el7'] or Chef::Config[:solo]
  if ( node['ulimit']['users']['mongod']['filehandle_hard_limit'].nil? rescue true )
    limitnofile = "64000"
  else
    limitnofile = node['ulimit']['users']['mongod']['filehandle_hard_limit']
  end
  if ( node['ulimit']['users']['mongod']['process_hard_limit'].nil? rescue true )
    limitnproc = "64000"
  else
    limitnproc = node['ulimit']['users']['mongod']['process_hard_limit']
  end
end

if node['cumulocity-mongo']['installEnterprise']
  yum_repository 'cumulocity' do
    description 'cumulocity Repository'
    baseurl node['yum']['repositories']['cumulocity']['url']
    gpgcheck false
    enabled true
    action :create
  end
  %w{
    mongodb-enterprise
    mongodb-enterprise-server
    mongodb-enterprise-shell
    mongodb-enterprise-tools
    mongodb-enterprise-mongos
    }.each do |package_name|
    package package_name do
      action :install
    end
  end
else
  yum_repository 'mongodb' do
    description 'MongoDB Repository'
    baseurl node['yum']['repositories']['mongodb']['url']
    gpgcheck true
    enabled true
    gpgkey node['yum']['repositories']['mongodb']['gpgkey']
    action :create
  end
  %w{
    mongodb-org
    mongodb-org-server
    mongodb-org-shell
    mongodb-org-tools
    mongodb-org-mongos
    }.each do |package_name|
    package package_name do
      action :install
    end
  end
end

service "mongod" do
  action :disable
end

directory "/etc/mongo" do
  owner node['cumulocity-mongo']['initRunUser']
  group node['cumulocity-mongo']['initRunGroup']
  mode '0750'
  action :create
end

directory "/var/log/mongodb" do
  owner node['cumulocity-mongo']['initRunUser']
  group node['cumulocity-mongo']['initRunGroup']
  mode '0750'
  action :create
end

cookbook_file "/etc/logrotate.d/mongodb" do
  owner "root"
  group "root"
  mode "0644"
  source "mongo/mongodb"
end

directory "/opt/mongodb" do
  owner node['cumulocity-mongo']['initRunUser']
  group node['cumulocity-mongo']['initRunGroup']
  mode '0770'
  action :create
end

directory "/opt/mongodb/configdb" do
  owner node['cumulocity-mongo']['initRunUser']
  group node['cumulocity-mongo']['initRunGroup']
  mode '0770'
  action :create
end

directory "/var/run/mongodb" do
  owner node['cumulocity-mongo']['initRunUser']
  group node['cumulocity-mongo']['initRunGroup']
  mode '0770'
  action :create
end

if node.chef_environment.index 'prod'
  tagtab = node.tags

  file "#{node['cumulocity-mongo']['sharedkey-file']}" do
    owner node['cumulocity-mongo']['initRunUser']
    group "root"
    mode 0600
    content node['cumulocity-mongo']['sharedkey-content']
  end

  unless tagtab.include? "standalone:mongod7:"
    directory "#{node['cumulocity-mongo']['status-dir']}" do
      owner node['cumulocity-mongo']['initRunUser']
      group 'root'
      mode '0770'
      recursive true
      action :create
    end
    include_recipe "cumulocity::mongo_configureReplicaSet" unless ::File.exist?("/etc/mongo/.createdRS")
    include_recipe "cumulocity::mongo_configureShard" unless ::File.exist?("/etc/mongo/.addedShard")
  end

else
  tagtab = ["standalone:mongod7:"]
end

tagtab.each do |tagg| if tagg.include? 'replicaset:' or tagg.include? 'standalone:'
    rsroles = tagg.split(":")
    puts "#{rsroles[1]} and #{rsroles[2]}"

    directory "/opt/mongodb/#{rsroles[1]}" do
      owner node['cumulocity-mongo']['initRunUser']
      group node['cumulocity-mongo']['initRunGroup']
      mode '0770'
      action :create
    end

    template "/etc/mongo/mongo#{rsroles[1]}.conf" do
      source "mongo/mongors.conf.erb"
      owner node['cumulocity-mongo']['initRunUser']
      group "mongod"
      mode 0640
      variables(
          :rsname => rsroles[1],
          :rsrole => rsroles[2]
      )
    end

    template "/etc/init.d/mongod#{rsroles[1]}" do
        source "mongo/mongod.init.erb"
        owner "root"
        group "mongod"
        mode 0755
        variables(
            :mongoTag => rsroles[1],
            :mongoConfigFile => "mongo" + rsroles[1] + ".conf",
            :mongoConfigDir => "/etc/mongo"
        )
    end

    if node['el7']
      systemd_unit "mongod#{rsroles[1]}.service" do
        content <<-EOU
[Unit]
Documentation=man:mongod(1)
Description=SYSV: Mongo is a scalable, document-oriented database.
Before=runlevel2.target
Before=runlevel3.target
Before=runlevel4.target
Before=runlevel5.target
After=network-online.target
After=network.service

[Service]
Type=forking
Restart=no
TimeoutSec=60min
IgnoreSIGPIPE=no
KillMode=process
GuessMainPID=no
RemainAfterExit=no
ExecStart=/etc/init.d/mongod#{rsroles[1]} restart
ExecStop=/etc/init.d/mongod#{rsroles[1]} stop
ExecReload=/etc/init.d/mongod#{rsroles[1]} reload
LimitNOFILE=#{limitnofile}
LimitNPROC=#{limitnproc}

[Install]
WantedBy=multi-user.target
        EOU
        action [:create, :enable, :start]
      end
    else
      service "mongod#{rsroles[1]}" do
        supports :reload => true, :restart => true, :status => true
        action [:enable, :start]
      end
    end

    if tagg == "standalone:mongod7:"

      if node['useVaults']
        vault = begin
              chef_vault_item(:secrets, "#{node.chef_environment}.core")
              rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
              nil
        end
      end
      mongodbUser = node['cumulocity-core']['properties']['mongodb.user']
      mongodbAdmn = node['cumulocity-core']['properties']['mongodb.admindb']
      mongodbInitUser = node['cumulocity-mongo']['mongodb.initUser']
      #insert vault password
      if node['useVaults']
        mongodbInitPass = vault['mongodb.initPassword']
        mongodbPass = vault['mongodb.password']
      else
        mongodbInitPass = node['cumulocity-mongo']['mongodb.initPassword']
        mongodbPass = node['cumulocity-core']['properties']['mongodb.password']
      end

      if mongodbInitPass.nil?
        Chef::Application.fatal!( "mongodbInitPass is nil", 254 )
      end

      if mongodbPass.nil?
        Chef::Application.fatal!( "mongodbPass is nil", 253 )
      end

      execute "create_mongo_users" do
        command "sleep 3; mongo --eval 'db.createUser({user: \"#{mongodbInitUser}\", pwd: \"#{mongodbInitPass}\", roles: [ \"root\" ]})' #{mongodbAdmn} && mongo -u \"#{mongodbInitUser}\" -p \"#{mongodbInitPass}\" --authenticationDatabase \"#{mongodbAdmn}\" --eval 'db.createUser({user: \"#{mongodbUser}\", pwd: \"#{mongodbPass}\", roles: [ \"readWriteAnyDatabase\",\"dbAdminAnyDatabase\",\"clusterManager\" ]})' #{mongodbAdmn} && touch /etc/mongo/.creds"
        action :run
	      not_if { ::File.exist?("/etc/mongo/.creds") }
      end
    end
  end
end


if node[:roles].include? "cumulocity-mongo-configsvr"

csrsroles = []
tagtab.each do |tagg| if tagg.include? 'configreplset:'
    csrsroles = tagg.split(":")
    puts "#{csrsroles[1]} and #{csrsroles[2]}"
end
end

  template "/etc/mongo/mongoconfig.conf" do
    source "mongo/mongoconfig.conf.erb"
    owner node['cumulocity-mongo']['initRunUser']
    group "mongod"
    mode 0640
    variables(
        :rsname => csrsroles[1],
        :rsrole => csrsroles[2]
    )
  end

  template "/etc/init.d/mongodconfig" do
    source "mongo/mongod.init.erb"
    owner "root"
    group "mongod"
    mode 0755
    variables(
        :mongoTag => "config",
        :mongoConfigFile => "mongoconfig.conf",
        :mongoConfigDir => "/etc/mongo"
    )
  end

  if node['el7']
    systemd_unit "mongodconfig.service" do
      content <<-EOU
[Unit]
Documentation=man:mongod(1)
Description=SYSV: Mongo is a scalable, document-oriented database.
Before=runlevel2.target
Before=runlevel3.target
Before=runlevel4.target
Before=runlevel5.target
After=network-online.target
After=network.service

[Service]
Type=forking
Restart=no
TimeoutSec=60min
IgnoreSIGPIPE=no
KillMode=process
GuessMainPID=no
RemainAfterExit=no
ExecStart=/etc/init.d/mongodconfig restart
ExecStop=/etc/init.d/mongodconfig stop
ExecReload=/etc/init.d/mongodconfig reload
LimitNOFILE=#{limitnofile}
LimitNPROC=#{limitnproc}

[Install]
WantedBy=multi-user.target
      EOU
      action [:create, :enable, :start]
    end
  else
    service "mongodconfig" do
      supports :reload => true, :restart => true, :status => true
      action [:enable, :start]
    end
  end

  if not csrsroles[1].nil?
    include_recipe "cumulocity::mongo_configureConfigSvrRS" unless ::File.exist?("/etc/mongo/.createdCS")
  end

end

