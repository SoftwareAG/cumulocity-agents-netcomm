users_manage "wheel" do
  action [ :remove, :create ]
  data_bag 'users_cumulocity'
end

users_manage "adm" do
  action [ :remove, :create ]
  data_bag 'users_cumulocity'
end

users_manage "users" do
  action [ :remove, :create ]
  data_bag 'users_cumulocity'
end


node.default['authorization']['sudo']['passwordless'] = true
include_recipe "sudo"
