package "postfix"

if node['environment'].include?("address") and not node['environment'].address.nil?
  myhostname, mydomain = node['environment'].address.split('.',2)
else
  myhostname = node['cumulocity-karaf']['myhostname']
  mydomain = node['cumulocity-karaf']['mydomain']
end

service "postfix" do
  action :enable
end

template "/etc/postfix/main.cf" do
  source "karaf/main.cf.erb"
  owner "root"
  group "root"
  mode "0644"
  variables(:myhostname => myhostname,  :mydomain => mydomain)
  notifies :reload, "service[postfix]", :delayed
end

execute "rebuild_transport_db" do
  command "postmap /etc/postfix/transport"
  action :run
end

execute 'postmap-sasl_passwd' do
  command "postmap /etc/postfix/sasl_passwd"
  action :nothing
end

if node['postfix']['smtp_sasl_auth_enable']
  template "/etc/postfix/sasl_passwd" do
    source "karaf/sasl_passwd.erb"
    owner "root"
    group "root"
    mode "0600"
    notifies :run, 'execute[postmap-sasl_passwd]', :immediately
    notifies :reload, "service[postfix]"
  end
end

execute 'postmap-transport' do
  command "postmap /etc/postfix/transport"
  action :nothing
end

unless node['cumulocity-karaf']['openrelayIP'].nil?
  template "/etc/postfix/transport" do
    source "karaf/transport.erb"
    owner "root"
    group "root"
    mode "0644"
    notifies :run, 'execute[postmap-transport]', :immediately
    notifies :reload, "service[postfix]"
  end
end
