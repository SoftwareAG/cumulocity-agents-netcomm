
node["agent_server_list"].each { |agent|
    package agent

    service agent do
	action [ :enable, :start ]
    end
}

