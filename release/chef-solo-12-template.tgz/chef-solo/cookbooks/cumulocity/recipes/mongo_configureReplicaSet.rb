if node.tags.count > 0
  if node.tags.grep(/replicaset:.+:P$/).length > 0
    myrs = node.tags.grep(/replicaset:.+:P$/)[0].split(":")[1]

    rsSecNodes = search(:node, "chef_environment:#{node.chef_environment} AND tags:replicaset*#{myrs}*S")
    rsArbNodes = search(:node, "chef_environment:#{node.chef_environment} AND tags:replicaset*#{myrs}*A")

    if not node['cumulocity-mongo']['members-check'] or ( node['cumulocity-mongo']['members-check'] and rsSecNodes.length + rsArbNodes.length == node['cumulocity-mongo']['total-members'] - 1 )

      rsPriPort = "2701" + myrs.split('').last

      if node['useVaults']
        vault = begin
            chef_vault_item(:secrets, "#{node.chef_environment}.core")
            rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
            nil
        end
      end

      mongodbAdmn = node['cumulocity-core']['properties']['mongodb.admindb']
      mongodbInitUser = node['cumulocity-mongo']['mongodb.initUser']
      if node['useVaults']
        mongodbInitPass = vault['mongodb.initPassword']
      else
        mongodbInitPass = node['cumulocity-mongo']['mongodb.initPassword']
      end

      if mongodbInitPass.nil?
        Chef::Application.fatal!( "mongodbInitPass is nil", 254 )
      end

      template "/etc/mongo/mongo-createRS.sh" do
        source "mongo/mongo-createRS.erb"
        variables(
            :rsSecNodes => rsSecNodes,
            :rsArbNodes => rsArbNodes,
            :rsPriPort => rsPriPort,
            :mongodbAdmn => mongodbAdmn,
            :mongodbInitUser => mongodbInitUser,
            :mongodbInitPass => mongodbInitPass,
            :rsname => myrs
        )
        owner "root"
        group "root"
        mode 0770
      end

      execute 'createRS' do
        command '/etc/mongo/mongo-createRS.sh'
        only_if { File.exists?("/etc/mongo/mongo-createRS.sh") }
        not_if { File.exists?("/etc/mongo/.createdRS") }
        action :run
      end

    end
  end
end
