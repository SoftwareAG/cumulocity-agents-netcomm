Chef::Config[:yum_timeout] = 300

package "redhat-lsb-core"
package "java-1.7.0-openjdk"

user 'karaf' do
  shell '/bin/bash'
  system true
end

yum_repository 'cumulocity' do
  description 'cumulocity Repository'
  baseurl node['yum']['repositories']['cumulocity']['url']
  gpgcheck false
  enabled true
  action :create
end

package node['cumulocity-cep']['package_name'] do
  unless node['cumulocity-cep']['version'].nil?
    version node['cumulocity-cep']['version']
  end
  allow_downgrade true
  action :install
end

extLBNodes = []
extLBNodes = search(:node, "chef_environment:#{node.chef_environment} AND roles:cumulocity-ontop-lb")
if extLBNodes.length == 1
  extLBNodeIP = extLBNodes.first['ipaddress']
else
  extLBNodeIP = "127.0.0.1"
end

node.default['cumulocity-core']['properties']['linkTemplateProcessor.clientProtocolType']=true
node.default['cumulocity-core']['properties']['errorMessageRepresentationBuilder.includeDebug']=true
node.default['cumulocity-core']['properties']['errorMessageRepresentationBuilder.documentationBaseUrl']="https://www.cumulocity.com/guides/reference-guide"
node.default['cumulocity-core']['properties']['http.server']=""

node.default['cumulocity-cep']['properties']['server.port']="8989"
node.default['cumulocity-cep']['properties']['C8Y.baseURL']="http://#{extLBNodeIP}:8111"
node.default['cumulocity-cep']['properties']['server.tomcat.access-log-enabled']=false
node.default['cumulocity-cep']['properties']['server.tomcat.access-log-pattern']="%h %l %u %t \"%r\" %s %b %D"
node.default['cumulocity-cep']['properties']['server.tomcat.basedir']="/usr/share/cumulocity-cep-server/tomcat"
node.default['cumulocity-cep']['properties']['esperha.storage']="/mnt/esperha-storage"
node.default['cumulocity-cep']['properties']['esperha.checkpointing.eventCount']=1000
node.default['cumulocity-cep']['properties']['esperha.checkpointing.intervalMSec']=60000
node.default['cumulocity-cep']['properties']['metrics.active']=true
node.default['cumulocity-cep']['properties']['metrics.engineIntervalMSec']=3600000
node.default['cumulocity-cep']['properties']['metrics.statementIntervalMSec']=3600000
node.default['cumulocity-cep']['properties']['pushAgent.host']="localhost:8788"

mongodbnodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-mongo-standalone")
if mongodbnodes.length >0 && mongodbnodes.first.name != node.name
  node.default["cumulocity-core"]["properties"]["mongodb.host"] = mongodbnodes.first['ipaddress']
else
  node.default["cumulocity-core"]["properties"]["mongodb.host"] = "localhost"
end

node.override['cumulocity-karaf']['properties-filenames'] = ["cumulocity-core.properties","cumulocity-cep-server.properties"]

# loop over node[cumulocity-karaf][properties-filenames]
include_recipe "cumulocity::karaf_common-core"
if node['useVaults']
  vault = begin
          chef_vault_item(:secrets, "#{node.chef_environment}.core")
          rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
          nil
  end
end

properties_filenames = node['cumulocity-karaf']['properties-filenames']
properties_filenames.each do |property_file|
  template "/etc/cumulocity/#{property_file}" do
    source "karaf/#{property_file}.erb"
    owner "karaf"
    group "root"
    mode "0640"
    variables( :ssAgentsIP => node[:ssAgentsIP],
               :k8sAgentsIP => node[:k8sAgentsIP],
               :taggednodes => node[:taggednodes],
               :vault => vault)
  end
end


# Create the required Esper HA directory
directory 'esperha.storage' do
  owner 'karaf'
  group 'karaf'
  mode '0775'
  path "#{node['cumulocity-cep']['properties']['esperha.storage']}"
  recursive true
  action :create
end


service node['cumulocity-cep']['package_name'] do
    action [ :enable, :start ]
end

node.default['taggednodes'] = nil
