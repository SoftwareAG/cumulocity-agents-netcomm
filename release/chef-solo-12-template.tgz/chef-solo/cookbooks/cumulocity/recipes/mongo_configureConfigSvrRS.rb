if node.tags.count > 0
  if node.tags.grep(/configreplset:.+:P$/).length > 0
    myrs = node.tags.grep(/configreplset:.+:P$/)[0].split(":")[1]

    rsSecNodes = search(:node, "chef_environment:#{node.chef_environment} AND tags:configreplset*#{myrs}*S")

    if not node['cumulocity-mongo']['members-check'] or ( node['cumulocity-mongo']['members-check'] and rsSecNodes.length == node['cumulocity-mongo']['total-members'] - 1 )

      rsPriPort = "2701" + myrs.split('').last

      if node['useVaults']
        vault = begin
            chef_vault_item(:secrets, "#{node.chef_environment}.core")
            rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
            nil
        end
      end

      mongodbAdmn = node['cumulocity-core']['properties']['mongodb.admindb']
      mongodbInitUser = node['cumulocity-mongo']['mongodb.initUser']
      if node['useVaults']
        mongodbInitPass = vault['mongodb.initPassword']
      else
        mongodbInitPass = node['cumulocity-mongo']['mongodb.initPassword']
      end

      if mongodbInitPass.nil?
        Chef::Application.fatal!( "mongodbInitPass is nil", 254 )
      end

      csrsroles = []
      tagtab = node.tags
      tagtab.each do |tagg| if tagg.include? 'configreplset:'
         csrsroles = tagg.split(":")
      #puts "#{csrsroles[1]} and #{csrsroles[2]}"
      end
      end

      template "/etc/mongo/mongo-createCS.sh" do
        source "mongo/mongo-createCS.erb"
        variables(
          :rsSecNodes => rsSecNodes,
          :rsPriPort => rsPriPort,
          :mongodbAdmn => mongodbAdmn,
          :mongodbInitUser => mongodbInitUser,
          :mongodbInitPass => mongodbInitPass,
          :rsname => csrsroles[1]
        )
        owner "root"
        group "root"
        mode 0770
      end

    end

  elsif node.tags.grep(/configreplset:.+:S$/).length > 0
    myrs = node.tags.grep(/configreplset:.+:S$/)[0].split(":")[1]
    rsPriPort = "2701" + myrs.split('').last

    template "/etc/mongo/mongo-createCS.sh" do
      source "mongo/mongo-createCS_b.erb"
      variables(
        :rsPriPort => rsPriPort
      )
      owner "root"
      group "root"
      mode 0770
    end

  end

  execute 'createCS' do
    command '/etc/mongo/mongo-createCS.sh'
    only_if { File.exists?("/etc/mongo/mongo-createCS.sh") }
    not_if { File.exists?("/etc/mongo/.createdCS") }
    action :run
  end

end
