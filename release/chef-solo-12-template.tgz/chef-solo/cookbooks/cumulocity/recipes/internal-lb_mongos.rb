if node['cumulocity-mongo']['initRunUser'] != 'root'
  user 'mongod' do
    comment 'mongod'
    home '/var/lib/mongo'
    shell '/bin/false'
    password '!!'
  end
end

mongocfgNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-mongo-configsvr")

unless not node['cumulocity-mongo']['members-check'] or ( node['cumulocity-mongo']['members-check'] and mongocfgNodes.length == node['cumulocity-mongo']['total-members'] )
  include_recipe "cumulocity::internal-lb"
else

  primConfSvr = search(:node, "chef_environment:#{node.chef_environment} AND (tags:configreplset*P)")
  if not primConfSvr[0].nil?
    confSvrReplSet = primConfSvr[0].tags.grep(/configreplset:.+:P$/)[0].split(":")[1]
  end

  include_recipe "yum"

  if node['cumulocity-mongo']['installEnterprise']
    yum_repository 'cumulocity' do
      description 'cumulocity Repository'
      baseurl node['yum']['repositories']['cumulocity']['url']
      gpgcheck false
      enabled true
      action :create
    end
    package "mongodb-enterprise-mongos"
  else
    yum_repository 'mongodb' do
      description 'MongoDB Repository'
      baseurl node['yum']['repositories']['mongodb']['url']
      gpgcheck false
      enabled true
      action :create
    end

    package "mongodb-org-mongos"
  end

  mongoConfigIPs = mongocfgNodes.collect{|x| x['ipaddress']}.sort.join(',')

  directory "/var/log/mongodb/" do
    owner node['cumulocity-mongo']['initRunUser']
    group 'root'
    mode '0750'
    action :create
  end

  directory "/etc/mongo" do
    owner node['cumulocity-mongo']['initRunUser']
    group 'root'
    mode '0750'
    action :create
  end

  file "#{node['cumulocity-mongo']['sharedkey-file']}" do
    owner node['cumulocity-mongo']['initRunUser']
    group "root"
    mode 0600
    content node['cumulocity-mongo']['sharedkey-content']
  end

  template "/etc/mongo/mongos.conf" do
    source "mongo/mongos.conf.erb"
    owner node['cumulocity-mongo']['initRunUser']
    group "root"
    mode 0644
    variables( :mongoConfigIPs => mongoConfigIPs,
               :confSvrReplSet => confSvrReplSet
             )
  end

  cookbook_file "/etc/logrotate.d/mongos" do
    owner "root"
    group "root"
    mode "0644"
    source "mongo/mongodb"
  end

  template "/etc/init.d/mongos" do
      source "internal-lb/mongos.init.erb"
      owner "root"
      group "root"
      mode 0755
      variables(
          :mongoConfigFile => "mongos.conf",
          :mongoConfigDir => "/etc/mongo"
      )
  end

  if node['el7']
    if ( node['ulimit']['users']['mongod']['filehandle_hard_limit'].nil? rescue true )
      limitnofile = "64000"
    else
      limitnofile = node['ulimit']['users']['mongod']['filehandle_hard_limit']
    end
    if ( node['ulimit']['users']['mongod']['process_hard_limit'].nil? rescue true )
      limitnproc = "64000"
    else
      limitnproc = node['ulimit']['users']['mongod']['process_hard_limit']
    end
    systemd_unit "mongos.service" do
      content <<-EOU
[Unit]
Documentation=man:mongos(1)
Description=SYSV: Mongo is a scalable, document-oriented database.
Before=runlevel2.target
Before=runlevel3.target
Before=runlevel4.target
Before=runlevel5.target
After=network-online.target
After=network.service

[Service]
Type=forking
Restart=no
TimeoutSec=60min
IgnoreSIGPIPE=no
KillMode=process
GuessMainPID=no
RemainAfterExit=no
ExecStart=/etc/init.d/mongos start
ExecStop=/etc/init.d/mongos stop
ExecReload=/etc/init.d/mongos reload
LimitNOFILE=#{limitnofile}
LimitNPROC=#{limitnproc}

[Install]
WantedBy=multi-user.target
      EOU
      action [:create, :enable, :start]
    end
  else
    service "mongos" do
      supports :reload => true, :restart => true, :status => true
      action [:enable, :start]
    end
  end

end
