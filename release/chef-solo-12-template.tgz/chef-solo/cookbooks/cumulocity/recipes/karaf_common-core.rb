# It creates cumulocity-core.properties, which is the same for both Karaf & CEP

if node['cumulocity-ssagents']['ssAgentsIP'].nil?
    node.default['ssAgentsIP'] = "127.0.0.1"
else
    node.default['ssAgentsIP'] = node['cumulocity-ssagents']['ssAgentsIP']
end

if node['cumulocity-ssagents']['k8sAgentsIP'].nil?
    node.default['k8sAgentsNodes'] = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-k8s-agents")
    if k8sAgentsNodes.length > 0
        node.default['k8sAgentsIP'] = k8sAgentsNodes.first['ipaddress']
    else
        node.default['k8sAgentsIP'] = "127.0.0.1"
    end
else
    node.default['k8sAgentsIP'] = node['cumulocity-ssagents']['k8sAgentsIP']
end

node.default['taggednodes']=[]
if node['cumulocity-ssagents']['useTags']
    node.default['taggednodes'] = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-ssagents")
end
