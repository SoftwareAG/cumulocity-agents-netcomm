package "haproxy"

service "haproxy" do
  supports :restart => true, :status => true, :reload => true
  action [:enable, :start]
end

service "rsyslog" do
  supports :restart => true, :status => true, :reload => true
  action [:enable, :start]
end


ruby_block "syslog_config" do
  block do
     config_file="/etc/rsyslog.conf"
     text = File.read(config_file)
     text.gsub!(/^# *\$ModLoad imudp/, "$ModLoad imudp" )
     text.gsub!(/^# *\$UDPServerRun 514/, "$UDPServerRun 514" )
     text.gsub!(/^#*.*RULES.*$/) { |m|  "#{m}\nlocal2.* /var/log/haproxy.log\n& ~" }
     File.open(config_file, "w") { |f| f.puts text }
  end
   not_if 'grep -w local2 /etc/rsyslog.conf'
  action :create
end


coreNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-core")
coreNodes.sort! {|n1,n2| n1.name <=> n2.name}

template "/etc/haproxy/haproxy.cfg" do
  source "haproxy.cfg.erb"
  variables(
      :coreNodes => coreNodes
  )
  owner "root"
  group "root"
  mode 0644
  notifies :reload, "service[rsyslog]"
  notifies :reload, "service[haproxy]"
end
