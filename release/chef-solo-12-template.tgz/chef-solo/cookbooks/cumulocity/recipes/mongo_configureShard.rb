if node['useVaults']
  include_recipe "chef-vault"
end
mongocfgNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-mongo-configsvr")
if mongocfgNodes.length == 3 and node.tags.count > 0

    if node.tags.grep(/configreplset:.+:[PS]$/).length > 0
      mycsrs = node.tags.grep(/configreplset:.+:[PS]$/)[0].split(":")[1]
    end
    if not mycsrs.nil?
      csrsPriPort = "2701" + mycsrs.split('').last
      csrsPriSecNodes = search(:node, "chef_environment:#{node.chef_environment} AND (tags:configreplset*#{mycsrs}*P OR tags:configreplset*#{mycsrs}*S)")
      mongoConfigIPs = mycsrs + "/" +csrsPriSecNodes.collect{|x| x['hostname'] + ":" + csrsPriPort}.sort.join(',')
    else
      mongoConfigIPs = mongocfgNodes.collect{|x| x['ipaddress']}.sort.join(',')
    end

if node.tags.grep(/replicaset:.+:P$/).length > 0
    myrs = node.tags.grep(/replicaset:.+:P$/)[0].split(":")[1]
    rsPriPort = "2701" + myrs.split('').last
    rsPriSecNodes = search(:node, "chef_environment:#{node.chef_environment} AND (tags:replicaset*#{myrs}*P OR tags:replicaset*#{myrs}*S)")

    shardStr = myrs + "/" + rsPriSecNodes.collect{|x| x['hostname'] + ":" + rsPriPort }.sort.join(',')

    if node['useVaults']
      vault = begin
          chef_vault_item(:secrets, "#{node.chef_environment}.core")
          rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
          nil
      end
    end

    mongodbAdmn = node['cumulocity-core']['properties']['mongodb.admindb']
    mongodbInitUser = node['cumulocity-mongo']['mongodb.initUser']

    mongodbUser = node['cumulocity-core']['properties']['mongodb.user']
    if node['useVaults']
      mongodbPass = vault['mongodb.password']
      mongodbInitPass = vault['mongodb.initPassword']
    else
      mongodbPass = node['cumulocity-core']['properties']['mongodb.password']
      mongodbInitPass = node['cumulocity-mongo']['mongodb.initPassword']
    end

    if mongodbInitPass.nil?
      Chef::Application.fatal!( "mongodbInitPass is nil", 254 )
    end

    if mongodbPass.nil?
      Chef::Application.fatal!( "mongodbPass is nil", 253 )
    end

    execute 'createRS' do
      command '/etc/mongo/mongo-addShard.sh'
      only_if { File.exists?("/etc/mongo/mongo-addShard.sh") }
      only_if { File.exists?("/etc/mongo/.createdRS") }
      only_if { mycsrs.nil? or File.exists?("/etc/mongo/.createdCS") }
      not_if { File.exists?("/etc/mongo/.addedShard") }
      action :run
    end

    template "/etc/mongo/mongo-addShard.sh" do
      source "mongo/mongo-addShard.erb"
      variables(
        :rsPriSecNodes => rsPriSecNodes,
        :rsname => myrs,
        :shardStr => shardStr,
        :mongoConfigIPs => mongoConfigIPs,
        :mongocfgNodes => mongocfgNodes,
        :mongodbAdmn => mongodbAdmn,
        :mongodbInitUser => mongodbInitUser,
        :mongodbInitPass => mongodbInitPass,
        :mongodbUser => mongodbUser,
        :mongodbPass => mongodbPass
      )
      owner "root"
      group "root"
      mode 0770
    end
end
end
