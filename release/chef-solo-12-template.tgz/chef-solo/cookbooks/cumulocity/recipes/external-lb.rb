#
# Cookbook Name:: cumulocity-loadbalancer
# Recipe:: default
#
# Copyright 2012, NSN
#
# All rights reserved - Do Not Redistribute
#


if node['cumulocity-external-lb']['package'] == "nginx"
  include_recipe "cumulocity::external-lb_nginx"
elsif node['cumulocity-external-lb']['package'] == "haproxy"
  include_recipe "cumulocity::external-lb_haproxy"
end
