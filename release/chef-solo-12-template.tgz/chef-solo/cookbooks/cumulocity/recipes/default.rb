include_recipe 'cumulocity::users'
include_recipe 'java'
include_recipe 'yum-epel'
#include_recipe 'hostsfile'

%w(
    gcc wget mc 
  ).each do |pkg|
  package pkg do
    action :install
  end
end

execute 'DisableSELinux' do
  action :nothing
  command "/sbin/setenforce 0"
end

service "iptables" do
  action :stop
end

ruby_block "disable SELINUX" do
  block do
    file = Chef::Util::FileEdit.new("/etc/sysconfig/selinux")
    file.search_file_replace_line(/SELINUX=enforcing/,"SELINUX=disabled")
    file.write_file
  end
  not_if { ::File.open('/etc/sysconfig/selinux').read() =~ /SELINUX=disabled/ }
  notifies :run, 'execute[DisableSELinux]', :immediately
end

motd_file = platform?(%w{ubuntu debian}) ? "/etc/motd.tail": "/etc/motd"

template motd_file do
  source "motd.tail.erb"
  group "root"
  owner "root"
  mode "0644"
  backup 0
end

unless node[:roles].include? "cumulocity-kubernetes"
    if node['swapfilesize'] > 0 and node['swapfilename'].length > 1
        swap_file '/swapfile1' do
            size node['swapfilesize']
            persist true
        end
    end
else
    execute "swapoff" do
        action :run
        command "swapoff -a"
    end
end

if node['fixhostname']

  prettyname = node.name + " part of " + node.chef_environment
  staticname = node.name
  fqdname    = node.name + '.' + node['domainname']

  if fqdname.length > 64
    fqdname = node.name + '.c8y.local'
  end

  if node['el7']
    execute 'preserve-static-hostname' do
      action :run
      only_if { File.exists?("/etc/cloud/cloud.cfg") }
      command <<-EOF
        ph="$(fgrep preserve_hostname /etc/cloud/cloud.cfg | cut -d: -f2)"

        if [[ -z ${ph} ]] ; then
          printf "\npreserve_hostname: true\n" >> /etc/cloud/cloud.cfg
        elif [[ "${ph}" ]] ; then
          sed -i "s/preserve_hostname:.*/preserve_hostname: true/g" /etc/cloud/cloud.cfg
        fi
      EOF
    end
    execute 'set-static-hostname' do
      action :run
      environment(
        'prettyname' => prettyname,
        'staticname' => staticname,
        'fqdname'    => fqdname
      )
      command <<-EOF
        hostnamectl set-hostname --pretty "${prettyname}"
        hostnamectl set-hostname --static "${staticname}"
        hostnamectl set-hostname --transient "${fqdname}"
      EOF
    end
  end

  hostsfile_entry '127.0.0.1' do
    hostname "#{fqdname}"
    aliases  ["#{staticname}", 'localhost', 'localhost.localdomain', 'localhost4', 'localhost4.localdomain4']
    action   :update
  end
  hostsfile_entry '::1' do
    hostname "#{fqdname}"
    aliases  ["#{staticname}", 'localhost', 'localhost.localdomain', 'localhost6', 'localhost6.localdomain6']
    action   :update
  end
end

if node['fixhostsfile']
  envNodes = search(:node, "chef_environment:#{node.chef_environment}")
    envNodes.sort! {|n1,n2| n1.name <=> n2.name}
    envNodes.each do |host|
      hostsfile_entry "#{host['ipaddress']}" do
        hostname  "#{host['hostname']}"
        aliases   ["#{host['hostname']}.#{node['domainname']}"]
        comment   "part of #{node.chef_environment} env"
        action    :create
      end
    end
  envNodes = nil
end

if node['dont_run_chef_client'] or File.exists?("/DONTRUNCHEFCLIENT")
  node.default['chef_client']['init_style']  = 'none'
end

unless node['systemd']['ulimits'].nil? or not node['el7']
    DefaultLimitNOFILE = node['systemd']['ulimits']['DefaultLimitNOFILE']
    DefaultLimitNPROC = node['systemd']['ulimits']['DefaultLimitNPROC']
    file "/etc/systemd/system.conf" do
      content "#{::File.open('/etc/systemd/system.conf').read}\nDefaultLimitNOFILE=#{DefaultLimitNOFILE}\nDefaultLimitNPROC=#{DefaultLimitNPROC}\n"
      action :create
      not_if { File.readlines("/etc/systemd/system.conf").grep(/^DefaultLimitNOFILE/).any? }
      not_if { File.readlines("/etc/systemd/system.conf").grep(/^DefaultLimitNPROC/).any? }
      notifies :run, "execute[reexec_systemd]", :immediately
    end
    execute "reexec_systemd" do
      action :nothing
      command "systemctl daemon-reexec"
    end
end

