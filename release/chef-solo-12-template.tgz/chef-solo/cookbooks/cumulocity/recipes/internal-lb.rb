#
# Cookbook Name:: cumulocity-loadbalancer
# Recipe:: default
#
# Copyright 2012, NSN
#
# All rights reserved - Do Not Redistribute
#

package "haproxy"

sqlNodes = []
if not node[:roles].include? "cumulocity-sql-db" and node[:roles].any? {|x| ["cumulocity-common-cores","cumulocity-core","cumulocity-cep-server"].include?(x)}
    sqlNodes = search(:node, "chef_environment:#{node.chef_environment} AND roles:cumulocity-sql-db")
    sqlNodes.sort! {|n1,n2| n1.name <=> n2.name}
end

nosqlNodes = []
nosqlNodes = search(:node, "chef_environment:#{node.chef_environment} AND roles:cumulocity-nosql-db")
if nosqlNodes.length == 0
    if not node[:roles].include? "cumulocity-mongo-standalone"
        nosqlNodes = search(:node, "chef_environment:#{node.chef_environment} AND roles:cumulocity-mongo-standalone")
    end
    nosqlPort = 27017
else
    nosqlPort = 5984
end

coreNodes = []
onTopLBcnt = []
onTopLBcnt = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-ontop-lb")
if onTopLBcnt.length == 0 or onTopLBcnt.length > 1
    if not node[:roles].include? "cumulocity-common-cores" and node[:roles].any? {|x| ["cumulocity-ssagents","cumulocity-cep-server"].include?(x)}
	coreNodes = search(:node, "chef_environment:#{node.chef_environment} AND (role:cumulocity-core OR role:cumulocity-mn-active-core)")
    end
else
    if not node[:roles].include? "cumulocity-common-cores" and ["cumulocity-ssagents"].all? {|x| node[:roles].include?(x)}
	coreNodes = search(:node, "chef_environment:#{node.chef_environment} AND (role:cumulocity-core OR role:cumulocity-mn-active-core)")
    end
end
if coreNodes.length > 0
    coreNodes.sort! {|n1,n2| n1.name <=> n2.name}
end

kubeMasterNodes = []
if not node['cumulocity-kubernetes'].nil?
    kubeMasterNodes = search(:node, "chef_environment:#{node['cumulocity-kubernetes']['deployK8S4env']} AND role:cumulocity-kubernetes AND tags:k8s-master")
end
if kubeMasterNodes.length > 0
    kubeMasterNodes.sort! {|n1,n2| n1.name <=> n2.name}
end

if sqlNodes.length>0 or nosqlNodes.length>0 or coreNodes.length>0 or kubeMasterNodes.length>0
  template "/etc/haproxy/haproxy.cfg" do
	source "internal-lb/haproxy.cfg.erb"
	variables(
    	    :sqlNodes => sqlNodes,
    	    :nosqlNodes => nosqlNodes,
    	    :nosqlPort => nosqlPort,
    	    :coreNodes => coreNodes,
            :kubeMasterNodes => kubeMasterNodes
	    )
    owner "root"
    group "root"
    mode 0644
    notifies :reload, "service[haproxy]"
  end
  service "haproxy" do
    supports :restart => true, :status => true, :reload => true
    action [:enable, :start]
  end
else
    service "haproxy" do
	action [:stop]
    end
end

if node[:roles].any? {|x| ["cumulocity-common-cores","cumulocity-core","cumulocity-cep-server"].include?(x)}
    mongocfgNodes = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-mongo-configsvr")

        if not node['cumulocity-mongo']['members-check'] or ( node['cumulocity-mongo']['members-check'] and mongocfgNodes.length == node['cumulocity-mongo']['total-members'] )
            include_recipe "cumulocity::internal-lb_mongos"
        end
end



