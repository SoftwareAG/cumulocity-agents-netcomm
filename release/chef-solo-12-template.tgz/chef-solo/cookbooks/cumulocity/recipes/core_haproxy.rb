loadbalancers = search(:node, "chef_environment:#{node.chef_environment} AND role:cumulocity-internal-lb")

package "haproxy" do
  action :install
end

if loadbalancers.nil? or loadbalancers.empty?

  log("no loadbalancers - nothing to configure") { level :info }

  service "haproxy" do
    supports :restart => true, :status => true, :reload => true
    action [:stop]
  end

else

  service "haproxy" do
    supports :restart => true, :status => true, :reload => true
    action [:enable, :start]
  end

  log("loadbalancers from search:#{loadbalancers.collect { |lb| lb["ipaddress"] }.join(" ")}") { level :info }

  template "/etc/haproxy/haproxy.cfg" do
    source "haproxy.cfg.erb"
    variables(:loadbalancers => loadbalancers)
    owner "root"
    group "root"
    mode "0644"
    notifies :reload, "service[haproxy]"
  end

end
