include_recipe "yum"
if node['useVaults']
  include_recipe "chef-vault"
end

replicators = []
if node['cumulocity-postgres']['isMasterHotStandby']
    replicators = search(:node,"chef_environment:#{node.chef_environment} AND roles:cumulocity-sql-db")
    replicators.sort! {|n1,n2| n1.name <=> n2.name}
end

loadbalancers = search(:node,"chef_environment:#{node.chef_environment} AND (roles:cumulocity-internal-lb OR roles:cumulocity-external-lb OR roles:cumulocity-cep-server OR roles:cumulocity-kubernetes)")
loadbalancers.sort! {|n1,n2| n1.name <=> n2.name}


yum_repository 'postgresql' do
  description 'postgresql Repository'
  baseurl node['yum']['repositories']['postgres']['url']
  gpgcheck false
  enabled true
  action :create
end

if node['el7']
%w{
  postgresql93
  postgresql93-devel
  postgresql93-server
  postgresql93-libs
  postgresql93-contrib
}.each do |package_name|
  package package_name do
    action :install
  end
end

execute "postgresql db setup" do
  command "/usr/pgsql-9.3/bin/postgresql93-setup initdb"
  action :run
  not_if { File.exists? "#{node['cumulocity-postgres']['data_directory']}/postgresql.conf" }
end
else
%w{
  postgresql91
  postgresql91-devel
  postgresql91-server
  postgresql91-libs
  postgresql91-contrib
}.each do |package_name|
  package package_name do
    action :install
  end
end

execute "/etc/init.d/postgresql-#{node['cumulocity-postgres']['version']} initdb && /etc/init.d/postgresql-#{node['cumulocity-postgres']['version']} start" do
  action :run
  creates "#{node['cumulocity-postgres']['data_directory']}/postgresql.conf"
end

end

service "postgresql-#{node['cumulocity-postgres']['version']}" do
  supports :reload => true, :restart => true, :status => true
  action [:enable, :start]
end

if node['useVaults']
  vault = begin
          chef_vault_item(:secrets, "#{node.chef_environment}.core")
          rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
          nil
  end
end
if node['useVaults']
  rdbmsPass = vault['contextService.rdbmsPassword']
else
  rdbmsPass = node['cumulocity-core']['properties']['contextService.rdbmsPassword']
end

unless File.exists? "#{node['cumulocity-postgres']['data_directory']}/postgresql.conf"

  c8ymnPass = ( node['nagios'].attribute?(:plugins) && node['nagios']['plugins']['check_postgres']['password']>'' && node['cumulocity-postgres']['c8ymonitoring.password']=='') ? node['nagios']['plugins']['check_postgres']['password'] : node['cumulocity-postgres']['c8ymonitoring.password']

  execute "set_postgres_user_password" do
    command "sleep 10 && psql -c \"alter user postgres with password '#{rdbmsPass}';\""
    action :run
    user "postgres"
  end

  execute "set_cumulocity_user_password" do
    command "psql -c \"CREATE ROLE c8ydbadmin with CREATEROLE LOGIN ENCRYPTED PASSWORD '#{node['cumulocity-postgres']['c8ydbadmin.password']}';\""
    action :run
    user "postgres"
  end

  execute "set_monitoring_user_password" do
    command "psql -c \"CREATE ROLE c8ymonitoring with NOSUPERUSER NOCREATEDB CONNECTION LIMIT 3 LOGIN ENCRYPTED PASSWORD '#{c8ymnPass}';\""
    action :run
    user "postgres"
  end

  execute "create_cumulocity_db" do
    command "createdb -O c8ydbadmin cumulocity"
    action :run
    user "postgres"
  end
end

if node['cumulocity-postgres']['isMasterHotStandby']

    tagtab = node.tags

    directory "#{node['cumulocity-postgres']['data_directory']}/pg_archive" do
      action :create
      owner 'postgres'
      group 'postgres'
      mode  0700
    end


    unless  File.exists? "#{node['cumulocity-postgres']['data_directory']}/.cluster.ready"

      if tagtab.include? "HotStandby"
        MasterNode = search(:node,"chef_environment:#{node.chef_environment} AND roles:cumulocity-sql-db AND NOT tags:HotStandby")
        MasterNode.sort! {|n1,n2| n1.name <=> n2.name}

	    template "#{node['cumulocity-postgres']['data_directory']}/recovery._onf" do
	      owner 'postgres'
	      group 'postgres'
	      variables :MasterNode => MasterNode
    	   mode   0600
	      source "postgres/recovery.conf.erb"
	    end

	    template "#{node['cumulocity-postgres']['data_directory']}/pg_basebackup.sh" do
	      owner 'root'
	      group 'root'
        mode   0700
	      variables :MasterNode => MasterNode
	      source "postgres/pg_basebackup.erb"
	    end

	    execute "master_backup" do
	      command "#{node['cumulocity-postgres']['data_directory']}/pg_basebackup.sh"
	      action :run
	      user "root"
	      not_if { File.exist?("#{node['cumulocity-postgres']['data_directory']}/recovery.done")}
	    end

	    template "#{node['cumulocity-postgres']['data_directory']}/failover_detector.sh" do
    	      owner "postgres"
	      group "postgres"
	      mode "0700"
	      variables :MasterNode => MasterNode
	      source "postgres/failover_detector.sh.erb"
	    end
	else
	    execute "set_replication_user_password" do
	      command "export PGPASSWORD=#{rdbmsPass} ; psql -c \"CREATE ROLE replicator with REPLICATION NOSUPERUSER NOCREATEDB CONNECTION LIMIT 5 LOGIN ENCRYPTED PASSWORD '#{node['cumulocity-postgres']['replicator.password']}';\""
	      action :run
	      user "postgres"
	      returns [0, 1]
	    end

	    execute "create_cluster_master_flag" do
	      command "touch #{node['cumulocity-postgres']['data_directory']}/.cluster.ready"
	      action :run
	      user "postgres"
	    end
	end
    else
	execute "rerun_failover_detector" do
	  command "export TMOUT=0 ;bash #{node['cumulocity-postgres']['data_directory']}/failover_detector.sh >#{node['cumulocity-postgres']['failover_log']} 2>&1 &"
	  action :run
	  user "root"
	  only_if { tagtab.include? "HotStandby" }
	  only_if { `pgrep -f "failover_detector.sh"`=="" }
	  not_if { File.exist?("#{node['cumulocity-postgres']['data_directory']}/recovery.done")}
	  only_if { File.exist?("#{node['cumulocity-postgres']['data_directory']}/recovery.conf")}
	end
    end
end

template "#{node['cumulocity-postgres']['data_directory']}/postgresql.conf" do
    source "postgres/postgresql.conf.erb"
    variables :cluster => node['cumulocity-postgres']['isMasterHotStandby']
    mode "0600"
    owner "postgres"
    group "postgres"
    notifies :restart, "service[postgresql-#{node['cumulocity-postgres']['version']}]", :immediately
end

extraNodesIPs = node.default['cumulocity-postgres']['extraHostsAccess']
if not node['cumulocity-kubernetes'].nil? and not node['cumulocity-kubernetes']['deployK8S4env'].nil?
    KubeNodesfromOtherEnv = search(:node,"chef_environment:#{node['cumulocity-kubernetes']['deployK8S4env']} AND roles:cumulocity-kubernetes")
end

template "#{node['cumulocity-postgres']['data_directory']}/pg_hba.conf" do
    source "postgres/pg_hba.conf.erb"
    variables(	:loadbalancers => loadbalancers,
                :extraNodesIPs => extraNodesIPs,
                :KubeNodesfromOtherEnv => KubeNodesfromOtherEnv,
                :replicators => replicators)
    mode "0600"
    owner "postgres"
    group "postgres"
    notifies :reload, "service[postgresql-#{node['cumulocity-postgres']['version']}]", :immediately
end
