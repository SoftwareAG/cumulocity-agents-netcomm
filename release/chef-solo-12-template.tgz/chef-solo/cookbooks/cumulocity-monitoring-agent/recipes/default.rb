#
# Cookbook Name:: cumulocity-agent
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

include_recipe "yum"
if node['useVaults']
  include_recipe "chef-vault"
end

if node['el7']
  plugin_dir = node['monitoring-agent']['plugin_dir']
  remote_directory node['monitoring-agent']['plugin_dir'] do
    source "plugins"
    owner "root"
    group "root"
    mode 0755
    files_mode 0755
  end

else
  plugin_dir = node['nagios']['plugin_dir']
end

yum_repository 'cumulocity' do
  description 'cumulocity Repository'
  baseurl node['yum']['repositories']['cumulocity']['url']
  gpgcheck false
  enabled true
  action :create
end

package "cumulocity-agent" do
  version node['monitoring-agent']['rpm_version']
  action :install
end

service "cumulocity-agent" do
  action [:enable, :start]
end

if node['useVaults']
  vault_extra = begin
      chef_vault_item(:secrets, "#{node.chef_environment}.extra")
      rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
      nil
  end
  tenantUsers = vault_extra['monitoring-agent']['tenants']
else
  tenantUsers = node['monitoring-agent']['tenants']
end

if tenantUsers.nil?
  Chef::Application.fatal!( "mongodbInitPass is nil", 230 )
end

mongoPriRs = []
mongoSecRs = []

if node.roles.include? 'cumulocity-kubernetes' and node.tags.include? "k8s-master"
  package "jq" do
    action :install
  end
end

if node.roles.include? 'cumulocity-mongo'
  package "python-pip" do
    action :install
  end

  execute "update_pymongo" do
    command "pip install --upgrade pymongo && touch /usr/share/cumulocity-agent/.pymongoUpdated"
    not_if { File.exists?('/usr/share/cumulocity-agent/.pymongoUpdated') }
  end

  if node['useVaults']
    vault_core = begin
        chef_vault_item(:secrets, "#{node.chef_environment}.core")
        rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
        nil
    end
  end

  mongodbAdmn = node['cumulocity-core']['properties']['mongodb.admindb']
  mongodbInitUser = node['cumulocity-mongo']['mongodb.initUser']
  mongodbMonitorUser = node['monitoring-agent']['mongodb.monitorUser']
  if node['useVaults']
    mongodbInitPass = vault_core['mongodb.initPassword']
    mongodbMonitorPass = vault_extra['monitoring-agent']['mongodb.monitorPassword']
  else
    mongodbInitPass = node['cumulocity-mongo']['mongodb.initPassword']
    mongodbMonitorPass = node['monitoring-agent']['mongodb.monitorPassword']
  end

  if mongodbInitPass.nil?
    Chef::Application.fatal!( "mongodbInitPass is nil", 254 )
  end

  if mongodbMonitorPass.nil?
    Chef::Application.fatal!( "mongodbMonitPass is nil", 240 )
#    mongodbMonitorPass = node['monitoring-agent']['mongodb.monitorPassword']
  end

  if node.tags.count > 0
    if node.tags.grep(/replicaset:.+:P$/).length > 0
      mongoPriRs << node.tags.grep(/replicaset:.+:P$/)[0].split(":")[1]
      rsPriPort = "2701" + mongoPriRs[0].split('').last

      template "/usr/share/cumulocity-agent/mongodb_create.nagios-mon.sh" do
        source "mongodb_create.nagios-mon.sh.erb"
        mode   "0770"
        owner  "root"
        group  "root"
        notifies :restart, "service[cumulocity-agent]"
        variables( :rsPriPort => rsPriPort,
                   :mongodbAdmn => mongodbAdmn,
                   :mongodbInitUser => mongodbInitUser,
                   :mongodbInitPass => mongodbInitPass,
                   :mongodbMonitorUser => mongodbMonitorUser,
                   :mongodbMonitorPass => mongodbMonitorPass
                 )
      end

      execute 'createMonitorMongoDbUser' do
        command '/usr/share/cumulocity-agent/mongodb_create.nagios-mon.sh'
        only_if { File.exists?('/usr/share/cumulocity-agent/mongodb_create.nagios-mon.sh') }
        not_if { File.exists?('/usr/share/cumulocity-agent/.mongoUserCreated') }
        action :run
      end

    end
    if node.tags.grep(/replicaset:.+:S$/).length > 0
      mongoSecRs << node.tags.grep(/replicaset:.+:S$/)[0].split(":")[1]
    end
  end

end

fsToCheck = node['monitoring-agent']['fs_to_check']

template "/usr/share/cumulocity-agent/lua/monitoring/plugins.lua" do
  source "plugins.lua.erb"
  mode   "0644"
  owner  "root"
  group  "root"
  notifies :restart, "service[cumulocity-agent]"
  variables( :plugin_dir => plugin_dir,
             :fsToCheck => fsToCheck,
             :mongoPriRs => mongoPriRs,
             :mongoSecRs => mongoSecRs,
             :mongodbMonitorUser => mongodbMonitorUser,
             :mongodbMonitorPass => mongodbMonitorPass
           )
end

template "/usr/share/cumulocity-agent/lua/monitoring/hosts.lua" do
  source "hosts.lua.erb"
  mode   "0644"
  owner  "root"
  group  "root"
  notifies :restart, "service[cumulocity-agent]"
  variables( :tenantUsers => tenantUsers,
             :plugin_dir => plugin_dir,
             :fsToCheck => fsToCheck,
             :mongoPriRs => mongoPriRs,
             :mongoSecRs => mongoSecRs,
             :mongodbMonitorUser => mongodbMonitorUser,
             :mongodbMonitorPass => mongodbMonitorPass
           )
end

template "/usr/share/cumulocity-agent/cumulocity-agent.conf" do
  source "cumulocity-agent.conf.erb"
  mode   "0644"
  owner  "root"
  group  "root"
  notifies :restart, "service[cumulocity-agent]"
  variables( :plugin_dir => plugin_dir )
end

