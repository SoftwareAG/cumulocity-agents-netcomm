name             'cumulocity-monitoring-agent'
maintainer       'Cumulocity GmbH'
maintainer_email 'you@example.com'
license          'All rights reserved'
description      'Installs/Configures cumulocity-monitoring-agent'
long_description 'Installs/Configures cumulocity-monitoring-agent'
version          '1.0.1'

