if node['el7']
  default['monitoring-agent']['rpm_version'] = "0.6.5-1"
else
  default['monitoring-agent']['rpm_version'] = "0.4.1-1"
end
default['monitoring-agent']['server_url'] = "http://monitor.c8y.io"

default['monitoring-agent']['plugin_dir'] = "/usr/share/cumulocity-agent/plugins"

default['monitoring-agent']['fs_to_check'] = [ "ext4", "xfs", "rootfs" ]

# MONGODB
default['monitoring-agent']['mongodb.monitorUser'] = "nagios-mon"

# credentials for monitoring agent
default['monitoring-agent']['platformUser'] = "monitoring-agent"

# FOLLOWING FEATURE NOT YET AVAILABLE
# add  credentials for other tenants in this format (better in vault):
#default['monitoring-agent']['tenants']['<tenant>']['username'] = "<password>"
