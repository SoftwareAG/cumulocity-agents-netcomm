#!/usr/bin/env python2

import json
import sys

import requests

import createAlarmsFromGpio as ga


netcommDeviceId = '30439559'
auth = requests.auth.HTTPBasicAuth('scriptUser', 'resUtpircs')
pushUrl = 'http://c8ytest.cumulocity.com/devicecontrol/operations/'
headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}


def getStatus(deviceId):
    data = {'deviceId': deviceId, 'description': 'Generalabfrage',
            'c8y_MeasurementRequestOperation': {'requestName': 'LOG'}}
    return requests.post(pushUrl, data=json.dumps(data), auth=auth,
                         headers=headers).json()


op = getStatus(netcommDeviceId)
c, t = ga.verifyOperation(op['id'], 40)
if c:
    print('CRITICAL - failed to get status report')
    sys.exit(2)
else:
    print('OK - got status report in {0} s | time={1}'.format(t, t))
    sys.exit(0)
