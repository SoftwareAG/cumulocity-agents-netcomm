#!/bin/bash

FOLDER=$1
FILETYPE=$2
OLDERTHAN=$3

RESULT=`find ${FOLDER} -name "${FILETYPE}" -type f -mmin +${OLDERTHAN} |wc -l`

if [[ $RESULT -eq 0 ]]; then
    CHECK="OK"
else
    CHECK="Failed"
fi

if [[ "$CHECK" == "OK" ]]; then
  echo "SERVICE OK"
  exit 0
elif [[ "$CHECK" == "Failed" ]]; then
  echo "${RESULT} files in ${FOLDER}"
  exit 2
else
  echo "Check failed"
  exit 3
fi
