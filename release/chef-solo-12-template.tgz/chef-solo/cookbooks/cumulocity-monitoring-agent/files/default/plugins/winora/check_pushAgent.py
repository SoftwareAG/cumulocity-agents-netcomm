#!/usr/bin/env python2
import requests
import os
import sys
import json
import string
import random

host = 'https://winora.cumulocity.com'
tenant = 'winora'
authUsername = 'monitoringUser'
authPassword = 'PQE85yGqVN'
auth = requests.auth.HTTPBasicAuth(tenant + '/' + authUsername, authPassword)

bikeAssetHash = 'monitorBikeAssetHashKBbkf'
bikeId = ''
selfRegisterUsername = 'selfRegisterMonitorUserGjth'

def registerBike() :

	file = {
	'file': ( 'devices.csv',
	 'ID;CREDENTIALS;TYPE;NAME;IDTYPE\n'
	 + bikeAssetHash +';' 
	 + ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(8)) +';type-of-device;testDevice;c8y_AssetHash', 
	 'text/csv')
	}

	uploadResp = requests.post(host + '/devicecontrol/bulkNewDeviceRequests', auth=auth, files=file, headers={'Accept': 'application/json'})

	if uploadResp.json()['numberOfCreated'] != 1 :
		print 'CRITICAL - Bike could not created with bulk registration'
		return 2
	return 0

def verifyBike() :
	global bikeId

	getResp = requests.get(host + '/identity/externalIds/c8y_AssetHash/' + bikeAssetHash,
		auth = auth)
	if getResp.status_code == 404 :
		print 'CRITICAL - Registered bike not found'
		return 2

	bikeId = getResp.json()['managedObject']['id']

	return 0

def registerUser() :

	data = {
		'username':selfRegisterUsername, 
		'email':'monitorEmailXdjh13@cumulocity.com', 
		'assetHash':bikeAssetHash, 
		'firstName':selfRegisterUsername, 
		'language':'en',
		'applicationKey':'de.haibike.eConnect',
		'Devices': [{
		  'PushID':'35740062-6bb2-423f-bb04-8d09f5731bec',
		  'OS':'Android',
		  'Version': '5.1.1'
		}]
	}

	registerUserResp = requests.post(host + '/service/user-registration/selfregistrations', 
		auth=auth, data=json.dumps(data), headers={'Content-Type':'application/json'})

	if registerUserResp.status_code > 299 :
		print 'CRITICAL - Registration of user is not successful. ' + registerUserResp.text
		return 2
	return 0
	
def verifyUser() :
	getResp = requests.get(host + '/user/' + tenant + '/users/' + selfRegisterUsername, 
		auth=auth)

	if getResp.status_code == 404 :
		print 'CRITICAL - Registered user not found'
		return 2
	return 0

def deleteBike() :

	def deleteDeviceUser() :
		deleteResp = requests.delete(host + '/user/' + tenant + '/users/device_' + bikeAssetHash, 
			auth = auth)

		if deleteResp.status_code > 299 :
			print 'CRITICAL - Deletion of device user is not successful. ' + deleteResp.text
			return 2
		return 0

	def deleteInventoryDevice() :
		deleteResp = requests.delete(host + '/inventory/managedObjects/' + bikeId, 
			auth = auth)

		if deleteResp.status_code > 299 :
			print 'CRITICAL - Deletion of inventory device is not successful'
			return 2
		return 0

	if len(bikeId) > 0 and  len(bikeAssetHash) > 0:

		exitCode = 0
		exitCode += deleteDeviceUser()
		exitCode += deleteInventoryDevice()
		return exitCode
		
	else :
		print 'CRITICAL - BikeId is not valid'
		return 2

def pushMessage() :
	data = {
		'providerType': 'TELEKOM',
		'message': 'Test Message',
		'deviceId': bikeId,
		'customProperties': {
		  'type': "c8y_Theft",
		  'source' : bikeId,
		  'id' : '1'
		}
	}

	pushResp = requests.post(host + '/service/push/push', auth=auth, data=json.dumps(data), headers={'Content-Type':'application/json'})

	if pushResp.status_code > 299 :
		print 'CRITICAL - Push request is not successful. ' + pushResp.text
		return 2
	return 0


exitCode = 0

registerBike()
exitCode += verifyBike()
if exitCode > 0 :
	sys.exit(2)

exitCode += registerUser()
exitCode += verifyUser()

if exitCode == 0 :
	exitCode += pushMessage()
else :
	print 'INFO - Could not prepare the device or the user. Skipping push service test'

exitCode += deleteBike()

if exitCode > 0 :
	sys.exit(2)
else :
	print 'OK'
	sys.exit(0)
