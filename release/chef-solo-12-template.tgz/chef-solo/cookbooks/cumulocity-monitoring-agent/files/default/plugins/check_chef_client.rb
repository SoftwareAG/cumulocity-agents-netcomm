#!/usr/bin/env ruby

require 'rubygems'
require 'json'
require 'time'
require File.dirname(__FILE__) + '/nagios_helper'
require File.dirname(__FILE__) + '/knife_helper'

include NagiosHelper
include KnifeHelper

def check(nodename, warning_level, critical_level)
  unless File.exists?(File.join(File.dirname(__FILE__),".chef","knife.rb"))
    unknown "Cannot find knife configuration." 
  end
  knife_result = run_knife_and_parse "node show #{nodename} -a ohai_time -F json"
  last_checkin = knife_result["ohai_time"].to_i
  now = Time.now.to_i
  time_diff = now - last_checkin
  if time_diff > critical_level
    critical message(time_diff)
  end
  if time_diff > warning_level
    warning message(time_diff)
  end
  puts "OK: #{message(time_diff)}"
end

def message(seconds)
  "Last check-in #{seconds} seconds ago"
end

if __FILE__ == $0

  unless ARGV.size == 3
    unknown "Wrong number of parameters passed. Usage: #{File.basename(__FILE__)} NODENAME warning critical"
  end

  nodename = ARGV[0]
  warning_level = ARGV[1].to_i
  critical_level = ARGV[2].to_i
  check(nodename, warning_level, critical_level)
end
