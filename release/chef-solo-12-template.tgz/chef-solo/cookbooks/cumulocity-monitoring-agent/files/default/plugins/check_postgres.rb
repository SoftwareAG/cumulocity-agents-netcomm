#!/usr/bin/env ruby

require 'rubygems'
require 'thor'
require 'json'
require 'time'
require 'pg'
require File.dirname(__FILE__) + '/nagios_helper'

class CheckPostgresCluster < Thor
  include NagiosHelper

  desc "replication", "Checks if replication is working on postgres cluster."
  method_option :host, :type => :string, :default => "127.0.0.1", :aliases => "-h", :desc => "Host"
  method_option :port, :type => :string, :default => "5432", :aliases => "-p", :desc => "Port"
  method_option :user, :type => :string, :default => "postgres", :aliases => "-u", :desc => "User"
  method_option :password, :type => :string, :required => true, :aliases => "-P", :desc => "Password"
  method_option :database, :type => :string, :default => "postgres", :aliases => "-d", :desc => "Database name"
  def replication()
    begin
        conn = PG.connect( :host => options.host, :port => options.port, :dbname => options.database, :user => options.user, :password => options.password)
    rescue PGError
        critical "Connection to (host=#{options.host}, port=#{options.port}, user=#{options.user}, database=#{options.database}) failed!"
    end
    ok "SLAVE, XLOG POS: " + standby_xlog_position(conn) if is_standby(conn)      
    check_replication_data_on_master(get_replication_data(conn), conn)
  end
  
  private
  def check_replication_data_on_master(replication_data, master_conn)
    replication_problem_msg = ""
    sync_exists = false
    replication_data.each do |row|
      if (row['sync_state'] != "sync")
        replication_problem_msg << "Replication sync state with #{row['client_addr']} is #{row['sync_state']}. "
      else
        sync_exists = true
      end
    end
    
    if (replication_problem_msg.empty?)
      ok "Replication on MASTER, XLOG POS: " + master_xlog_position(master_conn)
    else
      if (sync_exists)
        warning replication_problem_msg
      else
        critical replication_problem_msg        
      end
    end
  end
  
  def is_standby(conn)
    res  = conn.exec('select pg_is_in_recovery()')
    if (res.num_tuples() != 1)
      unknown "Problem with checking if node is master or standby, can not retrieve data from pg_is_in_recovery"
    else
      res.getvalue(0, 0) == 't'
    end
  end
 
  def get_replication_data(master_conn)
    replication_data  = master_conn.exec('select client_addr, sync_state from pg_stat_replication')
    if (replication_data.num_tuples() == 0)
      critical "Replication FAILED on MASTER, pg_stat_replication data empty"
    end
    return replication_data
  end

  # The following methods are not currenlty used, they could be used in the feature to implement checking of 
  # difference of xlog location between master and slave.
  def wal_location_2_bytes(location)
    if (location != nil)
      split_location = location.split("/")
      if (split_location.size == 2)
        return (( Integer("0x" + split_location[0]) * 16 * 1024 * 1024 * 255) + Integer("0x" + split_location[1]))
      end
    end
    return nil
  end
  
  def count_delay(master_conn, standby_conn)
    current_xlog_location  = wal_location_2_bytes(master_xlog_position(master_conn))
    last_xlog_receive_location  = wal_location_2_bytes(standby_xlog_position(standby_conn))
    if (current_xlog_location != nil && last_xlog_receive_location != nil)
      return (current_xlog_location - last_xlog_receive_location).to_s() + " bytes"
    else
      return "unknown"
    end
  end
  
  def master_xlog_position(master_conn)
    return master_conn.exec('select pg_current_xlog_location()').getvalue(0,0)
  end
  
  def standby_xlog_position(standby_conn)
    return standby_conn.exec('select pg_last_xlog_receive_location()').getvalue(0,0)
  end
  
end
CheckPostgresCluster.start
