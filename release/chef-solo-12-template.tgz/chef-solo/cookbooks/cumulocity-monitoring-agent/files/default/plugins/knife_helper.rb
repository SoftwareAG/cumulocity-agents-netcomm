require 'rubygems'
require 'chef/node'
require 'json'

module KnifeHelper
  def run_knife(command)
    `cd #{File.dirname(__FILE__)} && sudo knife #{command} 2>&1`
  end

  def run_knife_and_parse(command)
    JSON.parse(run_knife(command))
  end
end

