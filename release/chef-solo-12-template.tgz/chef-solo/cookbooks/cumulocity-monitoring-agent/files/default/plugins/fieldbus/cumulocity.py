#!/usr/bin/env python

import base64, httplib, json, time
from datetime import datetime

class CumulocityClient:

  def __init__(self, host, tenant, user, password, modbusDeviceId):
    self.host = host
    self.credentials = 'Basic ' + base64.b64encode(tenant + '/' + user + ':'+ password)
    self.connection = httplib.HTTPConnection(host+':80')
    self.modbusDeviceId = modbusDeviceId

  def clearAllAlarms(self):
    self.connection.request('GET', '/alarm/alarms?status=ACTIVE&pageSize=50&source=' + self.modbusDeviceId, '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    for alarm in jsonResponse['alarms']:
      self.connection.request('PUT', '/alarm/alarms/' + alarm['id'], json.dumps({'status': 'CLEARED'}), {'Authorization': self.credentials, 'Content-Type': 'application/json'})
      response = self.connection.getresponse().read()
      self.connection.close()

  def getActiveAlarms(self):
    self.connection.request('GET', '/alarm/alarms?status=ACTIVE&pageSize=50&source=' + self.modbusDeviceId, '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['alarms']

  def getEventsForTime(self, dateFrom, dateTo):
    self.connection.request('GET', '/event/events?pageSize=50&source=' + self.modbusDeviceId + '&dateFrom=' + self.getISODateString(dateFrom) + '&dateTo=' + self.getISODateString(dateTo), '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['events']

  def getEventsForSourceAndTime(self, source, dateFrom, dateTo):
    self.connection.request('GET', '/event/events?pageSize=50&source=' + source + '&dateFrom=' + self.getISODateString(dateFrom) + '&dateTo=' + self.getISODateString(dateTo), '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['events']

  def getEventsForTimeAndType(self, dateFrom, dateTo, type):
    self.connection.request('GET', '/event/events?pageSize=2000&dateFrom=' + self.getISODateString(dateFrom) + '&dateTo=' + self.getISODateString(dateTo) + '&type=' + type, '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['events']

  def createAlarm(self, type, text):
    alarm = {
	  'source': {'id': self.modbusDeviceId},
      'type': type,
      'text': text,
      'severity': 'MAJOR',
      'status': 'ACTIVE',
      'time': self.getISODateString(time.gmtime())
    }
    self.connection.request('POST', '/alarm/alarms', json.dumps(alarm), {'Authorization': self.credentials, 'Content-Type': 'application/json', 'Accept': 'application/json'})
    response = self.connection.getresponse().read()
    self.connection.close()

  def createEvent(self, type, text, deviceId, data=None):
    event = {
    'source': {'id': deviceId},
      'type': type,
      'text': text,
      'time': self.getISODateString(time.gmtime())
    }
    if data is not None:
      event.update(data)
    self.connection.request('POST', '/event/events', json.dumps(event), {'Authorization': self.credentials, 'Content-Type': 'application/json', 'Accept': 'application/json'})
    response = self.connection.getresponse().read()
    self.connection.close()

  def clearAlarm(self, alarmId):
    self.connection.request('PUT', '/alarm/alarms/' + alarmId, json.dumps({'status': 'CLEARED'}), {'Authorization': self.credentials, 'Content-Type': 'application/json'})
    response = self.connection.getresponse().read()
    self.connection.close()

  def setCoilRequest(self, address, coil, value):
    operation = {
      'description': 'Update coil',
      'c8y_SetCoil': {'address': address, 'coil': coil, 'value': value},
      'deviceId': self.modbusDeviceId
    }
    self.connection.request('POST', '/devicecontrol/operations' , json.dumps(operation), {'Authorization': self.credentials, 'Content-Type': 'application/json'})
    response = self.connection.getresponse().read()
    self.connection.close()

  def setRegisterRequest(self, address, register, startBit, bitCount, value):
    operation = {
      'description': 'Update register',
      'c8y_SetRegister': {'address': address, 'register': register, 'startBit': startBit, 'noBits': bitCount, 'value': value},
      'deviceId': self.modbusDeviceId
    }
    self.connection.request('POST', '/devicecontrol/operations' , json.dumps(operation), {'Authorization': self.credentials, 'Content-Type': 'application/json'})
    response = self.connection.getresponse().read()
    self.connection.close()

  def updateDeviceProperty(self, key, value):
    mo = {
      key: value
    }
    self.connection.request('PUT', '/inventory/managedObjects/' + self.modbusDeviceId,  json.dumps(mo) , {'Authorization': self.credentials, 'Content-Type': 'application/json', 'Accept': 'application/json'})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse

  def getModbusDevice(self):
    self.connection.request('GET', '/inventory/managedObjects/' + self.modbusDeviceId, '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse

  def getMeasurementsForFragmentTypeAndTime(self, fragmentType, dateFrom, dateTo):
    self.connection.request('GET', '/measurement/measurements?pageSize=50&source=' + self.modbusDeviceId + '&dateFrom=' +
      self.getISODateString(dateFrom) + '&dateTo=' + self.getISODateString(dateTo) + '&fragmentType=' + fragmentType,
      '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['measurements']

  def getMeasurementsForSourceAndTime(self, source, dateFrom, dateTo):
    self.connection.request('GET', '/measurement/measurements?pageSize=50&source=' + source + '&dateFrom=' + self.getISODateString(dateFrom) + '&dateTo=' + self.getISODateString(dateTo), '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['measurements']

  def getMeasurementsForSourceAndTimeWithoutEnd(self, source, dateFrom):
    self.connection.request('GET', '/measurement/measurements?pageSize=50&source=' + source + '&dateFrom=' + self.getISODateString(dateFrom), '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['measurements']


  def getISODateString(self, dt):
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', dt)

  def getISODate(self, dt):
    return datetime.strptime(dt, '%Y-%m-%dT%H:%M:%SZ')

  def getPendingOperations(self, id):
    self.connection.request('GET', '/devicecontrol/operations?status=PENDING&deviceId=' + id , '', {'Authorization': self.credentials})
    response = self.connection.getresponse()
    responseBody = response.read()
    self.connection.close()
    if response.status > 299:
      return None
    return json.loads(responseBody)['operations']

  def failOperation(self, id):
    body = {
      'status': 'FAILED'
    }
    self.connection.request('PUT', '/devicecontrol/operations/' + id , json.dumps(body), {'Authorization': self.credentials})
    response = self.connection.getresponse()
    responseBody = response.read()
    self.connection.close()

  def getNewDeviceRequest(self, id):
    self.connection.request('GET', '/devicecontrol/newDeviceRequests/' + id , '', {'Authorization': self.credentials})
    response = self.connection.getresponse()
    responseBody = response.read()
    self.connection.close()
    if response.status > 299:
      return None
    return json.loads(responseBody)

  def createNewDeviceRequest(self, id):
    body = {
      'id': id
    }
    self.connection.request('POST', '/devicecontrol/newDeviceRequests' , json.dumps(body), {'Authorization': self.credentials, 'Content-Type': 'application/json'})
    response = self.connection.getresponse().read()
    self.connection.close()

  def deleteNewDeviceRequest(self, id):
    self.connection.request('DELETE', '/devicecontrol/newDeviceRequests/' + id , '', {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    self.connection.close()

  def acceptNewDeviceRequest(self, id):
    body = {
      'status': 'ACCEPTED'
    }
    self.connection.request('PUT', '/devicecontrol/newDeviceRequests/' + id , json.dumps(body), {'Authorization': self.credentials, 'Content-Type': 'application/json'})
    response = self.connection.getresponse().read()
    self.connection.close()

  def getManagedObjectsByType(self, type):
    self.connection.request('GET', '/inventory/managedObjects?pageSize=2000&type=' + type, '', {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse['managedObjects']

  def getExternalId(self, type, id):
    self.connection.request('GET', '/identity/externalIds/' + type + '/' + id, '', {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse

  def deleteManagedObject(self, id):
    self.connection.request('DELETE', '/inventory/managedObjects/' + id, '', {'Authorization': self.credentials})
    response = self.connection.getresponse()
    print response.status
    response.read()
    self.connection.close()

  def getManagedObject(self, id):
    self.connection.request('GET', '/inventory/managedObjects/' + id, '' , {'Authorization': self.credentials})
    response = self.connection.getresponse().read()
    jsonResponse = json.loads(response)
    self.connection.close()
    return jsonResponse
