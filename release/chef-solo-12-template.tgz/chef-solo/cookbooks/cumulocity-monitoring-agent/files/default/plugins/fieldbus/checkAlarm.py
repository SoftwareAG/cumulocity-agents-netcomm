#!/usr/bin/env python

import sys
from cumulocity import CumulocityClient
from datetime import datetime, timedelta
'''
--------------------------------------
Configuration
--------------------------------------
'''
if len(sys.argv) != 8:
  print 'Expecting 7 parameters <host> <tenant> <username> <password> <deviceId> <alarmTypePrefix> <requiredTestInterval>'
  print 'e.g. python fielbusTests.py integration.cumulocity.com testtenant admin mypassword 12345 myPrefix 20'
  sys.exit()

host = sys.argv[1]
tenant = sys.argv[2]
username = sys.argv[3]
password = sys.argv[4]
deviceId = sys.argv[5] # The id of the device to check alarms on
alarmTypePrefix = sys.argv[6]
requiredTestInterval = int(sys.argv[7])
'''
--------------------------------------
'''

def checkForAlarm():
  client = CumulocityClient(host, tenant, username, password, deviceId)
  mo = client.getModbusDevice()
  lastExecution = client.getISODate(mo[alarmTypePrefix]['lastExecution'])
  testsRun = mo[alarmTypePrefix]['testsExecuted']
  wasSuccessful = mo[alarmTypePrefix]['successful']
  if wasSuccessful:
    if datetime.utcnow() - lastExecution < timedelta(minutes = requiredTestInterval):
      print 'OK - ' + str(testsRun) + ' tests passed.'
      sys.exit(0)
    else:
      print 'WARNING - last test execution was more than ' + str(requiredTestInterval) + ' ago.'
      sys.exit(1)
  else:
    alarms = client.getActiveAlarms()
    testsFailed = buildTestsFailed(alarms)
    print 'CRITICAL - failures in tests: ' + testsFailed
    sys.exit(2)

def buildTestsFailed(alarms):
  testsFailed = ''
  for alarm in alarms:
    if alarm['type'].startswith(alarmTypePrefix):
      testsFailed += ', '
      testsFailed += alarm['type'][len(alarmTypePrefix)+1:]
  if len(testsFailed) > 2:
    return testsFailed[2:]
  else:
    return testsFailed

checkForAlarm()
