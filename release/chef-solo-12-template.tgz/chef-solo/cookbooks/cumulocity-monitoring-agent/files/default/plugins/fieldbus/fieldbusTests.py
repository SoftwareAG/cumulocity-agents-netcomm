#!/usr/bin/env python

import unittest, sys, time, traceback
from pymodbus.transaction import *
from pymodbus.server.async import StartTcpServer
from pymodbus.server.async import ModbusServerFactory
from pymodbus.datastore import ModbusSequentialDataBlock
from pymodbus.datastore import ModbusSlaveContext, ModbusServerContext
from twisted.internet import reactor
from time import sleep
from cumulocity import CumulocityClient
from datetime import datetime

'''
--------------------------------------
Configuration
--------------------------------------
'''
if len(sys.argv) != 8:
  print('Expecting 7 parameters <host> <tenant> <username> <password> <modbusDeviceId> <reportingDeviceId> <modbusPort>')
  print('e.g. python fielbusTests.py integration.cumulocity.com testtenant admin mypassword 12345 23456 502')
  sys.exit()

host = sys.argv[1]
tenant = sys.argv[2]
username = sys.argv[3]
password = sys.argv[4]
modbusDeviceId = sys.argv[5] # The id of the modbus child device
reportingDeviceId = sys.argv[6] # The id of the device where alarm reports are posted
modbusPort = int(sys.argv[7])
'''
--------------------------------------
'''



class FieldbusTests(unittest.TestCase):

  @classmethod
  def setUpClass(self):
    global tenant, username, password, modbusDeviceId
    global context
    self.client = CumulocityClient(host, tenant, username, password, modbusDeviceId)
    context[0x00].setValues(1, 0, [0]*100)
    context[0x00].setValues(2, 0, [0]*100)
    context[0x00].setValues(3, 0, [0]*100)
    context[0x00].setValues(4, 0, [0]*100)
    # clear all alarms of the device before continuing
    self.client.clearAllAlarms()
    sleep(15)

  @classmethod
  def tearDownClass(self):
    # shutdown modbus server after test cases are finished
    reactor.stop()

  def setUp(self):
    self.client.clearAllAlarms()

  def test_changeCoilValueToRaiseAlarmAndCheckMO(self):
    global context
    context[0x00].setValues(1, 2, [1])
    sleep(15)
    alarms = self.client.getActiveAlarms()
    self.assertEquals(len(alarms), 1)
    mo = self.client.getModbusDevice()
    coilValue = mo['c8y_CoilStatus']['RaiseAlarmOutput']
    self.assertEquals(int(coilValue), 1)

  def test_updateCoilFromCumulocity(self):
    global context
    self.client.setCoilRequest(1,2,1)
    value = None
    for i in range(15):
      value = context[0x00].getValues(1,1,1)
      if value[0] == 1:
        break
      time.sleep(1)
    self.assertEquals(value[0], 1)

  def test_updateRegisterFromCumulocity(self):
    global context
    self.client.setRegisterRequest(1,2,0,16,60)
    value = None
    for i in range(20):
      value = context[0x00].getValues(3,1,1)
      if (value[0] == 60):
        break
      time.sleep(1)
    self.assertEquals(value[0], 60)

  def test_changeInputRegisterToCreateMeasurement(self):
    global context
    context[0x00].setValues(4, 3, [10])
    dateFrom = time.gmtime()
    sleep(20)
    dateTo = time.gmtime()
    measurements = self.client.getMeasurementsForFragmentTypeAndTime('c8y_InputRegisterMeasurement',dateFrom,dateTo)
    self.assertGreater(len(measurements), 0)
    atLeastOneMeasurementCorrect = False
    for measurement in measurements:
      value = measurement['c8y_InputRegisterMeasurement']['m']['value']
      if value == 10:
        atLeastOneMeasurementCorrect = True
        break
    self.assertTrue(atLeastOneMeasurementCorrect)

  def test_changeHoldingRegisterValueToRaiseAlarmAndExpectClearing(self):
    global context
    context[0x00].setValues(3, 2, [0x8000])
    sleep(15)
    alarms = self.client.getActiveAlarms()
    self.assertEquals(len(alarms), 1)

    context[0x00].setValues(3, 2, [0])
    sleep(15)
    alarms = self.client.getActiveAlarms()
    self.assertEquals(len(alarms), 0)

  def test_validateRegisterConversion(self):
    global context
    context[0x00].setValues(3, 3, [1024])
    sleep(15)
    mo = self.client.getModbusDevice()
    registerValue = mo['c8y_RegisterStatus']['HoldingRegisterWithConversion']
    self.assertEquals(float(registerValue), 20.48)

  def test_changeInputRegisterValueToRaiseAlarmAndExpectClearing(self):
    global context
    context[0x00].setValues(4, 2, [0x0001])
    sleep(15)
    alarms = self.client.getActiveAlarms()
    self.assertEquals(len(alarms), 1)

    context[0x00].setValues(4, 2, [0])
    sleep(15)
    alarms = self.client.getActiveAlarms()
    self.assertEquals(len(alarms), 0)

  def test_changeCoilValueToCreateEvent(self):
    global context
    dateFrom = time.gmtime()
    context[0x00].setValues(1, 4, [1])
    sleep(15)
    events = self.client.getEventsForTime(dateFrom, time.gmtime())
    self.assertEquals(len(events), 1)

  def test_changeDiscreteInputValueToCreateEvent(self):
    global context
    dateFrom = time.gmtime()
    context[0x00].setValues(2, 4, [1])
    sleep(15)
    events = self.client.getEventsForTime(dateFrom, time.gmtime())
    self.assertEquals(len(events), 1)

  def test_changeHoldingRegisterValueToCreateEvent(self):
    global context
    dateFrom = time.gmtime()
    context[0x00].setValues(3, 4, [1])
    sleep(15)
    events = self.client.getEventsForTime(dateFrom, time.gmtime())
    self.assertEquals(len(events), 1)

  def test_changeInputRegisterValueToCreateEvent(self):
    global context
    dateFrom = time.gmtime()
    context[0x00].setValues(4, 4, [1])
    sleep(15)
    events = self.client.getEventsForTime(dateFrom, time.gmtime())
    self.assertEquals(len(events), 1)

  def test_validateSignedRegisterConversion(self):
    global context
    context[0x00].setValues(3, 5, [0xFFFF])
    sleep(15)
    mo = self.client.getModbusDevice()
    registerValue = mo['c8y_RegisterStatus']['SignedHoldingRegister']
    self.assertEquals(int(float(registerValue)), -1)

  def test_validatePartialSignedRegisterConversion(self):
    global context
    context[0x00].setValues(4, 5, [0x00FF])
    sleep(15)
    mo = self.client.getModbusDevice()
    registerValue = mo['c8y_RegisterStatus']['SignedInputRegisterFirst8Bits']
    self.assertEquals(int(float(registerValue)), -1)

  def test_changeAlarmEventRegisterToCreateAlarmAndEvent(self):
    global context
    dateFrom = time.gmtime()
    context[0x00].setValues(3, 6, [0x1337])
    sleep(15)
    alarms = self.client.getActiveAlarms()
    self.assertEquals(len(alarms), 1)
    events = self.client.getEventsForTime(dateFrom, time.gmtime())
    self.assertEquals(len(events), 1)

    mo = self.client.getModbusDevice()
    registerValue = mo['c8y_RegisterStatus']['AlarmEventHoldingRegister']
    self.assertEquals(int(float(registerValue)), 0x1337)

    dateFrom = time.gmtime()
    context[0x00].setValues(3, 6, [0])
    sleep(15)
    alarms = self.client.getActiveAlarms()
    self.assertEquals(len(alarms), 0)
    events = self.client.getEventsForTime(dateFrom, time.gmtime())
    self.assertEquals(len(events), 1)

    mo = self.client.getModbusDevice()
    registerValue = mo['c8y_RegisterStatus']['AlarmEventHoldingRegister']
    self.assertEquals(int(float(registerValue)), 0)

def startTests():
  try:
    del sys.argv[1:]
    suite = unittest.TestLoader().loadTestsFromTestCase(FieldbusTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    handleResult(result)
  except SystemExit as inst:
    if inst.args[0] is True:
      print('')

def handleResult(result):
  client = CumulocityClient(host, tenant, username, password, reportingDeviceId)
  clearOldAlarms(client, 'FieldbusTests')
  raiseAlarms(client, result.failures)
  updateLastExecution(client, result)

def raiseAlarms(client, failures):
  for test, trace in failures:
    client.createAlarm(test.id().replace("__main__.", ""),trace)

def clearOldAlarms(client, prefix):
  allAlarms = client.getActiveAlarms()
  for alarm in allAlarms:
    if alarm['type'].startswith(prefix):
      client.clearAlarm(alarm['id'])

def updateLastExecution(client, result):
  report = {
    'lastExecution': client.getISODateString(time.gmtime()),
    'testsExecuted': result.testsRun,
    'successful': result.wasSuccessful()
  }
  client.updateDeviceProperty('FieldbusTests', report)

# setup modbus server
store = ModbusSlaveContext(
    co = ModbusSequentialDataBlock(0, [0]*100),
    di = ModbusSequentialDataBlock(0, [0]*100),
    hr = ModbusSequentialDataBlock(0, [0]*100),
    ir = ModbusSequentialDataBlock(0, [0]*100))
context = ModbusServerContext(slaves=store, single=True)

framer  = ModbusSocketFramer
factory = ModbusServerFactory(context, framer, None)
try:
  print('------------ Start running tests ------------')
  print('-------- ' + str(datetime.now()) + ' ---------')
  print('---------------------------------------------')
  port = reactor.listenTCP(modbusPort, factory)
  # queue test cases
  reactor.callInThread(startTests)
  # start modbus server
  reactor.run()
except Exception as error:
  print('Unexpected error running tests.')
  traceback.print_exc()
