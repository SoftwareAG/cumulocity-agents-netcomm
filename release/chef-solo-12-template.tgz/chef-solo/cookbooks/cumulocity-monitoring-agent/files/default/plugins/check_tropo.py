#!/usr/bin/env python2
import sys

import createAlarmsFromGpio as ga


ID = ga.netcommDeviceId
c, t = ga.verifyNoActiveAlarm(ID, 'tropo', 10)
if not c:
    print('CRITICAL - Tropo is down')
    sys.exit(2)

print('OK - Get tropo status in {0} s | RTT={1}'.format(t + 1, t + 1))
