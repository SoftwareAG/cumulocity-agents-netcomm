#!/usr/bin/python
import requests, sys, json, argparse
from enum import Enum
from string import Template

parser = argparse.ArgumentParser(description='Health check API.')

parser.add_argument('url')
parser.add_argument('username')
parser.add_argument('password')

args = parser.parse_args()

class Status(Enum):
    UP = 1
    OUT_OF_SERVICE = 2
    DOWN = 3

class HealthCheck:
    def __init__(self):
        self.headers = {'accept': 'application/json'}
        self._status = None

    def status(self):
        return Status[self.get()['status']['code']]

    def get(self):
        try:
            if self._status is None:
                self._status = requests.get(args.url+'/health',
                   auth=(args.username, args.password), headers=self.headers).json()
        except requests.exceptions.RequestException as e:
            self._status ={'status': {'code':'DOWN'},'details':{'connection':{'status':{'code':'DOWN'},'details':str(e)}}}
        return self._status
    def description(self):
        description = ''
        for id, status in self.get()['details'].iteritems():
            if status['status']['code'] == 'UP':
                 continue
            description += Template('$id is $status - details: $details \n ').substitute({'id': id,'status': status['status']['code'], 'details': json.dumps(status['details']) })

        return description


check = HealthCheck()
status = check.status()

if status is Status.UP :
    sys.exit(0);
if status is Status.OUT_OF_SERVICE:
    print(check.description())
    sys.exit(1)

if status is Status.DOWN:
    print(check.description())
    sys.exit(2)
