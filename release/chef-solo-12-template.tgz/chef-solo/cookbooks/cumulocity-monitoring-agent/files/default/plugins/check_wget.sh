#!/bin/bash

file=`mktemp`

if [ "$1" == "" ] || [ "$2" == "" ]
then
  echo "Error! Usage: check_wget URL search_string"
  exit 3
fi

wget -O $file $1 2>/dev/null 1>/dev/null

grep $2 $file 2>/dev/null 1>/dev/null
grep_exit=$?

rm $file

if [ "$grep_exit" == "0" ]
then
  echo OK
  exit 0
else
  echo CRITICAL
  exit 2
fi
