#!/usr/bin/env python
# -*- coding: utf-8 -*-

import base64, sys, httplib, json, urllib
from random import randint 

from pprint import pprint

url = str(sys.argv[1])
user = str(sys.argv[2])
password = str(sys.argv[3])
tenant = 'management'
errStatus=0
errMessage=''

adminCredentials = 'Basic ' + base64.b64encode(tenant + '/' + user + ':'+ password)

client = httplib.HTTPConnection(url)

try:
	client.request('GET', '/cep/health' ,'', {'Authorization': adminCredentials, 'Content-Type': 'application/json', 'Accept': 'application/json'})
except:
	errStatus = 1
	errMessage = str(sys.exc_info()[0])
        client.close()                                                                                                                                                           

if errStatus==0:
	response = client.getresponse()
	responseData = response.read()
	responseStatus = response.status
	client.close()


	if responseStatus > 299:
		errStatus = 1
		errMessage = str(responseData)

	else:

		respStruct = json.loads(responseData)

		if respStruct.has_key("status"):
			respStatus = respStruct['status']
			respCode = str(respStatus['code'])

			if respCode != "UP":
				errStatus = 1
				errMessage = "CEP DOWN"

		else:
			errStatus = 1
			errMessage = "Could not evaluate health endpoint result"


if errStatus==0:

	print "CEP OK"
	sys.exit(0)

else:

	print "CEP CRITICAL | "+str(errMessage)
	sys.exit(2)







