#!/bin/bash

SERVER=$1
PORT=$2
URI=$3
AUTH=""
METHOD=$5
BODY=$6

ADDRESS="http://${SERVER}:${PORT}${URI}"
BODY=$(echo $BODY |tr '*~#%@' '"[{}]')

RESULT=`curl --write-out "%{http_code}\n" --silent --output /dev/null -X ${METHOD} "${ADDRESS}" -H "Content-Type: application/json" -H "Authorization: ${AUTH}" -d {${BODY}}`

if [[ $RESULT -eq 201 || $RESULT -eq 200 ]]; then
    CHECK="OK"
else
    CHECK="Failed"
fi

if [[ "$CHECK" == "OK" ]]; then
  echo "SERVICE OK"
  exit 0
elif [[ "$CHECK" == "Failed" ]]; then
  echo "Service not working: ${URI}"
  exit 2
else
  echo "Check failed"
  exit 3
fi
