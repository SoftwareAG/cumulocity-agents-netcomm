
#!/usr/bin/env python2

import datetime

CRLF = '\r\n'

def printAndWrite(message, file):
	print(message)
	file.write(message + '\n')

def getGMT() :
	date = datetime.datetime.utcnow()
	return date.strftime('%a, %d %b %Y %H:%M:%S GMT')

def verifyFieldAndValue(response, field, value, keyword) :

	message = ''
	if response.get(field) == None :
		message += '2, CRITICAL - field ' + field + ' does not exist'
		return message

	if len(keyword) > 0 :
		for key in keyword:

			if message != '' :
				message += '\n'

			if response.get(field).find(key) != -1 :
				message += '0, OK - keyword '+ key + ' found in ' + field
			else :
				message += '2, CRITICAL - keyword '+ key + ' not found in ' + field

	if value != None :

		if message != '' :
			message += '\n'

		if response.get(field) == value : 
			message += '0, OK - returned value is correct for ' + field
		else:
			message += '2, CRITICAL - field ' + field + ' does not have correct value. Expected: ' + str(value) + ' received: ' + response.get(field)
	
	return message

def validateHeaders (headers, file) :
	if headers != '0' :
		headers = headers.split('\n')
		headers_dictionary = {}
		for x in headers :
			fields = x.split(':', 1)
			if len(fields) == 2 :
				headers_dictionary[str(fields[0]).strip()] = str(fields[1]).strip()
		
		printAndWrite(verifyFieldAndValue(headers_dictionary, 'Transfer-Encoding', 'chunked', []), file)
		printAndWrite(verifyFieldAndValue(headers_dictionary, 'Server', 'nginx', []), file)
		printAndWrite(verifyFieldAndValue(headers_dictionary, 'Date', getGMT(), []), file)
		if (headers[0].startswith('HTTP/1.1')) :
			printAndWrite(verifyFieldAndValue(headers_dictionary, 'Connection', 'keep-alive', []), file)
		elif (headers[0].startswith('HTTP/1.0')) :
			printAndWrite(verifyFieldAndValue(headers_dictionary, 'Connection', 'close', []), file)
		printAndWrite(verifyFieldAndValue(headers_dictionary, 'Strict-Transport-Security', None, ['max-age', 'includeSubDomains']), file)

def getResponse (s, reliable) :
	# Get the response (in several parts, if necessary)
	response = ''

	print ('Listening for incoming packet')
	buffer = s.recv(1024)	
	# HTTP headers will be separated from the body by an empty line
	if buffer.startswith('HTTP') :
		header_data, _, body = buffer.partition(CRLF + CRLF)
		if reliable == True :
			sessionId = getSessionId(body)
			return header_data, body, sessionId

		print 'header'
		print header_data
		print 'body'
		print body
		return header_data, body
		
	header_data = '0'
	count, message = bodyContent(buffer)
	if (count == 0) :
		print 'body count 0'
		return getResponse (s, reliable)


	if reliable == True :
		sessionId = getSessionId(buffer)
		return header_data, buffer, sessionId
	print 'no header'
	print 'body'
	print buffer
	return '0', buffer

def getSessionId (body) : 

	#parse data to get request count
	sessionId = '0'
	lines = body.split('\n')

	# search for 88
	for line in lines :
		template = line.split(',')
		if template[0] == '88' :
			sessionId = template[1]
			break

	print ('sessionId: ' + sessionId)
	return sessionId

def generateRequestContent (domain, endpoint, authbase64, xId, data) :
	request = [
		'POST '+ endpoint +' HTTP/1.1',
		'Host: ' + domain,
		'Authorization: Basic ' + str(authbase64),
		'X-Id: ' + xId,
		'Content-Length: ' + str(len(data)),
		'',
		data
	]
	return CRLF.join(request)

def executeRequest (s, domain, request, reliable) :

	s.send(request)

	if reliable == True:
		headers, body, sessionId = getResponse(s, reliable)
		return s, headers, body, sessionId

	headers, body = getResponse(s, reliable)
	count, message = bodyContent(body)
	return headers, body


def bodyContent (body):
	lines = body.split('\n')
	count = 0
	if (lines[0] != ''):
		
		try :
			count = int(lines[0], 16)
		except ValueError:
			return -1, lines

	return count, lines[1:len(lines)]

def validateHeartbeat (body, interval, file) :
	count, message_array = bodyContent(body)
	print ('chunk: ' + str(count))
	print ('message: ')
	print (message_array)
	if count != 0 :	
		if count == 1 and message_array[0] == ' \r': 
			if (interval >= 540 and interval <= 660) :# apprx. 9-11 min
				message = '0, OK - One heartbeat is received in ' + str(interval) + ' sec.'
				printAndWrite(message, file)
				return 1
			else :
				message = '2, CRITICAL - One heartbeat is expected every 540-660 seconds but received in ' + str(interval) + ' sec.'
				printAndWrite(message, file)
				return 0
		elif message_array[0].startswith(' '): 
			message = '2, CRITICAL - Not a valid heartbeat received in ' + str(interval) + 'sec., expected message count 1 received : ' + count
			printAndWrite(message, file)
			return 0
		elif (message_array[0] != '\r'):
			message = '3, Operation received'
			printAndWrite(message, file)
			return 2
	return 3

def getXId(responseBody) :
	values = responseBody.split(',')
	return values[1].strip()

def checkTimeout (body_message, timeout, file) :
	count, message_array = bodyContent(body_message)
	
	for line in message_array :
		if line.strip() == '86,,5400000,0,retry' :
			if timeout >= 5400 and timeout <= 5460 :
				message = '0, OK - Long polling timeout message received after ' + str(timeout/60) + 'minutes'
				printAndWrite(message, file)
				return True
			else :
				message = '1, NOK - Long polling timeout message expected to be received in 90-91 minutes but received after ' + str(timeout/60) +' minutes'
				printAndWrite(message, file)
				return False

	return False

