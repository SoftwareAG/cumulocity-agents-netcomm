#!/bin/sh
#
# Event handler script for restarting the Karaf service on the local machine
#
# Note: This script will only restart the Karaf if the service is
#       retried 3 times (in a "soft" state) or if the web service somehow
#       manages to fall into a "hard" error state.
#       If service is still running this script will NOT restart it!

# What state is the Karaf service in?

function logstatus  {
    LSTAT="`date`\t ${0##*/}\t $1 $2 $3"
    echo -e $LSTAT |sudo tee -a /var/log/nagios_rescue.log > /dev/null
}

case "$1" in
OK)
	# The service just came back up, so don't do anything...
	;;
WARNING)
	# We don't really care about warning states, since the service is probably still running...
	;;
UNKNOWN)
	# We don't know what might be causing an unknown error, so don't do anything...
	;;
CRITICAL)
	# Is this a "soft" or a "hard" state?
	case "$2" in
	# We're in a "soft" state, meaning that Nagios is in the middle of retrying the
	# check before it turns into a "hard" state and contacts get notified...
	SOFT)
			
		case "$3" in
				
		3)
			# Call the init script to re-start the Karaf service
			/etc/init.d/cumulocity-core-karaf status
			if [ $? -ne 0 ]
			    then sudo /etc/init.d/cumulocity-core-karaf start
			    echo -n "Restarting Karaf service (3rd soft critical state)..."
			    logstatus $1 $2 $3
			fi
			;;
			esac
		;;
				
	HARD)
			# Call the init script to re-start the Karaf service
			/etc/init.d/cumulocity-core-karaf status
			if [ $? -ne 0 ]
			    then sudo /etc/init.d/cumulocity-core-karaf start
			    echo -n "Starting Karaf service (HARD State)..."
			    logstatus $1 $2 $3
			fi
	esac
	;;
esac
exit 0

