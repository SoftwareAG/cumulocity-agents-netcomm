#!/usr/bin/env python

import socket

class TrackerClient:
    def __init__(self, host, port):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.host = host
        self.port = port
        self.socket.connect((self.host, self.port))

    def sendMessage(self, message):
        self.socket.send(message)

    def close(self):
        self.socket.close()
