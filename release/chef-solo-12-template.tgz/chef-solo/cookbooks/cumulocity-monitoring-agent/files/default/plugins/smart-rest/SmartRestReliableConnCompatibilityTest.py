#!/usr/bin/env python2

import requestAndValidationFunctions as rv
import socket
import base64
import time
import datetime
import os
import sys

CRLF = '\r\n'

domain = 'c8ytest.cumulocity.com'
notificationEndpoint = '/devicecontrol/notifications'
credentials = 'c8ytest/device_FCN0CJ01L665509:A1rp1XU6qE'
base64String = base64.b64encode(credentials.encode('utf-8'))
xId = 'demoagent_5'
device = '33954064'

s = socket.socket()
s.connect((domain, 80))

currentDir = os.path.dirname(__file__)
tempFile = os.path.join(currentDir, 'result/smartRestReliableConnTestResults_temp')
resultFile = os.path.join(currentDir, 'result/smartRestReliableConnTestResults')
file = open(tempFile, 'w')

try :
 	#---- Reliable communication mode ----
	#TC 20: Perform handshake for SmartREST notification
	print('Testing for reliable communication mode')

	now = datetime.datetime.now()
	rv.printAndWrite('0, Tests started: ' + str(now), file)
	# Blank Post Request
	rv.printAndWrite('0, Test - Request blank', file)
	request = rv.generateRequestContent(domain, '/s', base64String, xId, '')
	headers, body = rv.executeRequest(s, domain, request, False)
	rv.validateHeaders(headers, file)
	count, message_array = rv.bodyContent(body)
	xId = rv.getXId(message_array[0])

	rv.printAndWrite('0, Test - Request 80: Perform handshake with true flag', file)
	request = rv.generateRequestContent(domain, notificationEndpoint, base64String, xId, '80,true')
	headers, body = rv.executeRequest(s, domain, request, False)
	rv.validateHeaders(headers, file)
	count, message_array = rv.bodyContent(body)
	clientId = message_array[0].strip()

	#TC 21: Subscribe to SmartREST notifications
	rv.printAndWrite('0, Test - Request 81: Subscribe notifications', file)
	data = '81,' + clientId + ',/' + device
	request = rv.generateRequestContent(domain, notificationEndpoint, base64String, xId, data)
	headers, body = rv.executeRequest(s, domain, request, False)
	rv.validateHeaders(headers, file)

	#TC 22: Connect to SmartREST notification channel
	rv.printAndWrite('0, Test - Request 83: Long polling', file)
	data = '83,' + clientId
	request = rv.generateRequestContent(domain, notificationEndpoint, base64String, xId, data)
	s.send(request)

	longpolling_t0 = time.time()
	timeout = 60 * 90
	isTimeoutReceived = False

	#TC 30: Heartbeat should be sent every 10 minutes
	# and
	#TC 31: Exactly one heartbeat should be sent within 10 minutes interval
	heartbeat = 0
	invalidHeartbeat = 0
	while (time.time() - longpolling_t0 < timeout + 120  and isTimeoutReceived != True) :

		rv.printAndWrite('0, Test - Get a heartbeat', file)
		t0 = time.time()
		headers, body, connectId = rv.getResponse(s, True)

		rv.validateHeaders(headers, file)
		t1 = time.time()
		type = rv.validateHeartbeat(body, int(t1-t0), file)

		# TC 40: Long polling timeout
		isTimeoutReceived = rv.checkTimeout(body, t1 - longpolling_t0, file)
		
		if (type == 0) :
			invalidHeartbeat += 1
		elif (type == 1) :
			heartbeat += 1
		elif (type == 2) : # type: operation, restart post request, heartbeat counts and loop polling time
			reconnect_data = data + ',' + connectId
			request = rv.generateRequestContent(domain, notificationEndpoint, base64String, xId, reconnect_data)
			s.send(request)
			longpolling_t0 = time.time()

	if isTimeoutReceived != True :
		rv.printAndWrite('1, NOK - Long polling timeout message not received in 90-91 minutes', file)

	# Disconnect
	rv.printAndWrite('0, Test - Request 84: disconnect', file)
	data = '84,' + clientId
	request = rv.generateRequestContent(domain, notificationEndpoint, base64String, xId, data)
	headers, body = rv.executeRequest(s, domain, request, False)
	rv.validateHeaders(headers, file)

	s.close()
	file.close()

except :
	s.close()
	rv.printAndWrite('2, Thrown exception during execution of the tests' + str(sys.exc_info()[0]), file)
	file.close()
finally :
	#rename temp file to real result file
	os.rename(tempFile, resultFile)