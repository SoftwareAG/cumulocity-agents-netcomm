#!/usr/bin/env ruby

require 'rubygems'
require 'json'
require 'time'
require 'chef/node'
require 'set'
require File.dirname(__FILE__) + '/nagios_helper'
require File.dirname(__FILE__) + '/knife_helper'

include NagiosHelper
include KnifeHelper

def check(nodename)
  unless File.exists?(File.join(File.dirname(__FILE__),".chef","knife.rb"))
    unknown "Cannot find knife configuration."
  end
  environment = run_knife_and_parse("node show -Fj #{nodename} -a chef_environment")["chef_environment"]
  knife_result = run_knife_and_parse("search node -Fj -q \"chef_environment:#{environment} AND recipes:bigcouch\\:\\:join_cluster\"")["rows"]
  expected_nodes = knife_result.collect {|couchNode| "bigcouch@#{couchNode.ipaddress}"}
  expected_nodes_with_names = knife_result.collect {|couchNode| "#{couchNode.name}(#{couchNode.ipaddress})"}
  membership = JSON.parse `curl -s http://127.0.0.1:5984/_membership`
  cluster_nodes = membership["cluster_nodes"]
  all_nodes = membership["all_nodes"]
  unless (cluster_nodes.to_set == expected_nodes.to_set)
    critical "Nodes running join_cluster: #{expected_nodes_with_names.join(', ')}. Bigcouch 'cluser_nodes': #{cluster_nodes.join(', ')}."
  end
  unless (all_nodes.to_set == cluster_nodes.to_set)
    critical "Mismatch in couch membership cluster_nodes != all_nodes, Bigcouch 'cluster_nodes': #{cluster_nodes.join(', ')}. Bigcouch 'all_nodes': #{all_nodes.join(', ')}."
  end

  p "OK. Cluser nodes #{expected_nodes_with_names.join(',')}."
end

if __FILE__ == $0
  unless ARGV.size == 1
    unknown "Wrong number of parameters passed. Usage: #{File.basename(__FILE__)} NODENAME"
  end

  nodename = ARGV[0]
  check(nodename)
end