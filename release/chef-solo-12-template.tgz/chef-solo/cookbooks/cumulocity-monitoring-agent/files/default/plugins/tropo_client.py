#!/usr/bin/env python3
from datetime import datetime, timedelta
import itertools
import json
import os
from subprocess import Popen, PIPE
import syslog
import time

import requests

auth = requests.auth.HTTPBasicAuth("scriptUser", "resUtpircs")
deviceid = "30439559"
url_alarm = 'http://c8ytest.cumulocity.com/alarm/alarms/'
h = {"Content-Type": "application/json", "Accept": "application/json"}
url_query = "http://c8ytest.cumulocity.com/alarm/alarms/?source={}&status={}"
val = 1800


def main():
    while True:
        try:
            clear_alarms(deviceid, 'sip')
            syslog.syslog(syslog.LOG_NOTICE, 'Starting tropo test')
            create_alarm(deviceid, 'sip', 'sip call')
            if not received_call(30):
                syslog.syslog(syslog.LOG_ERR, 'Tropo is down!')
                create_alarm(deviceid, 'tropo', 'tropo down')
            else:
                syslog.syslog(syslog.LOG_NOTICE, 'Tropo is okay!')
                clear_alarms(deviceid, 'tropo')
        except requests.exceptions.RequestException as e:
            syslog.syslog(syslog.LOG_WARNING, e)
        line = 'Next test: ' + str(datetime.now() + timedelta(seconds=val))
        syslog.syslog(syslog.LOG_NOTICE, line)
        time.sleep(val)


def create_alarm(deviceid, alarm_type, text):
    data = {'time': '2015-11-17T15:00:00+0100', 'type': alarm_type,
            'status': 'ACTIVE', 'source': {'id': deviceid},
            'severity': 'MAJOR', 'text': text}
    requests.post(url_alarm, data=json.dumps(data), auth=auth, headers=h)


def clear_alarms(deviceid, alarm_type):
    url = url_query.format(deviceid, 'ACTIVE')
    active = requests.get(url, auth=auth).json()['alarms']
    url = url_query.format(deviceid, 'ACKNOWLEDGED')
    acked = requests.get(url, auth=auth).json()['alarms']
    for alarm in filter(lambda x: x['type'] == alarm_type,
                        itertools.chain(active, acked)):
        url = url_alarm + alarm['id']
        data = json.dumps({'status': 'CLEARED'})
        requests.put(url, data=data, auth=auth, headers=h)


def received_call(timeout):
    output = Popen('pgrep linphone', shell=True, stdout=PIPE)
    pid = output.stdout.read().decode('ascii').strip()
    if not pid:
        output = Popen('pgrep ekiga', shell=True, stdout=PIPE)
        pid = output.stdout.read().decode('ascii').strip()
        if not pid:
            return False
    d = '/proc/{}/fd/'.format(pid)
    stop = time.time() + timeout
    while time.time() <= stop:
        realpaths = map(lambda x: os.path.realpath(d + x), os.listdir(d))
        if any(filter(lambda x: 'snd' in x, realpaths)):
            return True
        time.sleep(3)
    return False


if __name__ == '__main__':
    main()
