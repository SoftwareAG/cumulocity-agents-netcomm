#!/usr/bin/env python2

import sys

import json
import requests
import time
from datetime import datetime, timedelta
import os

import operationAndVerification as ga

# both netcomm and relay controller (raspberry or cinterion) should be online.
# for testing purposes setup netcomm device
# start with ip mode, can be switched if necessary using UI
# connect to netcomm from command line 
	# ssh root@192.168.1.1
# set the value of service.cumulocity.gpio.1.debounce.interval and give the same value for relay_debounce_interval
	# to set interval on netcomm device: rdb_set service.cumulocity.gpio.1.debounce.interval <interval>
# set the value of service.cumulocity.sms.report.interval and give the same value for sms_report_interval here
	# to set interval on netcomm device: rdb_set service.cumulocity.sms.report.interval <interval>
# set the value of service.cumulocity.plugin.lua__signal.interval and give the same value for ip_report_interval here
	# to set interval on netcomm device: rdb_set service.cumulocity.plugin.lua__signal.interval <interval>

sms_report_interval = 1200
ip_report_interval = 60
relay = "1"
relay_debounce_interval = 600

ID = ga.netcommDeviceId

measurementUrl = "http://c8ytest.cumulocity.com/measurement/measurements/?source={0}&type={1}&dateFrom={2}&dateTo={3}&pageSize=10000"

currentDir = os.path.dirname(__file__)
tempFile = os.path.join(currentDir, 'result/netcommTestResults_temp')
resultFile = os.path.join(currentDir, 'result/netcommTestResults')
file = open(tempFile, 'w')

def getMeasurements(deviceId, type):
	t = time.time()
	today = datetime.fromtimestamp(t)
	tomorrow = today + timedelta(days=+1)
	today = today.strftime("%Y-%m-%d")
	tomorrow = tomorrow.strftime("%Y-%m-%d")
	url = measurementUrl.format(deviceId, type, today, tomorrow)
	measurements = requests.get(url, auth=ga.auth).json()['measurements']
	return measurements

def enableSmsMode():
	op = ga.switchMode(ID, 'SMS')
	return assertOp(op, 360)

def assertOp(operation, timeout):
	value, message = ga.assertOp(operation, timeout)
	if (value == 2) :
		printAndWrite('2, ' + message)
	if (value == 0) :
		message = 'OK - Op %s(%s) successful' % (operation['id'], operation['description'])
		printAndWrite('0, ' + message)
	return value, message

def testAlarmFromGPIO (ID, relay, timeout):
	value, message = ga.testAlarmFromGPIO(ID, relay, timeout)
	printAndWrite(str(value) + ', ' + message)

def printAndWrite (message) :
	print(message)
	file.write(message + '\n')

try :

	now = datetime.now()
	printAndWrite('0, Tests started: ' + str(now))

	# SMS Communication mode testing
	value, message = enableSmsMode()

	if value == 2 or value == 1 :
		printAndWrite ('2, Skipping all sms related tests')
	else :
		# test: alarm from gpio in sms mode
		testAlarmFromGPIO(ID, relay, (relay_debounce_interval * 3/2))

		# test: debouncing in sms mode
		op = ga.openRelay(relay)
		assertOp(op, 30)

		c, ta1 = ga.verifyNoActiveAlarm(ID, 'gpio1', relay_debounce_interval/3)
		if not c:
			message = '2, CRITICAL - Alarm still active (sms mode)'
			printAndWrite(message)
		    
		op = ga.closeRelay(relay)
		assertOp(op, 30)

		op = ga.openRelay(relay)
		assertOp(op, 30)

		c, ta1 = ga.verifyNoActiveAlarm(ID, 'gpio1', relay_debounce_interval/3)
		if not c:
			message = '2, CRITICAL - Alarm still active (sms mode)'
			printAndWrite(message)

		op = ga.closeRelay(relay)
		assertOp(op, 30)
		printAndWrite('0, OK - Test debouncing in sms mode passed')


		# test: measurement created from ping sms and generalabfrage
		interval = (sms_report_interval * 3/2)

		before_measurements = getMeasurements(ID, 'c8y_SignalStrength')
		time.sleep(interval)
		after_measurements = getMeasurements(ID, 'c8y_SignalStrength')
		if len(after_measurements) - len(before_measurements) > 0 :
			printAndWrite('0, OK - Signal measurement created from ping sms')
		else :
			printAndWrite('2, CRITICAL - Signal measurement is not created from ping sms')

		before_measurements = after_measurements
		op = ga.getStatusOperation(ID)
		assertOp(op, 30)
		after_measurements = getMeasurements(ID, 'c8y_SignalStrength')
		if len(after_measurements) - len(before_measurements) > 0 :
			printAndWrite('0, OK - Signal measurement created from ping sms after get status operation')
		else :
			printAndWrite('2, CRITICAL - Signal measurement is not created from ping sms after get status operation')

	# switch to ip mode
	op = ga.switchMode(ID, "IP")
	c, value = assertOp(op, 360)

	if c == 2 or c == 1 :
		printAndWrite ('2, Skipping all IP related tests')
	else :
		printAndWrite('0, OK - Netcomm switch operation mode to IP is successful')
		#IP Communication mode testing

		measurement_signal_interval = ip_report_interval * 3/2
		before_measurements = getMeasurements(ID, 'c8y_SignalMeasurement')
		time.sleep(measurement_signal_interval)
		after_measurements = getMeasurements(ID, 'c8y_SignalMeasurement')
		if len(after_measurements) - len(before_measurements) > 0:
			printAndWrite('0, OK - Signal measurement created in IP measurement polling time')
		else :
			printAndWrite('2, CRITICAL - Signal measurement is not created in IP measurement polling time')

		before_measurements = after_measurements
		op = ga.getStatusOperation(ID)
		assertOp(op, 30)
		after_measurements = getMeasurements(ID, 'c8y_SignalMeasurement')
		if len(after_measurements) - len(before_measurements) > 0 :
			printAndWrite('0, OK - Signal measurement created in IP mode after get status operation')
		else :
			printAndWrite('2, CRITICAL - Signal measurement is not created in IP mode after get status operation')

		testAlarmFromGPIO(ID, relay, (relay_debounce_interval * 3/2))

	file.close()

except :
	printAndWrite('2, Thrown exception during execution of the tests: ' + str(sys.exc_info()[0]))
	file.close()
finally:
	#rename temp file to real result file
	os.rename(tempFile, resultFile)