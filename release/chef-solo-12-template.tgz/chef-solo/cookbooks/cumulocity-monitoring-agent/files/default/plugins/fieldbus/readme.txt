Instructions:

* Prerequisites
** Install python 2.7
** Install pip "easy_install -U pip"
** Install requiered libraries "pip install -Ur requirements.txt"

* Device setup:
** Connect the NTC to your laptop
** Register the device on any tenant
** Create a modbus child
*** IP address: the IP address of your laptop
*** address: 1
*** device type: E2ETestModel
** Set transmit rate and polling rate to 4 seconds

* fielbusTests.py:
** This script executes the test cases and posts a report and if present alarms to a reporting device.
** The script takes 7 parameters <host> <tenant> <username> <password> <modbusDeviceId> <reportingDeviceId> <modbusPort>.'
** The modbusDeviceId is the id of the created modbus child.
** The reportingDeviceId is the id of the device where the test reports are posted.
** The modbusPort is the port on which the modbus slave will listen to.
** e.g. python fielbusTests.py integration.cumulocity.com testtenant admin mypassword 12345 23456 502

* checkAlarms.py:
** This script evaluates the report and if not successful the alarms present on the reporting device to create a nagios report.
** The script takes 7 parameters <host> <tenant> <username> <password> <deviceId> <alarmTypePrefix> <requiredTestInterval>
** The deviceId is the id of the device where the test reports are read from.
** The alarmTypePrefix is the prefix that is expected on active alarm types.
** The requiredTestInterval is the interval (in minutes) test executions must be performed before a warning will be shown.
** e.g. python fielbusTests.py integration.cumulocity.com testtenant admin mypassword 12345 myPrefix 20
