#!/bin/sh
#
# Event handler script for freeing RAM on the local machine
#

# What state is the MEMORY in?

function logstatus  {
    LSTAT="`date`\t ${0##*/}\t $1 $2 $3"
    echo -e $LSTAT |sudo tee -a /var/log/nagios_rescue.log > /dev/null
}

case "$1" in
OK)
	# The RAM Memory is ok, so don't do anything...
	;;
WARNING)
	# We try to free some memory blocked by cache...
	case "$3" in
	2)
		echo -n "Removing cached pages from RAM..."
		# Call the Kernel script
		sudo sync; echo "1" |sudo tee /proc/sys/vm/drop_caches
		logstatus $1 $2 $3
		;;
		esac
	;;
UNKNOWN)
	# We don't know what might be causing an unknown error, so don't do anything...
	;;
CRITICAL)
	# Is this a "soft" or a "hard" state?
	case "$2" in
		
	SOFT)
			
		case "$3" in
				
		2)
			echo -n "Removing cached pages and inodes from RAM..."
			# Call the Kernel script
			sudo sync; echo "3" |sudo tee /proc/sys/vm/drop_caches
			logstatus $1 $2 $3
			;;
			esac
		;;
				
	HARD)
	;;
    esac
    ;;
esac

exit 0

