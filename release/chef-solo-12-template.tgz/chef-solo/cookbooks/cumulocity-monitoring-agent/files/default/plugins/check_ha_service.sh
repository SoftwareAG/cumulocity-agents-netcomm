#!/bin/bash

#
# Michal Semeniuk, NSN, 2012
# Wrapper script to run nagios plugin only on active node of heartbeat cluster
# Usage: check_ha_service check_script nagios_plugin [plugin_options]
#

if [ "$1" == "" ] || [ "$2" == "" ]
then
  echo "Error: no arguments!"
  echo "Usage: check_ha_service check_script nagios_plugin [plugin_options]"
  exit 3
fi

CHECK_SCRIPT=`which $1`
shift 1
PLUGIN=$*

if [[ ! -x $CHECK_SCRIPT ]]
then
  echo "Error: I can't run check_script $1!"
  exit 3
fi

sudo $CHECK_SCRIPT 2>/dev/null 1>/dev/null
RET_VALUE=$?

if [ "$RET_VALUE" == "0" ]
then
  $PLUGIN
  exit $?
elif [ "$RET_VALUE" == "1" ]
then
  echo "I'm slave, not checking"
  exit 0
else
  echo "I can't check status of node in cluster!"
  exit 3
fi


