#!/bin/bash

FOLDER="/var/log/chef/client.log"

RESULT=`tail -n 1 ${FOLDER} |grep " ERROR:\| FATAL: \| gracefully$"`

if [[ -z $RESULT ]]; then
    CHECK="OK"
else
    CHECK="Failed"
fi

if [[ "$CHECK" == "OK" ]]; then
  echo "SERVICE OK"
  exit 0
elif [[ "$RESULT" == *gracefully* ]]; then
  echo "Chef client has been stopped."
  exit 1
elif [[ "$CHECK" == "Failed" ]]; then
  echo "${RESULT}" |cut -b 29-
  exit 2
else
  echo "Check failed"
  exit 3
fi
