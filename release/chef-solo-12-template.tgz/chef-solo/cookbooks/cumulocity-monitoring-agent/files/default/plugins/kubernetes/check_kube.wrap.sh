#!/bin/bash

if [[ -z $1 ]] ; then
  echo "Usage: $0 check_kube_script"
  exit 3
fi

script="$( readlink -f "$1" )"
output="$( "$script" -k /etc/kubernetes/admin.conf )"
exitcode=$?

case "$( basename $1 )" in
  check_kube_deployments.sh|check_kube_pods.sh)
      OK="$( egrep -c '^OK:' <<< "${output}" )"
    WARN="$( egrep -c '^Warning:' <<< "${output}" )"
    CRIT="$( egrep -c '^Critical:' <<< "${output}" )"
    UNKN="$( egrep -c '^Unknown:' <<< "${output}" )"
    echo "OK: $OK | WARN: $WARN | CRIT: $CRIT | UNKN: $UNKN | EXIT: $exitcode"
    egrep '^Warning:' <<< "${output}"
    egrep '^Critical:' <<< "${output}"
    egrep '^Unknown:' <<< "${output}"
  ;;
  check_kube_nodes*.sh|check_kubernetes_api*.sh)
    echo "${output}"
  ;;
  *) echo UNKNOWN ; exitcode=3 ;;
esac
exit $exitcode







