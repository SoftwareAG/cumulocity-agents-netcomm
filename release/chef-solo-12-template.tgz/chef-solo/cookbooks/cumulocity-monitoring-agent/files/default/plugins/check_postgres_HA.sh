#!/bin/bash

check_replication_lag() {
pg_query="SELECT CASE WHEN pg_last_xlog_receive_location() = pg_last_xlog_replay_location() 
		      THEN 0 
		      ELSE EXTRACT (EPOCH FROM now()-pg_last_xact_replay_timestamp())::INTEGER END;"

pg_command="psql -A -t -U ${pg_user} -c \"$pg_query\" $pg_db"

pg_rl_result=`eval $pg_command`
pg_rl_retval=$?

}

check_hotstandby_state() {
pg_query="SELECT CAST(pg_is_in_recovery() as int);"

pg_command="psql -A -t -U ${pg_user} -c \"$pg_query\" $pg_db"

pg_hs_result=`eval $pg_command`
pg_hs_retval=$?

}

usage() {
cat << EOF
usage: $0 OPTIONS
OPTIONS:
-db 'PostgreSQL database to connect'
--dbuser 'PostgreSQL user for monitoring role'
--dbpass 'Password for monitoring role'
EOF
}

# MAIN:
while [ $# -gt 0 ]; do
      case "$1" in
	-H ) shift;;
        -db ) pg_db=$2 ; shift;;
	--dbpass ) pg_pass=$2 ; shift;;
	--dbuser ) pg_user=$2 ; shift;;
	*) usage; exit -1
      esac
    shift 
done

export PGPASSWORD=${pg_pass}
check_replication_lag
check_hotstandby_state
pgrep -f "failover_detector.sh" > /dev/null ; fd_retval=$?
pgrep -f "wal\s(receiver|sender)" > /dev/null ; wr_retval=$?

if [ $((pg_rl_retval + pg_hs_retval)) -ne 0 ]; then echo "Cannot connect to Postgres db!" ; exit 4; fi

let xrl=pg_rl_result==0?0:1
let xhs=pg_hs_result==1?0:2
let xfd=fd_retval==0?0:4
let xwr=wr_retval==0?0:8
xresult=$(($xrl + $xhs + $xfd + $xwr))

case $xresult in 
    0)		xcode=0 ; xmess="Postgres is working as a Hot Standby, Replication is in sync";;
    1)		xcode=1 ; xmess="Postgres is working as a Hot Standby, Replication is ${pg_rl_result} sec behind the Master";;
    2)		xcode=2 ; xmess="Postgres is no longer a Hot Standby, writing to db is enabled!";;
    3)		xcode=2 ; xmess="Postgres is no longer a Hot Standby, Replication is ${pg_rl_result} sec behind the Master";;
    4)		xcode=2 ; xmess="Postgres is working as a Hot Standby but failover detector is not running!";;
    5)		xcode=2 ; xmess="Postgres is working as a Hot Standby, Replication is ${pg_rl_result} sec behind the Master but failover detector is dead";;
    6|7)	xcode=0 ; xmess="Postgres is working as a Master";;
    8|9)	xcode=2 ; xmess="Postgres is working as a Hot Standby but replication streaming process is not active";;
    10|11)	xcode=2 ; xmess="Replication process is still active, Postgres is in read-write mode";;
    12|13)	xcode=2 ; xmess="Postgres is in unknown state, it is in read-only mode but failover detector and streaming process are dead";;
    14|15)	xcode=2 ; xmess="Postgres switched to MASTER in read-write mode. Check what happened with the second node!";;
esac

echo $xmess
exit $xcode


