#!/usr/bin/env ruby

require 'rubygems'
require 'thor'
require 'json'
require 'time'
require File.dirname(__FILE__) + '/nagios_helper'

class CheckBackup < Thor
#  RESTORE_SCRIPT = "/Users/ukache/Projects/impaq/nsn/tam/creatary-chef/cookbooks/backup/templates/default/db_backup.rb"
  RESTORE_SCRIPT = "db_backup"
  include NagiosHelper

  desc "postgresql", "Checks if there are today backups from AWS and Rackspace for postgresql."
  method_option :threshold, :type => :numeric, :default => 93600, :aliases => "-t", :desc => "Threshold in [s]"
  def postgresql

    # times in [s]
    time_rackspace = get_latest_backup_time "Rackspace"
    time_aws = get_latest_backup_time "AWS"
    today_time = Time.now
    
    if ((today_time - time_rackspace) < options.threshold) and ((today_time - time_aws) < options.threshold)
      ok "Backups are up to date. Rackspace: #{time_rackspace.strftime('%d %b %Y %T')}, AWS: #{time_aws.strftime('%d %b %Y %T')}"
    elsif ((today_time - time_rackspace) > options.threshold) and ((today_time - time_aws) < options.threshold)
      warning "Backup from Rackspace is out of date: #{time_rackspace.strftime('%d %b %Y %T')}"
    elsif ((today_time - time_rackspace) < options.threshold) and ((today_time - time_aws) > options.threshold)
      warning "Backup from AWS is out of date: #{time_aws.strftime('%d %b %Y %T')}"
    else
      critical "Backups are out of date! Latest backup from Rackspace is #{time_rackspace.strftime('%d %b %Y %T')} and from AWS is #{time_aws.strftime('%d %b %Y %T')}"
    end
  end

  protected
  def get_latest_backup_time(provider)
    #    hash = {"last_modified" => "2012-02-28 01:00:07 +0100"}
    command = "sudo su charon -c '#{RESTORE_SCRIPT} show_latest --json --provider=#{provider}'"
    output = nil
    IO.popen(command) {|stdout| output = stdout.read}
    if $?.exitstatus != 0
      unknown "I can't get the latest backup time for #{provider}!"
    end
    hash = JSON.parse(output)
    Time.parse(hash["last_modified"])
  end
end

CheckBackup.start
