#!/bin/bash

# 
# Michal Semeniuk, NSN, 2012
# Nagios plugin to check drbd resource
# Plugin accepts one argument: name of resource
# If there is no argument, plugin will check all available resources
#

if [[ ! -a /proc/drbd ]]
then
  echo "Error: no /proc/drbd file!"
  exit 3
fi

if [ "$1" == "" ]
then
  echo "Error: no arguments!"
  echo "Usage: check_drbd.sh resource_to_check"
  exit 3
fi

device=$1

status=`cat /proc/drbd | grep " $device:"`

if [ "$status" == "" ]
then
  echo "Error: no device $device"
  exit 3
fi

conn_status=`echo $status | awk '{ print $2 }' | awk -F":" '{ print $2 }'`
local_disk=`echo $status | awk '{ print $4 }' | awk -F":" '{ print $2 }' | awk -F"/" '{ print $1 }'`
remote_disk=`echo $status | awk '{ print $4 }' | awk -F":" '{ print $2 }'| awk -F"/" '{ print $2 }'`

if [ "$conn_status" == "Connected" ]
then
  if [ "$local_disk" == "UpToDate" ] && [ "$remote_disk" == "UpToDate" ]
  then
    ret_value=0
    echo -n "OK: "
  else
    ret_value=1
    echo -n "WARNING: "
  fi
else
  echo -n "CRITICAL: "
  ret_value=2
fi

echo "Connection status: $conn_status, Local disk: $local_disk, Remote disk: $remote_disk"
exit $ret_value

