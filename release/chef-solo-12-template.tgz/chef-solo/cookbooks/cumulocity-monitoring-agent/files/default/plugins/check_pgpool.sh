#!/bin/bash

#
# Michal Semeniuk, NSN, 2012
#

while getopts ':u:p:P:h:' OPT; do
  case $OPT in
    u)  USER=$OPTARG;;
    p)  PASSWORD=$OPTARG;;
    P)  PORT=$OPTARG;;
    h)  HOST=$OPTARG;;
    *)  UNKNOWN_OPTION="yes";;
  esac
done

PCP_NODE_COUNT=`which pcp_node_count`
PCP_NODE_INFO=`which pcp_node_info`

if [ "$PCP_NODE_COUNT" == "" ]
then
  echo "UNKNOWN: There is no pcp_node_count tool!"
  exit 3
fi

if [ "$PCP_NODE_INFO" == "" ]
then
  echo "UNKNOWN: There is no pcp_node_info tool!"
  exit 3
fi

COUNT=`$PCP_NODE_COUNT 2 $HOST $PORT $USER $PASSWORD 2>&1`

if [ "$?" != "0" ]
then
  echo "UNKNOWN: I can't get number of pgpool backends! Error: $COUNT"
  exit 3
fi

if [ "$COUNT" == "0" ]
then
  echo "CRITICAL: There is no configured pgpool backends, check your configuration!"
  exit 2
fi

INDEX=0
FAILED=0
OUTPUT_INFO=""
while [ "$INDEX" != "$COUNT" ]
do
  NODE_INFO=`$PCP_NODE_INFO 2 $HOST $PORT $USER $PASSWORD $INDEX 2>&1`
  if [ "$?" != 0 ]
  then
    echo "CRITICAL: I can't get information for pgpool backend: $INDEX, $NODE_INFO"
    exit 2
  fi
  STATUS=`echo $NODE_INFO | awk '{ print $3 }'`
  OUTPUT_INFO=$OUTPUT_INFO"Backend $INDEX: $NODE_INFO; "
  if [ "$STATUS" != "1" ]
  then
    FAILED=$((FAILED+1))
  fi
  INDEX=$((INDEX+1))
done

if [ "$FAILED" != "0" ]
then
  echo "CRITICAL: $OUTPUT_INFO"
  exit 2
fi

echo "OK: $OUTPUT_INFO"
exit 0

