#!/usr/bin/env python

import sys, imp, time, os
imp.load_source('cumulocity', os.path.join(os.path.dirname(__file__), 'fieldbus/cumulocity.py'))
from cumulocity import CumulocityClient
from datetime import datetime, timedelta

'''
--------------------------------------
Configuration
--------------------------------------
'''
if len(sys.argv) != 7:
  print 'Expecting 6 parameters <host> <tenant> <username> <password> <eventType> <requiredInterval>'
  print 'e.g. python fielbusTests.py integration.cumulocity.com testtenant admin mypassword myEventType 24'
  sys.exit()

host = sys.argv[1]
tenant = sys.argv[2]
username = sys.argv[3]
password = sys.argv[4]
eventType = sys.argv[5]
requiredInterval = int(sys.argv[6])
'''
--------------------------------------
'''
def checkEvent():
    client = CumulocityClient(host, tenant, username, password, 10000)
    events = queryEvents(client)
    lastEvent = getLastEvent(events)
    exitWithMessage(lastEvent)

def queryEvents(client):
    dateFrom = buildFrom()
    dateTo = time.gmtime()
    return client.getEventsForTimeAndType(dateFrom, dateTo, eventType)

def buildFrom():
    dateFrom = datetime.utcnow() - timedelta(hours=requiredInterval)
    return dateFrom.timetuple()

def getLastEvent(events):
    if len(events) > 0:
        return events[0]

def exitWithMessage(lastEvent):
    if lastEvent:
        print('OK - Last event was at {time}.'.format(time=lastEvent['time']))
        sys.exit(0)
    else:
        print('CRITICAL - No event of type {type} within last {interval} hours.'.format(type=eventType, interval=requiredInterval))
        sys.exit(2)

checkEvent()
