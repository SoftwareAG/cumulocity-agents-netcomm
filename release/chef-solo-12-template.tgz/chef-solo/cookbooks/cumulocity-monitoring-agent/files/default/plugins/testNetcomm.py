#!/usr/bin/env python2

import sys

import json
import requests
import time
from datetime import datetime, timedelta

import createAlarmsFromGpio as ga

# both netcomm and relay controller (raspberry or cinterion) should be online.
# for testing purposes setup netcomm device
# start with ip mode, can be switched if necessary using UI
# connect to netcomm from command line 
	# ssh root@192.168.1.1
# set the value of service.cumulocity.gpio.1.debounce.interval to the and set the relay_debounce_interval
	# to set interval on netcomm device: rdb_set service.cumulocity.gpio.1.debounce.interval 40
# set the value of service.cumulocity.sms.report.interval to the sms_report_interval here
	# to set interval on netcomm device: rdb_set service.cumulocity.sms.report.interval 60
# set the value of service.cumulocity.plugin.lua__signal.interval to the ip_report_interval here
	# to set interval on netcomm device: rdb_set service.cumulocity.plugin.lua__signal.interval 60

sms_report_interval = 60
ip_report_interval = 60
relay = "1"
relay_debounce_interval = 40

ID = ga.netcommDeviceId

measurementUrl = "http://c8ytest.cumulocity.com/measurement/measurements/?source={0}&type={1}&dateFrom={2}&dateTo={3}&pageSize=10000"

def getMeasurements(deviceId, type):
	t = time.time()
	today = datetime.fromtimestamp(t)
	tomorrow = today + timedelta(days=+1)
	today = today.strftime("%Y-%m-%d")
	tomorrow = tomorrow.strftime("%Y-%m-%d")
	url = measurementUrl.format(deviceId, type, today, tomorrow)
	measurements = requests.get(url, auth=ga.auth).json()['measurements']
	return measurements

def enableSmsMode():
	op = ga.switchMode(ID, 'SMS')
	ga.assertOp(op, 360)
	print ('OK - Switched to sms mode.')

# SMS Communication mode testing
enableSmsMode()
# test: alarm from gpio in sms mode
ga.testAlarmFromGPIO(ID, relay, (relay_debounce_interval * 3/2))
print('OK - Test alarm from gpio in sms mode passed')

# test: debouncing in sms mode
op = ga.openRelay(relay)
ga.assertOp(op, 30)

c, ta1 = ga.verifyNoActiveAlarm(ID, 'gpio1', relay_debounce_interval/3)
if not c:
    print('CRITICAL - Alarm still active')
    sys.exit(2)

op = ga.closeRelay(relay)
ga.assertOp(op, 30)

op = ga.openRelay(relay)
ga.assertOp(op, 30)

c, ta1 = ga.verifyNoActiveAlarm(ID, 'gpio1', relay_debounce_interval/3)
if not c:
    print('CRITICAL - Alarm still active')
    sys.exit(2)

op = ga.closeRelay(relay)
ga.assertOp(op, 30)
print('OK - Test debouncing in sms mode passed')


# test: measurement created from ping sms and generalabfrage
interval = (sms_report_interval * 3/2)

before_measurements = getMeasurements(ID, 'c8y_SignalStrength')
time.sleep(interval)
after_measurements = getMeasurements(ID, 'c8y_SignalStrength')
if len(after_measurements) - len(before_measurements) > 0 :
	print('OK - Signal measurement created')
	print('OK - Test measurement created from ping sms passed')
else :
	print('CRITICAL - Signal measurement is not created')

# switch to ip mode
op = ga.switchMode(ID, "IP")
c, ta0 = ga.assertOp(op, 360)

if c == 0:
	updatedOperation = ga.getUpdatedOperation(op)
	print('OK - Netcomm switch operation mode to IP is successful')

#IP Communication mode testing

measurement_signal_interval = ip_report_interval * 3/2
before_measurements = getMeasurements(ID, 'c8y_SignalMeasurement')
time.sleep(measurement_signal_interval)
after_measurements = getMeasurements(ID, 'c8y_SignalMeasurement')
if len(after_measurements) - len(before_measurements) > 0:
	print('OK - Signal measurement created')
else :
	print('CRITICAL - Signal measurement is not created')
ga.testAlarmFromGPIO(ID, relay, (relay_debounce_interval * 3/2))
enableSmsMode()

sys.exit(0)