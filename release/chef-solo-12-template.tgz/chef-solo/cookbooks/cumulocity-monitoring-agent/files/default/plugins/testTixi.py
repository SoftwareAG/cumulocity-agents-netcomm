#!/usr/bin/env python2
import sys
import requests
import json
import time
from datetime import datetime, timedelta

import createAlarmsFromGpio as ga

ID = ga.tixiDeviceId
relay = "1"
measurementUrl = "http://c8ytest.cumulocity.com/measurement/measurements/?source={0}&type={1}&dateFrom={2}&dateTo={3}&pageSize=10000"

def createTixiGetOperation (deviceId, operationField):
	data = {
		"deviceId": deviceId,
		"description": "get " + operationField,
		"c8y_Command": {
			"text": "[<Get _=\"" + operationField + "\" ver=\"v\"/>]"
		}
	}
	return requests.post(ga.pushUrl, data=json.dumps(data), 
		auth=ga.auth, headers=ga.headers).json()


def createTixiSetOperation (deviceId, operationField, value):
	data = {
		"deviceId": deviceId,
		"description": "set " + operationField,
		"c8y_Command": {
			"text": "[<Set _=\"" + operationField + "\" value=\"" + value + "\" ver=\"v\"/>]"
		}
	}
	return requests.post(ga.pushUrl, data=json.dumps(data), 
		auth=ga.auth, headers=ga.headers).json()

def createTixiCommandOperation (deviceId, commandText):
	data = {
		"deviceId": deviceId,
		"description": "set " + operationField,
		"c8y_Command": {
			"text": commandText
		}
	}
	return requests.post(ga.pushUrl, data=json.dumps(data), 
		auth=ga.auth, headers=ga.headers).json()

def returnConnectionMode():
	op = createTixiGetOperation(ID, '/Process/PV/isIP')
	time.sleep(5)
	c, ta0 = ga.assertOp(op, 30)
	result_of_cmd_op = "";
	if c == 0:
		updatedOperation = ga.getUpdatedOperation(op)
		# check if result is returned from updated operation
		result_of_cmd_op = ga.assertAndReturnResultOfCommandOperation(updatedOperation)

	return result_of_cmd_op;

def enableIpMode():
	# enable sms mode (managedObject)
	ga.switchMode(ID, "IP")

	result_of_cmd_op = returnConnectionMode();
	if (result_of_cmd_op == 1):
		print('OK - IP mode enabled')
	else :
		print('Critical - enabling IP mode failed')

def enableSmsMode():
	# enable sms mode (managedObject)
	ga.switchMode(ID, "SMS")

	result_of_cmd_op = returnConnectionMode();
	if (result_of_cmd_op == 0):
		print('OK - SMS mode enabled')
	else :
		print('Critical - enabling SMS mode failed')

def getMeasurements(deviceId, type):
	t = time.time()
	today = datetime.fromtimestamp(t)
	tomorrow = today + timedelta(days=+1)
	today = today.strftime("%Y-%m-%d")
	tomorrow = tomorrow.strftime("%Y-%m-%d")
	url = measurementUrl.format(deviceId, type, today, tomorrow)
	measurements = requests.get(url, auth=ga.auth).json()['measurements']
	return measurements

debounceCommand_longInterval = """
[<SetConfig _="PROCCFG/ProcessVars">
	<Gpio1_high>
		<Value>
			<LD v1="/Process/MB/IO/I/P0"/>
			<!-- Debounce setting for gpio1 high flank -->
		    <!-- eg. 500ms, 5s, 2m -->
			<D_ON time="2m"/>
		</Value>
	</Gpio1_high>
</SetConfig>]
[<SetConfig _="PROCCFG/ProcessVars">
	<Gpio1_low>
		<Value>
			<LDN v1="/Process/MB/IO/I/P0"/>
			<!-- Debounce setting for gpio1 low flank -->
		    <!-- eg. 500ms, 5s, 2m -->
			<D_ON time="2m"/>
		</Value>
	</Gpio1_low>
</SetConfig>]
"""

debounceCommand_shortInterval = """
[<SetConfig _="PROCCFG/ProcessVars">
	<Gpio1_high>
		<Value>
			<LD v1="/Process/MB/IO/I/P0"/>
			<!-- Debounce setting for gpio1 high flank -->
		    <!-- eg. 500ms, 5s, 2m -->
			<D_ON time="1ms"/>
		</Value>
	</Gpio1_high>
</SetConfig>]
[<SetConfig _="PROCCFG/ProcessVars">
	<Gpio1_low>
		<Value>
			<LDN v1="/Process/MB/IO/I/P0"/>
			<!-- Debounce setting for gpio1 low flank -->
		    <!-- eg. 500ms, 5s, 2m -->
			<D_ON time="1ms"/>
		</Value>
	</Gpio1_low>
</SetConfig>]
"""
smsPingIntervalCommand = """
[<SetConfig _="PARAM/Parameter/Config">
	<Global>
		<Heartbeat _="Pattern1minutes"/>
		<TimeSync _="Pattern1minutes"/>
		<TimeZone _="+0100"/>
	</Global>
</SetConfig>]
"""

enableSmsMode()

#test: debounce in sms mode
op = createTixiCommandOperation(ID, debounceCommand_longInterval)
ga.assertOp(op, 30)

op = ga.openRelay(relay)
ga.assertOp(op, 30)

c, ta1 = ga.verifyNoActiveAlarm(ID, 'gpio1', 30)
if not c:
    print('CRITICAL - Alarm still active')
    sys.exit(2)

op = ga.closeRelay(relay)
ga.assertOp(op, 30)

op = ga.openRelay(relay)
ga.assertOp(op, 30)
c, ta1 = ga.verifyNoActiveAlarm(ID, 'gpio1', 30)
if not c:
    print('CRITICAL - Alarm still active')
    sys.exit(2)

op = ga.closeRelay(relay)
ga.assertOp(op, 30)

# test measurement created from sms ping interval and generalabfrage
op = createTixiCommandOperation(ID, smsPingIntervalCommand)
before_measurements = getMeasurements(ID, 'c8y_SignalStrength')
time.sleep(interval)
after_measurements = getMeasurements(ID, 'c8y_SignalStrength')
if len(after_measurements) - len(before_measurements) > 0:
	print("OK - Signal measurement created")

# test alarms from gpio
op = createTixiCommandOperation(ID, debounceCommand_shortInterval)
ga.assertOp(op, 30)
ga.testAlarmFromGPIO(ID, relay, 1)

#IP Communication mode testing
enableIpMode()

measurement_polling_time = createTixiGetOperation(ID, 'LogSendTime')
before_measurements = getMeasurements(ID, 'c8y_SignalMeasurement')
time.sleep(measurement_polling_time)
after_measurements = getMeasurements(ID, 'c8y_SignalMeasurement')
if len(after_measurements) - len(before_measurements) > 0:
	print("OK - Signal measurement created")


op = createTixiCommandOperation(ID, debounceCommand_shortInterval)
ga.assertOp(op, 30)
ga.testAlarmFromGPIO(ID, relay, 1)

enableSmsMode()

sys.exit(0)
