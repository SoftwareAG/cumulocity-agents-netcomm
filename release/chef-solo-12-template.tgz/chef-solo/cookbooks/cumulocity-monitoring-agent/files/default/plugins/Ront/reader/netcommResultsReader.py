#!/usr/bin/env python2
import os
import sys

try :
	with open(os.path.join(os.path.dirname(__file__),'../result/netcommTestResults'), 'r') as f :
		returnValue = '0';
		buffer = ''
		errorbuffer = ''
		for line in f.readlines():
			
			result = line.split(',')
			value = result[0]
			message = result[1].replace('\n', '.')

			if (value == '2') :
				returnValue = '2'
			if (returnValue == '0' and value == '1') :
				returnValue = '1'

			buffer += message
		
			if(value == '2' or value == '1') :
				errorbuffer += message
		
		if (returnValue == '2' or returnValue == '1') :
			print 'Errors: ' + errorbuffer

		if (returnValue == '0') :
			print 'Tests are passing.'
			
		print 'Logs: ' + buffer	
		sys.exit(int(returnValue))

except IOError:
	print 'File does not exist'
	sys.exit(3)
