#!/usr/bin/env python

import unittest, sys, time, traceback, httplib, json, imp, os
from datetime import datetime
from time import sleep
imp.load_source('cumulocity', os.path.join(os.path.dirname(__file__), '../fieldbus/cumulocity.py'))
from cumulocity import CumulocityClient
from datetime import datetime
from trackerClient import TrackerClient

'''
--------------------------------------
Configuration
--------------------------------------
'''
if len(sys.argv) != 8:
    print('Expecting 7 parameters <host> <tenant> <username> <password> <trackerAgentHost> <cobanRfvPort> <gl200TelicPort>')
    print('e.g. python trackerTests.py integration.cumulocity.com testtenant admin mypassword integration.cumulocity.com 9090, 9091')
    sys.exit(2)

host = sys.argv[1]
tenant = sys.argv[2]
username = sys.argv[3]
password = sys.argv[4]
trackerAgentHost = sys.argv[5]
cobanRfvPort = int(sys.argv[6])
gl200TelicPort = int(sys.argv[7])

telicImei = '234567'
gl200Imei = '123412341234446'
cobanImei = '888888888888888'
rfvImei = '123412341234556'

class TrackerTests(unittest.TestCase):

    @classmethod
    def setUpClass(self):
        self.client = CumulocityClient(host, tenant, username, password, '10000')
        self.cobanTrackerClient = TrackerClient(trackerAgentHost, cobanRfvPort)
        self.rfvTrackerClient = TrackerClient(trackerAgentHost, cobanRfvPort)
        self.gl200TrackerClient = TrackerClient(trackerAgentHost, gl200TelicPort)
        self.telicTrackerClient = TrackerClient(trackerAgentHost, gl200TelicPort)
        self.registerTrackerDevices()

    @classmethod
    def tearDownClass(self):
        self.cobanTrackerClient.close()
        self.rfvTrackerClient.close()
        self.telicTrackerClient.close()
        self.gl200TrackerClient.close()

    @classmethod
    def registerTrackerDevices(self):
        self.createNewDeviceRequests()
        self.sendRegisterMessages()
        sleep(1)
        self.acceptNewDeviceRequests()
        sleep(1)
        self.sendRegisterMessages()
        sleep(1)
        self.findManagedObjectIds()

    @classmethod
    def findManagedObjectIds(self):
        self.telicDeviceId = self.findManagedObjectId(telicImei)
        self.gl200DeviceId = self.findManagedObjectId(gl200Imei)
        self.cobanDeviceId = self.findManagedObjectId(cobanImei)
        self.rfvDeviceId = self.findManagedObjectId(rfvImei)

    @classmethod
    def acceptNewDeviceRequests(self):
        self.client.acceptNewDeviceRequest(telicImei)
        self.client.acceptNewDeviceRequest(gl200Imei)
        self.client.acceptNewDeviceRequest(cobanImei)
        self.client.acceptNewDeviceRequest(rfvImei)

    @classmethod
    def createNewDeviceRequests(self):
        self.client.createNewDeviceRequest(telicImei)
        self.client.createNewDeviceRequest(gl200Imei)
        self.client.createNewDeviceRequest(cobanImei)
        self.client.createNewDeviceRequest(rfvImei)

    @classmethod
    def sendRegisterMessages(self):
        self.sendTelicRegisterMessage()
        self.sendGl200RegisterMessage()
        self.sendCobanRegisterMessage()
        self.sendRfvRegisterMessage()

    @classmethod
    def sendTelicRegisterMessage(self):
        self.telicTrackerClient.sendMessage('0000123456|262|02|003002016000000721' + telicImei + '99,200311121210,0,200311121210,115864,480332,3,4,67,4,,,599,11032,,0000,00,238,0,0,0\00')

    @classmethod
    def sendGl200RegisterMessage(self):
        self.gl200TrackerClient.sendMessage('+RESP:GTFRI,02010B,' + gl200Imei + ',,0,0,2,1,4.3,92,70.0,121.354335,31.222073,20090214013254,0460,0000,18d8,6141,00,0,4.3,92,70.0,121.354336,31.222074,20090101000000,04 60,0000,18d8,6142,00,,20090214093254,11F0$')

    @classmethod
    def sendCobanRegisterMessage(self):
        self.cobanTrackerClient.sendMessage('##,imei:' + cobanImei + ',A;')

    @classmethod
    def sendRfvRegisterMessage(self):
        self.rfvTrackerClient.sendMessage('*DB,' + rfvImei + ',LINK,,,,,,010316,FFFFFFFF#')

    @classmethod
    def findManagedObjectId(self, imei):
        externalId = self.client.getExternalId('c8y_Imei', imei)
        return externalId['managedObject']['id']

    def test_telicLocationUpdate(self):
        self.telicTrackerClient.close()
        self.telicTrackerClient = TrackerClient(trackerAgentHost, gl200TelicPort)
        before = time.gmtime()
        sleep(1)
        telicNow = telicDateTimeString(datetime.now())
        self.telicTrackerClient.sendMessage(buildTelicMessage(telicImei, telicNow, telicNow, 110000, 480000, 3, 40, 5, 600, 7000, 1111, 1000))
        sleep(3)
        after = time.gmtime()
        # Measurements: altitude, speed, milage, battery
        measurements = self.client.getMeasurementsForSourceAndTime(self.telicDeviceId, before, after)
        self.assertEquals(len(measurements), 4)
        for measurement in measurements:
            if measurement['type'] == 'c8y_Altitude':
                self.assertEquals(measurement['c8y_Altitude']['altitude']['value'], 600)
            if measurement['type'] == 'c8y_Speed':
                self.assertEquals(measurement['c8y_SpeedMeasurement']['speed']['value'], 40)
            if measurement['type'] == 'c8y_TrackerMileage':
                self.assertEquals(measurement['c8y_TrackerMileage']['c8y_DistanceMeasurement']['value'], 7)
            if measurement['type'] == 'c8y_TrackerBattery':
                self.assertEquals(measurement['c8y_TrackerBattery']['level']['value'], 1000)

        # Events: charger connected, location
        events = self.client.getEventsForSourceAndTime(self.telicDeviceId, before, after)
        self.assertEquals(len(events), 2)
        for event in events:
            if event['type'] == 'c8y_ChargerConnected':
                self.assertEquals(event['text'], 'Charger connected')
            if event['type'] == 'c8y_LocationUpdate':
                self.assertEquals(event['c8y_Position']['satellitesForCalculation'], 5)
                self.assertEquals(event['c8y_Position']['fixType'], '3D Fix')
                self.assertEquals(event['c8y_Position']['lat'], 48)
                self.assertEquals(event['c8y_Position']['lng'], 11)
                self.assertEquals(event['c8y_Position']['alt'], 600)
        # Invenory: position
        managedObject = self.client.getManagedObject(self.telicDeviceId)
        self.assertEquals(managedObject['c8y_Position']['satellitesForCalculation'], 5)
        self.assertEquals(managedObject['c8y_Position']['fixType'], '3D Fix')
        self.assertEquals(managedObject['c8y_Position']['lat'], 48)
        self.assertEquals(managedObject['c8y_Position']['lng'], 11)
        self.assertEquals(managedObject['c8y_Position']['alt'], 600)

    def test_gl200SingleLocationUpdate(self):
        before = time.gmtime()
        sleep(1)
        self.gl200TrackerClient.sendMessage(buildGl200SingleLocationReport(gl200Imei, 12.34, 45.67, 89.01, 23.45))
        sleep(3)
        after = time.gmtime()
        # Measurements: milage
        measurements = self.client.getMeasurementsForSourceAndTime(self.gl200DeviceId, before, after)
        self.assertEquals(len(measurements), 1)
        self.assertEquals(measurements[0]['type'], 'c8y_TrackerMileage')
        self.assertEquals(measurements[0]['c8y_TrackerMileage']['c8y_DistanceMeasurement']['value'], 23.45)
        # Events: location
        events = self.client.getEventsForSourceAndTime(self.gl200DeviceId, before, after)
        self.assertEquals(len(events), 1)
        self.assertEquals(events[0]['type'], 'c8y_LocationUpdate')
        self.assertEquals(events[0]['c8y_Position']['alt'], 12.34)
        self.assertEquals(events[0]['c8y_Position']['lng'], 45.67)
        self.assertEquals(events[0]['c8y_Position']['lat'], 89.01)
        # Inventory: position
        managedObject = self.client.getManagedObject(self.gl200DeviceId)
        self.assertEquals(managedObject['c8y_Position']['lat'], 89.01)
        self.assertEquals(managedObject['c8y_Position']['lng'], 45.67)
        self.assertEquals(managedObject['c8y_Position']['alt'], 12.34)

    def test_cobanPositionUpdate(self):
        before = time.gmtime()
        sleep(1)
        self.cobanTrackerClient.sendMessage(buildCobanPositionUpdate(cobanImei, 12.34, 56.78, 90))
        sleep(3)
        after = time.gmtime()
        # Measurements: speed
        measurements = self.client.getMeasurementsForSourceAndTime(self.cobanDeviceId, before, after)
        self.assertEquals(len(measurements), 1)
        self.assertEquals(measurements[0]['type'], 'c8y_Speed')
        self.assertEquals(measurements[0]['c8y_SpeedMeasurement']['speed']['value'], 166)
        # Events: location
        events = self.client.getEventsForSourceAndTime(self.cobanDeviceId, before, after)
        self.assertEquals(len(events), 1)
        self.assertEquals(events[0]['type'], 'c8y_LocationUpdate')
        self.assertEquals(events[0]['c8y_Position']['alt'], 0)
        self.assertEquals(events[0]['c8y_Position']['lng'], 0.9463333)
        self.assertEquals(events[0]['c8y_Position']['lat'], 0.2056667)
        self.assertEquals(events[0]['c8y_SpeedMeasurement']['speed']['value'], 166)
        # Inventory: position
        managedObject = self.client.getManagedObject(self.cobanDeviceId)
        self.assertEquals(managedObject['c8y_Position']['lat'], 0.2056667)
        self.assertEquals(managedObject['c8y_Position']['lng'], 0.9463333)
        self.assertEquals(managedObject['c8y_Position']['alt'], 0)

    def testRfvPositionUpdate(self):
        before = time.gmtime()
        sleep(1)
        self.rfvTrackerClient.sendMessage(buildRfvPositionUpdate('me', rfvImei, 12.34, 56.78, 90, datetime.now()))
        sleep(3)
        after = time.gmtime()
        # Measurements: speed
        measurements = self.client.getMeasurementsForSourceAndTime(self.rfvDeviceId, before, after)
        self.assertEquals(len(measurements), 1)
        self.assertEquals(measurements[0]['type'], 'c8y_Speed')
        self.assertEquals(measurements[0]['c8y_SpeedMeasurement']['speed']['value'], 166)
        # Events: location
        events = self.client.getEventsForSourceAndTime(self.rfvDeviceId, before, after)
        self.assertEquals(len(events), 1)
        self.assertEquals(events[0]['type'], 'c8y_LocationUpdate')
        self.assertEquals(events[0]['c8y_Position']['alt'], 0)
        self.assertEquals(events[0]['c8y_Position']['lng'], 0.9463333)
        self.assertEquals(events[0]['c8y_Position']['lat'], 0.2056667)
        self.assertEquals(events[0]['c8y_SpeedMeasurement']['speed']['value'], 166)
        # Inventory: position
        managedObject = self.client.getManagedObject(self.rfvDeviceId)
        self.assertEquals(managedObject['c8y_Position']['lat'], 0.2056667)
        self.assertEquals(managedObject['c8y_Position']['lng'], 0.9463333)
        self.assertEquals(managedObject['c8y_Position']['alt'], 0)

def startTests():
    del sys.argv[1:]
    suite = unittest.TestLoader().loadTestsFromTestCase(TrackerTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        print('OK - ' + str(result.testsRun) + ' tests passed.')
        sys.exit(0)
    else:
        print('CRITICAL - failures in tests: ' + buildErrorText(result))
        sys.exit(2)

def buildErrorText(result):
    failures = result.failures
    text = ''
    for test, trace in failures:
        print('test: {test}, trace {trace}'.format(test=test, trace=trace))
        text += ', '
        text += test.id().replace("__main__.", "")
    errors = result.errors
    for test, trace in errors:
        print('test: {test}, trace {trace}'.format(test=test, trace=trace))
        text += ', '
        text += test.id().replace("__main__.", "")
    if len(text) > 2:
        return text[2:]

def telicDateTimeString(datetime):
    return datetime.strftime('%d%m%y%H%M%S')

def rfvTimeString(datetime):
    return datetime.strftime('%H%M%S')

def rfvDateString(datetime):
    return datetime.strftime('%d%m%y')

def buildTelicMessage(imei, logTime, gpsTime, long, lat, fixType, speed, sattelites, alt, milage, digitalInput, battery):
    return '0000123456|262|02|003002016000000721{imei}99,{logTime},0,{gpsTime},{long},{lat},{fixType},{speed},67,{sattelites},,,{alt},{milage},,{digitalInput},00,{battery},0,0,0\00'.format(imei=imei, logTime=logTime, gpsTime=gpsTime, long=long, lat=lat, fixType=fixType, speed=speed, sattelites=sattelites, alt=alt, milage=milage, digitalInput=digitalInput, battery=battery)

def buildCobanPositionUpdate(imei, lat, long, speed):
    return 'imei:{imei},tracker,0809231929,,F,055403.000,A,{lat},N,{long},E,{speed},,;'.format(imei=imei, lat=lat, long=long, speed=speed)

def buildRfvPositionUpdate(maker, imei, lat, long, speed, datetime):
    return '*{maker},{imei},V1,{time},A,{lat},N,{long},E,{speed},,{date},FFFFFFFF#'.format(maker=maker, imei=imei, time=rfvTimeString(datetime), lat=lat, long=long, speed=speed, date=rfvDateString(datetime))

def buildGl200SingleLocationReport(imei, alt, long, lat, milage):
    return '+RESP:GTFRI,02010B,{imei},,0,0,1,1,{milage},92,{alt},{long},{lat},20090 214013254,0460,0000,18d8,6141,00,0,{milage}$'.format(imei=imei, alt=alt, long=long, lat=lat, milage=milage)

try:
    startTests()
except Exception as e:
    print('CRITICAL - unexpected error in test execution:')
    traceback.print_exc()
    sys.exit(2)
