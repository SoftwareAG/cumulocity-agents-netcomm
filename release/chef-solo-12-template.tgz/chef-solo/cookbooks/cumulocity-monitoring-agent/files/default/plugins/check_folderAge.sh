#!/bin/bash

FOLDER=$1
FILETYPE=$2
OLDERTHAN=$3

RESULT=`find ${FOLDER} -maxdepth 1 -name "${FILETYPE}" -type d -mmin +${OLDERTHAN} |wc -l`

if [[ $RESULT -eq 0 ]]; then
    CHECK="OK"
else
    CHECK="Failed"
fi

if [[ "$CHECK" == "OK" ]]; then
  echo "SERVICE OK"
  exit 0
elif [[ "$CHECK" == "Failed" ]]; then
  echo "folder ${FOLDER}/${FILETYPE} not updated in last ${OLDERTHAN} minutes!"
  exit 2
else
  echo "Check failed"
  exit 3
fi
