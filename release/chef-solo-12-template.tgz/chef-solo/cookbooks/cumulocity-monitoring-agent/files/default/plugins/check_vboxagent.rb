#!/usr/bin/env ruby
require 'socket'

case ARGV[0]
    when "1" 
port=8188
    when "2" 
port=8288
    when "3" 
port=8388
end

sendbyte1 = ARGV[1].scan(/../).map(&:hex).to_a
sendbyte2 = ARGV[2].scan(/../).map(&:hex).to_a
expectedr = ARGV[3]

if File.sticky?(__FILE__)
    somefile = File.open('/tmp/testnag.log', "a")
    somefile.puts "#{ARGV[0]} #{ARGV[1]} #{ARGV[2]} #{ARGV[3]}"
end

host = 'localhost'
begin
s = TCPSocket.new(host, port)

# Register:
  s.write sendbyte1.pack('C*')
  resp=s.recv(1024).unpack("'H*'")
  sleep(1)
# Request:
  if sendbyte2.length>1
    s.write sendbyte2.pack('C*')
    resp=s.recv(1024).unpack("'H*'")
  end
# Response:
  s.close
 puts resp[0].to_s if File.sticky?(__FILE__)
 puts expectedr.to_s if File.sticky?(__FILE__)
  if resp[0].match expectedr
    puts "SERVICE OK on port #{port}"
    exit(0)
  else
    puts "ERROR! Wrong response"
    exit(1)
  end

rescue
puts "ERROR! No response"
exit(1)
end

