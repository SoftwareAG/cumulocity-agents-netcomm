#!/usr/bin/env python2

import json
import sys
import time

import requests


auth = requests.auth.HTTPBasicAuth("scriptUser", "resUtpircs")
tixiDeviceId = "33439424"
netcommDeviceId = "30439559"
cinterionDeviceId = None  #"25954000"
raspberryDeviceId = "30499448"
pushUrl = "http://c8ytest.cumulocity.com/devicecontrol/operations/"
alarmUrl = "http://c8ytest.cumulocity.com/alarm/alarms/?source={0}&status={1}"
headers = {"Content-Type": "application/json", "Accept": "application/json"}


def closeRelay(relay):
    if cinterionDeviceId != None :
        return _sendRelayOperation(relay, 'CLOSE')
    elif raspberryDeviceId != None :
        return _sendRelayArrayOperation(relay, 'CLOSED')

def openRelay(relay):
    if cinterionDeviceId != None :
        return _sendRelayOperation(relay, 'OPEN')
    elif raspberryDeviceId != None :
        return _sendRelayArrayOperation(relay, 'OPEN')


def _sendRelayArrayOperation(relayNumber, action):
    relayArray = ['OPEN', 'OPEN']
    relayArray[int(relayNumber) - 1] = action
    data = {"c8y_RelayArray": relayArray,
            "deviceId": raspberryDeviceId, 'description': action + ' relay ' + relayNumber}
    return requests.post(pushUrl, data=json.dumps(data), auth=auth,
                         headers=headers).json()

def _sendRelayOperation(relayNumber, action):
    data = {"c8y_Relay": {"number": relayNumber, "action": action},
            "deviceId": cinterionDeviceId, 'description': action + ' relay'}
    return requests.post(pushUrl, data=json.dumps(data), auth=auth,
                         headers=headers).json()

def switchMode(deviceId, mode):
    data = {'c8y_CommunicationMode': {'mode': mode}, 'deviceId': deviceId,
            'description': 'switch to ' + mode + ' mode'}
    return requests.post(pushUrl, data=json.dumps(data), auth=auth,
                         headers=headers).json()


def verifyOperation(opId, timeout):
    dt = min(5, timeout//10)
    t0 = time.time()
    while time.time() - t0 <= timeout:
        response = requests.get(pushUrl + opId, auth=auth).json()
        opStatus = response["status"]
        if opStatus == "SUCCESSFUL":
            return 0, int(time.time() - t0)
        elif opStatus == "FAILED":
            return 1, int(time.time() - t0)
        time.sleep(dt)
    return 2, int(time.time() - t0)


def _getActiveAlarms(deviceId, t):
    url = alarmUrl.format(deviceId, 'ACTIVE')
    alarms = requests.get(url, auth=auth).json()['alarms']
    return filter(lambda x: x['type'] == t, alarms)


def verifyAlarmActive(deviceId, alarmType, timeout):
    t0 = time.time()
    dt = min(5, timeout//10)
    while time.time() - t0 <= timeout:
        alarms = list(map(lambda x: x['count'],
                          _getActiveAlarms(deviceId, alarmType)))
        if alarms:
                return True, int(time.time() - t0)
        time.sleep(dt)
    return False, int(time.time() - t0)


def verifyNoActiveAlarm(deviceId, alarmType, timeout):
    t0 = time.time()
    dt = min(5, timeout//10)
    while time.time() - t0 <= timeout:
        alarms = list(map(lambda x: x['count'],
                          _getActiveAlarms(deviceId, alarmType)))
        if not alarms:
                return True, int(time.time() - t0)
        time.sleep(dt)
    return False, int(time.time() - t0)


def assertOp(op, timeout):
    c, t = verifyOperation(op['id'], timeout)
    if c == 1:
        print('CRITICAL - Op %s(%s) failed!' % (op['id'], op['description']))
        sys.exit(2)
    elif c == 2:
        print('CRITICAL - Op %s(%s) timeout!' % (op['id'], op['description']))
        sys.exit(2)
    return c, t


def getUpdatedOperation (operation):
    updatedOperation = requests.get(pushUrl + operation['id'], auth=auth).json()
    return updatedOperation

def assertAndReturnResultOfCommandOperation (operation):
    result = operation['c8y_Command']['result']
    if result is None:
        print("CRITICAL - command operation does not have result")
    else:
        print("OK - command operation is successful")
    return result

def testAlarmFromGPIO(deviceId, relay, timeout):
    op = openRelay(relay)
    assertOp(op, 30)
    c, ta0 = verifyAlarmActive(deviceId, 'gpio'+relay, timeout)
    if not c:
        print('CRITICAL - Alarm not created')
        sys.exit(2)

    op = closeRelay(relay)
    assertOp(op, 30)

    c, ta1 = verifyNoActiveAlarm(deviceId, 'gpio'+relay, timeout)
    if not c:
        print('CRITICAL - Alarm still active')
        sys.exit(2)

    output = "OK - Alarm create in {0} s, clear in {1} s | create={2} clear={3}"
    print(output.format(ta0, ta1, ta0, ta1))
