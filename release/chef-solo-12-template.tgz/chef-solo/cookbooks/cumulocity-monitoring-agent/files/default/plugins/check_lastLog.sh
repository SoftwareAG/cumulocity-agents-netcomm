#!/bin/bash

FOLDER="/var/log/chef/client.log"

RESULT=`tail -n 1 ${FOLDER} |grep " ERROR:\| FATAL:"`

if [[ -z $RESULT ]]; then
    CHECK="OK"
else
    CHECK="Failed"
fi

if [[ "$CHECK" == "OK" ]]; then
  echo "SERVICE OK"
  exit 0
elif [[ "$CHECK" == "Failed" ]]; then
  echo "${RESULT}"
  exit 2
else
  echo "Check failed"
  exit 3
fi
