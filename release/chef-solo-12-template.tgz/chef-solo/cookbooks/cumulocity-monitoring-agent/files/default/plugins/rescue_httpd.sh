#!/bin/sh
#
# Event handler script for restarting the web server on the local machine
#
# Note: This script will only restart the web server if the service is
#       retried 3 times (in a "soft" state) or if the web service somehow
#       manages to fall into a "hard" error state.
#

# What state is the HTTP service in?

function logstatus  {
    LSTAT="`date`\t ${0##*/}\t $1 $2 $3"
    echo -e $LSTAT |sudo tee -a /var/log/nagios_rescue.log > /dev/null
}

case "$1" in
OK)
	# The service just came back up, so don't do anything...
	;;
WARNING)
	# We don't really care about warning states, since the service is probably still running...
	;;
UNKNOWN)
	# We don't know what might be causing an unknown error, so don't do anything...
	;;
CRITICAL)
	# Aha!  The HTTP service appears to have a problem - perhaps we should restart the server...

	# Is this a "soft" or a "hard" state?
	case "$2" in
		
	# We're in a "soft" state, meaning that Nagios is in the middle of retrying the
	# check before it turns into a "hard" state and contacts get notified...
	SOFT)
			
		case "$3" in
				
		3)
			echo -n "Restarting HTTP service (3rd soft critical state)..."
			# Call the init script to restart the HTTPD server
			sudo /etc/init.d/httpd restart
			logstatus $1 $2 $3
			;;
			esac
		;;
				
	HARD)
		echo -n "Restarting HTTP service..."
		# Call the init script to restart the HTTPD server
		sudo /etc/init.d/httpd restart
		logstatus $1 $2 $3
		;;
	esac
	;;
esac
exit 0

