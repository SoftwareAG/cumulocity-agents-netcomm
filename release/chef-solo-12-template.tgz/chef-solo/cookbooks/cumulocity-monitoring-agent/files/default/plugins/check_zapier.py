#!/usr/bin/env python

import time, imp, os, sys
imp.load_source('cumulocity', os.path.join(os.path.dirname(__file__), 'fieldbus/cumulocity.py'))
from cumulocity import CumulocityClient
from datetime import datetime

zapierDevice = '31821593'
eventType = 'c8y_ZapierE2ENewEvent'
newDeviceRequestId = 'zapierE2ETestc8ytest'
successful = True

client = CumulocityClient('developer.cumulocity.com', 'c8ytest', 'scriptUser', 'resUtpircs', '31821593')

eventText = str(time.time())

before = time.gmtime()
client.createEvent(eventType, eventText, zapierDevice)
client.createEvent("c8y_LocationUpdate", "LocUpdate", zapierDevice, { "c8y_Position": {
    	"alt": 67,
      	"lng": 6.7303924,
      	"lat": 53.2433101 }})
time.sleep(15)

after = time.gmtime()
existingNewDeviceRequest = client.getNewDeviceRequest(newDeviceRequestId)
if existingNewDeviceRequest is None:
  print 'CRITICAL - device registration was not created'
  successful = False

operations = client.getPendingOperations(zapierDevice)
if operations is None:
  print 'CRITICAL - could not find operations'
  successful = False
else:
  if len(operations) is not 2:
    print 'CRITICAL - could not find exactly 2 operations'
    successful = False
  else:
    keys = operations[0].keys() + operations[1].keys()
    if not "c8y_Restart" in keys:
      print 'CRITICAL - could not find restart operations'
      successful = False
    elif not "c8y_CustomOperation" in keys:
      print 'CRITICAL - could not find custom operations'
      successful = False

device = client.getManagedObject(zapierDevice)
if not device['c8y_ZapierE2E']['value'] == eventText:
  print 'CRITICAL - device update was not successful'
  successful = False

successEvent = client.getEventsForTimeAndType(before, after, "c8y_ZapierSuccesfulNewEvent")
if not len(successEvent) == 1:
  print 'CRITICAL - sucess event from Zapier missing'
  successful = False

successEventSmartRule = client.getEventsForTimeAndType(before, after, "c8y_ZapierSuccesfulNewSmartRuleEvent")
if not len(successEvent) == 1:
  print 'CRITICAL - sucess SmartRule event from Zapier missing'
  successful = False

# clean up
client.deleteNewDeviceRequest(newDeviceRequestId)
for op in operations:
  client.failOperation(op['id'])
client.createEvent("c8y_LocationUpdate", "LocUpdate", zapierDevice, { "c8y_Position": {
      "alt": 67,
        "lng": 6.7303924,
        "lat": 51.2433101 }})

if successful:
  print 'OK - All Zapier data created correctly.'
else:
  sys.exit(2)
