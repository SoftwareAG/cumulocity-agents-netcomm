default['backup_script']['snapshots'] = false
default['backup_script']['AMIs'] = false

default['backup_script']['http_proxy'] = nil
default['backup_script']['AWS_SECRET_ACCESS_KEY'] = "insert here your AWS_SECRET_ACCESS_KEY"
default['backup_script']['AWS_ACCESS_KEY_ID'] = "insert here your AWS_ACCESS_KEY_ID"

default['backup_script']['smtp_relay'] = nil
default['backup_script']['mail_from'] = nil
default['backup_script']['rcpt_to'] = nil
