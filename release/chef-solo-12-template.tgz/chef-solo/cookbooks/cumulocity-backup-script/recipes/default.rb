#
# Cookbook Name:: cumulocity-backup-script
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

include_recipe 'yum-epel'

package "python-pip" do
  action :install
end

execute "install_awscli" do
  command "pip install awscli"
end

directory "/root/backup_script" do
  mode   "0755"
  owner  "root"
  group  "root"
end

cookbook_file "/root/backup_script/ami_snapshots_management.sh" do
  source "ami_snapshots_management.sh"
  mode   "0755"
  owner  "root"
  group  "root"
end

template "/root/backup_script/ami_snapshots_management.conf" do
  source "ami_snapshots_management.conf.erb"
  mode   "0600"
  owner  "root"
  group  "root"
end

cookbook_file "/root/backup_script/cron_scheduler.sh" do
  source "cron_scheduler.sh"
  mode   "0755"
  owner  "root"
  group  "root"
end

if node['backup_script']['snapshots'] and ( node['roles'].include? "cumulocity-mongo" or node['roles'].include? "cumulocity-sql-db" )
  execute "configure_snapshot_backup" do
    command "/root/backup_script/cron_scheduler.sh -e #{node.chef_environment} -s"
  end
end

if node['backup_script']['AMIs']
  execute "configure_snapshot_backup" do
    command "/root/backup_script/cron_scheduler.sh -e #{node.chef_environment} -a"
  end
end

