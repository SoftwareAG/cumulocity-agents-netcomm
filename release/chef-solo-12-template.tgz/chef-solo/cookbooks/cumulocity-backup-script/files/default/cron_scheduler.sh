#!/bin/bash

debug=false

while getopts "e:as" opt ; do
  case $opt in
    e) env=$OPTARG ;;
    a) createami=true ;;
    s) createsnap=true ;;
  esac
done

if [[ -z $env ]] ; then
  echo "option missing"
  exit 250
fi

debug_pr(){
  ${debug:-false} && printf "%15s --> %s\n" $1 "$( eval echo \$$1 )"
}

md5sum=$( md5sum <<< "${env}" | sed 's/[^0-9a-z]//g' )
debug_pr md5sum
hashnum="$((0x${md5sum%% *}))"
hashnum="${hashnum##-}"
debug_pr hashnum

declare d=0
chars="$(( $( wc -c <<< $hashnum ) -1 ))"
debug_pr chars

#arg1=limit
randtime(){
  local num
  while [[ ${num:-25} -gt $1 ]] ; do
    if [[ $d -le $chars ]] ; then
      num="$( cut -c $(( 1 + $d )) <<< $hashnum )"
      (( d++ ))
    else
      num=0
    fi
  done
  echo $num
  return $d
}

sched(){
  amihour="${amihour:-$( randtime 3 )}" d=$?
  debug_pr amihour
  debug_pr d
  dmin="${dmin:-$( randtime 5 )}" d=$?
  debug_pr dmin
  debug_pr d
  umin="${umin:-$( randtime 9 )}" d=$?
  debug_pr umin
  debug_pr d
  amimin="$( sed -r 's/^0?(.*)/\1/g' <<< "${dmin}${umin}" )"
  snaphour="$amihour"
  debug_pr snaphour
  snapmin="$(( $amimin + 5 ))"
  if [[ $snapmin -gt 59 ]] ; then
    snapmin="$(( $snapmin - 60 ))"
    debug_pr snapmin
    (( snaphour++ ))
    debug_pr snaphour
  fi
}

#sched
#echo " amitime--> ${amihour}:${amimin}"
#echo "snaptime--> ${snaphour}:${snapmin}"

if ${createsnap:-false} && ! egrep -q "ami_snapshots_management.sh .*-[a-z]*b" /etc/crontab ; then
  echo "Configuring snapshot cronjob..."
  sched
  cat >> /etc/crontab << EOF
# Backup for DB volumes
${snapmin} ${snaphour} * * *  root /root/backup_script/ami_snapshots_management.sh -ybDR30 &>> /root/backup_script/ami_snapshots_management.log

EOF
elif ${createsnap:-false} ; then
  echo "Cronjob for snapshot already present"
fi

if ${createami:-false} && ! egrep -q "ami_snapshots_management.sh .*-[a-z]*c" /etc/crontab ; then
  echo "Configuring AMI cronjob..."
  sched
  cat >> /etc/crontab << EOF
# Backup for ROOT volumes
${amimin} ${amihour} * * 6  root /root/backup_script/ami_snapshots_management.sh -ycdr6 &>> /root/backup_script/ami_snapshots_management.log

EOF
elif ${createami:-false} ; then
  echo "Cronjob for AMI already present"
fi

