#!/bin/bash

# default parameters

f_helpMsg(){
  echo "Usage: $0 --createami --deleteoldamis [--extrainstanceid=i-xxxxxxxx --extrainstanceid=i-yyyyyyyy] --backupvolumes [--preservebackup] --deletesnapshots [--include=vol-xxxxxxxx --include=vol-yyyyyyyy] [--exclude=/dev/sdX --exclude=/dev/xvdX] [--amiretentiondays=7] [--snapshotretentiondays=7] [--yes] [--test] [--notify]
  -c, --createami		Create AMI of current instance
  -d, --deleteoldamis		Delete AMIs older than amiretentiondays
      --extrainstanceid		Check AMIs related to specified instance too
  -r, --amiretentiondays	Parameter for deleting AMIs expressed in number of days. Default: 7
  -b, --backupvolumes		Take a snapshot of non-root volumes
  -D, --deletesnapshots		Delete Snapshots older than snapshotretentiondays
      --backupeverything	Take full backup of every volume, including root and swaps (applys on both on AMI and backup creation)
      --include			Include aws volume in backup rotation for deletion
      --exclude			Exclude block device from AMI creation and backup snapshots
  -P, --preservebackup		Tag Snapshot with 'Preserve' tag, so that it will not be deleted in future rotations
  -R, --snapshotretentiondays	Parameter for deleting Snapshots expressed in number of days. Default: 7
  -y, --yes			Assume always 'yes' answer to deletion requests
  -t, --test			Dry run, just test if operations are possible
  -n, --notify			Send an email if AMI or Backup creation fails (only if --test option is not used)
      --nocolors		Set black and white output
  -h, --help			Shows this message

Examples:
  Creating AMI and rotate older than 6 days ones:
    $0 -cdr6
  Taking snapshot and rotate older than 30 days ones:
    $0 -bDR30
"
}

# arg1=color arg2=string
f_color_pr(){
  if ${nocolors:-false} ; then
    shift
    printf -- "$@\n"
  else
    case $1 in
      grn) COLOR='\e[1;32m' ;;
      ylw) COLOR='\e[1;33m' ;;
      red) COLOR='\e[1;31m' ;;
      cyn) COLOR='\e[1;36m' ;;
    esac
    shift
    printf "$COLOR""$@\n"'\e[m'
  fi
}

while getopts "hr:R:PcdDbytn-:" opt ; do
  case "$opt" in
    -) case $OPTARG in
         amiretentiondays=*) amiretentiondays="${OPTARG#*=}" ;;
                  createami) createimage=true ;;
              deleteoldamis) deleteimage=true ;;
          extrainstanceid=*) extrainstanceids+="${OPTARG#*=} " ;;
              backupvolumes) backupvolumes=true ;;
            deletesnapshots) deletesnapshots=true ;;
           backupeverything) backupeverything=true ;;
                  include=*) volumestoincludeinrotation+="${OPTARG#*=} " ;;
                  exclude=*) volumestoexclude+="$( sed -r 's@(xvd|sd)@sd@g' <<< "${OPTARG#*=}" ) " ;;
             preservebackup) preservebackup=true ;;
                        yes) autoyes="yes" ;;
                       test) dryrun=true ;;
                     notify) notify=true ;;
                   nocolors) nocolors=true ;;
                       help) f_helpMsg && exit ;;
                          *) f_color_pr red "ERROR: ${OPTARG} is an invalid option!!" && f_helpMsg && exit 3;;
       esac ;;
    r) amiretentiondays="$OPTARG" ;;
    R) snapshotretentiondays="$OPTARG" ;;
    P) preservebackup=true ;;
    c) createimage=true ;;
    d) deleteimage=true ;;
    b) backupvolumes=true ;;
    D) deletesnapshots=true ;;
    y) autoyes="yes" ;;
    t) dryrun=true ;;
    n) notify=true ;;
    h) f_helpMsg && exit ;;
    *) f_color_pr red "ERROR: ${opt} is an invalid option!!" && f_helpMsg && exit 3;;
  esac
done

amiretentionsecs="$(( ${amiretentiondays:-7} * 86400 ))"
snapshotretentionsecs="$(( ${snapshotretentiondays:-7} * 86400 ))"

# define these variables here, or in an external .conf file with same name as script:

#export HTTP_PROXY="http://<proxy:14239>"
#export HTTPS_PROXY="http://<proxy:14239>"

#export AWS_SECRET_ACCESS_KEY=
#export AWS_ACCESS_KEY_ID=

#export smtp_server="smtp://<server>
#export mail_from="<mail@address>"
#export rcpt_to="<mail@address>"

####################

# load settings:

thisscript=$(readlink -f ${BASH_SOURCE[0]})
configfile="$( dirname ${thisscript} )/$( basename ${thisscript} sh)conf"
[[ -f "$configfile" ]]  && . "$configfile"

####################

if ${dryrun:-false} ; then
  extra_options+="--dry-run"
fi


declare -a abl
abl=( {a..z} )
declare -A abi
I=0
for L in {a..z} ; do
  abi[$L]=$((I++))
done

# no_args
f_guessDeviceMapping(){
  local listblockdev="$( find /dev -maxdepth 1 -type b \( -name "sd?" -o -name "xvd?" \) | sort )"
  local firstsysL="$( head -n1 <<< "$listblockdev" | \grep -o '.$' | tr -d '\n' )"
  difference="${abi[$firstsysL]}"
  for d in $listblockdev ; do
    f_color_pr grn "  $d ==> $( f_sysToAwsName $d )"
  done
}

# arg1="system block device"
f_sysToAwsName(){
  local awsL sysL
  sysL="$( \grep -o '.$' <<< "$1" )"
  awsL="${abl[${abi[$sysL]}-${difference:-0}]}"
  sed -r -e "s@.\$@$awsL@g" -e 's@(xvd|sd)@sd@g' <<< "$1"
}

# arg1="aws virtual device"
f_awsToSysName(){
  local awsL sysL
  awsL="$( sed 's/[0-9]*$//g' <<< "$1" | \grep -o '.$' )"
  sysL="${abl[${abi[$awsL]}+${difference:-0}]}"
  sed "s@[a-z][0-9]*\$@$sysL@g" <<< "$1"
}

# no_args
f_fetchInfo(){
  f_color_pr cyn "-- $( date )\n"
  f_color_pr cyn "Fetching information from current aws instance..."
  # instance-data or 169.254.169.254
  instanceid="$( wget --no-proxy -qO- http://169.254.169.254/latest/meta-data/instance-id )"
  regionid="$( wget --no-proxy -qO- http://169.254.169.254/latest/meta-data/placement/availability-zone | sed -r 's:([0-9][0-9]*)[a-z]*$:\1:' )"
  tagname="Name"
  instancename="$( aws ec2 describe-tags --filters "Name=resource-id,Values=$instanceid" "Name=key,Values=$tagname" --region $regionid --output=text | cut -f5 )"
  #me="$( aws iam get-user --output=text | sed -r 's/.+arn:aws:iam::([0-9]+):user.+/\1/g' )"
  me="$( aws sts get-caller-identity --query='Account' --output=text )"
  f_color_pr grn "  AwsUserID:    ${me}"
  f_color_pr grn "  InstanceID:   ${instanceid}"
  f_color_pr grn "  InstanceName: ${instancename}"
  f_color_pr grn "  RegionID:     ${regionid}"
}

# arg1="mail subject" arg2="mail body"
f_notify(){
  if ( ${notify:-false} && ! ${dryrun:-false} ) ; then
    mailx -s "$1" ${smtp_server:+-S "smtp=$smtp_server"} ${mail_from:+-S "from=$mail_from"} "$rcpt_to" <<< "$2" &>/dev/null
  fi
}

# arg1="text to clean"
f_textCleaner(){
  sed -r 's/[^0-9a-zA-Z().-\/_-]/_/g' <<< "$@"
}

# argX="device to exclude"
f_createImage(){
  if [[ ! -z $@ ]] ; then
    p=1
    bdm='['
    for dev in $@ ; do
      bdm+='{"DeviceName":"'$dev'","NoDevice":""}'
      if [[ $(( p++ )) -lt $# ]] ; then
        bdm+=','
      fi
    done
    bdm+=']'
  fi
  aws ec2 create-image \
    --region "${regionid}" \
    --instance-id "${instanceid}" \
    --name "ami-$( date +%Y%m%d-%H%M%S )-$( f_textCleaner ${instancename} )" \
    --description "AMI created on $( date +%F ) for instance ${instancename}" \
    --no-reboot \
    --output=text \
    ${bdm:+--block-device-mappings} "$bdm" \
    $extra_options || \
    f_notify "AMI creation failed for ${instanceid} (${instancename})" "The AMI Creation for ${instanceid} (${instancename}) in region ${regionid} failed"
}

# arg1="resource id to tag" arg2="resource type"
f_tagResource(){
  local customTagName1="c8yManagement"
  local customTagValue1="${CTV1:-${2+AutoRotated${2}}}"
  local customTagName2="c8yInstanceIdOrigin"
  local customTagValue2="${instanceid}"
  aws ec2 create-tags \
    --region "${regionid}" \
    --resource "$1" \
    --tags "Key=${customTagName1},Value=${customTagValue1}" \
           "Key=${customTagName2},Value=${customTagValue2}" \
    $extra_options || \
    f_notify "Tagging $1 $2 failed for ${instanceid} (${instancename})" "Impossible to apply tag on $1 $2 for ${instanceid} (${instancename}) in region ${regionid}"
}

# arg1=devname arg2=volume-id
f_createSnapshot(){
  local devname="$( basename $1 )"
  aws ec2 create-snapshot \
    --region "${regionid}" \
    --volume-id $2 \
    --description "${instancename}-${snapshottimestamp:-$( date +%Y%m%d-%H%M%S )}-${devname}-backup" \
    --output=text \
    $extra_options || \
    f_notify "AMI creation failed for ${instanceid} (${instancename})" "The AMI Creation for ${instanceid} (${instancename}) in region ${regionid} failed"
}

# argX=instance-id
f_listMyAMIs(){
  local customTagName1="c8yManagement"
  local customTagValue1="AutoRotatedAMI"
  local customTagName2="c8yInstanceIdOrigin"
  for customTagValue2 in "${@:-$instanceid}" ; do
    aws ec2 describe-images \
      --region "${regionid}" \
      --filter "Name=is-public,Values=false" \
               "Name=owner-id,Values=$me" \
               "Name=tag:${customTagName1},Values=${customTagValue1}" \
               "Name=tag:${customTagName2},Values=${customTagValue2}" \
      --query 'Images[*].{
                 A:ImageId,
                 B:CreationDate,
                 C:Description,
                 "":BlockDeviceMappings[?Ebs.SnapshotId!=null].{
                   D:Ebs.SnapshotId
                 }
               }' \
      --output=text
  done \
    | sed -r ':a;N;$!ba;s/\n/|/g' | sed -r -e 's/[|]ami/\nami/g' -e 's/[|]//g'
}

# no_args
f_swapCheck(){
  local devblks="$( lsblk -nrfsd )"
  local swapparts="$( fgrep '[SWAP]' <<< "${devblks}" )"

  # exclude logical volumes
  local devchecklist="$( cut -f1 -d' ' <<< "${swapparts}" )"
  for d in ${devchecklist} ; do
    if [[ ! -b "/dev/${d}" ]] ; then
      swapparts="$( fgrep -v ${d} <<< ${swapparts} )"
    fi
  done
  ##########

  local devswaps="$( sed -r 's/^([a-z]+)[0-9]* .*/\1/g' <<< "${swapparts}" )"
  local tmpdev
  
  for d in ${devswaps} ; do
    tmpdev="$( fgrep -v SWAP <<< "$devblks" | fgrep -o $d )"
    devswaps="${devswaps//$tmpdev}"
  done
  
  # aws rename dev
  devswaps="$( sed -r 's@(xvd|sd)@/dev/sd@g' <<< "$devswaps" )"
  echo "$devswaps"
}

# arg1=f=>freeze,u=>unfreeze argX="devices to check for freezing filesystems"
f_fsFrzUnfrz(){
  local par1=$1
  shift
  local parN=$#
  if ! ${skip:-false} && [[ $par1 == "f" || -z $mountpoints ]] ; then
    for (( m = 0 ; m < ${parN} ; m++ )) ; do
      dev="$( f_awsToSysName $1 )"
      [[ -b "$dev" ]] || dev="${dev/\/sd//xvd}"
      mountpoints+="$( [[ -z $1 ]] || lsblk -nio MOUNTPOINT ${dev} | egrep -v '\[SWAP\]|^$' ) "
      shift
    done
    if [[ -z $mountpoints ]] ; then
      skip=true
    else
      mountpoints="$( for mp in ${mountpoints} ; do echo $mp ; done | sort -u ) "
    fi
  fi
  if [[ $par1 == "f" ]] ; then
    sync
    action="Freezing"
  elif [[ $par1 == "u" ]] ; then
    action="Unfreezing"
  fi
  for M in $mountpoints ; do
    f_color_pr grn "  ${action} filesystem '${M}'...$( ${dryrun:-false} && echo " (dryrun => not for real)" )"
    ${dryrun:-false} || fsfreeze -${par1} $M
  done
  if [[ $par1 == "u" ]] ; then
    unset mountpoints
    unset skip
  fi
}

# no_args
f_listAllVolumes_Raw(){
  aws ec2 describe-instances \
    --region ${regionid} \
    --filter "Name=instance-id,Values=${instanceid}" \
    --query 'Reservations[*].Instances[0].{
               "":BlockDeviceMappings[*].{
                 A:DeviceName,
                 B:Ebs.VolumeId
               },
               ROOT:RootDeviceName
             }' \
    --output=text
}

# no_args
f_listAllVolumes(){
  f_listAllVolumes_Raw | sed -n '2,$s/^[ \t]*//gp'
}

# no_args
f_listNonRootVolumes(){
  local l=1
  f_listAllVolumes_Raw \
    | while read line ; do
      if [[ $l -eq 1 ]] ; then
        rootdevice="$line"
        unset l
      else
        fgrep -v "${rootdevice}" <<< "$line"
      fi
    done
}

# arg1="volume id 1" arg2="volume id 2" argX="volume id X"
f_listSnapshots_old(){
  local volumes=$( sed -r -e 's/(^[ ]+)|([ ]+$)//g' -e 's/([^ ])[ ]+([^ ])/\1,\2/g' <<< "$@" )
  aws ec2 describe-snapshots \
    --region ${regionid} \
    --filters "Name=volume-id,Values=${volumes}" \
    --query "Snapshots[*].{
               A:SnapshotId,
               B:VolumeId,
               C:StartTime,
               D:Description
             }" \
    --output=text | fgrep -v CreateImage
}

# arg1="volume id 1" arg2="volume id 2" argX="volume id X"
f_listSnapshots(){
  local volumes=$( sed -r -e 's/(^[ ]+)|([ ]+$)//g' -e 's/([^ ])[ ]+([^ ])/\1,\2/g' <<< "$@" )
  aws ec2 describe-snapshots \
    --region ${regionid} \
    --filters "Name=volume-id,Values=${volumes}" \
    --query 'Snapshots[*].{
               A:SnapshotId,
               B:VolumeId,
               C:StartTime,
               D:Description,
               TAG:Tags[?Key==`c8yManagement`],
               ZZZZZ:[`STOPLINE`]
             }' \
    --output=text | \
  sed -r ':a;N;$!ba;{s/\n/\t/g;s/\tZZZZZ\tSTOPLINE\t?/\n/g}' | \
  sed -r \
    -e '/TAG\tc8yManagement\tPreserve/Id' \
    -e "/u'Value': '[^']*Preserve[^']*', u'Key': 'c8yManagement'/Id" \
    -e '/CreateImage/Id' \
    -e 's/\tTAG\t.+//g' \
    -e '/^[ \t]*$/d'
}

# argX="snapshots to delete"
f_delSnapshots(){
  for S in $* ; do
    aws ec2 delete-snapshot \
      --region "${regionid}" \
      --snapshot-id "$S" \
      --output=text \
      $extra_options \
    && f_color_pr red "  Snapshot ${S} deleted!"
  done
}

# arg1="ami to delete"
f_delAMI(){
  aws ec2 deregister-image \
    --region "${regionid}" \
    --image-id "$1" \
    --output=text \
    $extra_options \
  && f_color_pr red "  AMI $1 deregistered!"
}

# arg1="ISO format date"
f_dateToEpoch(){
  date -d "$( sed -n -r 's/([0-9]{4}(-[0-9]{2}){2})T(([0-9]{2}:){2}[0-9]{2}[.][0-9]{3})Z/\1 \3/gp' <<< "$1" )" +%s
}

f_exec_deleteimage(){
  f_color_pr cyn "Deleting obsolete AMIs:"
  f_color_pr grn "  Getting related images list from current region ..."
  while read -u3 line ; do
    eval $( awk -F'\t' '{print "IMAGEID=\""$1"\"\nDATE=\""$2"\"\nSNAPID=\""substr($0, index($0,$4))"\"\n"}' <<< "$line" )
    creationts=$( f_dateToEpoch "$DATE" )
    if [[ $(( $( TZ=UTC date +%s ) - ${amiretentionsecs} )) -ge ${creationts} ]] ; then
      f_color_pr ylw "  AMI $IMAGEID is older than ${amiretentiondays:-7} days and will be deregistered and associated snapshot $SNAPID deleted"
      confirm="${autoyes:-X}"
      while ! [[ ${confirm,,} =~ ^(y(es)?)|(no?)$ && -z ${autoyes} ]] ; do
        [[ -z $autoyes ]] && read -p 'Confirm? [y/N] : ' 'confirm'
        if [[ ${confirm,,} =~ ^y(es)?$ ]] ; then
          f_delAMI "${IMAGEID}"
          f_delSnapshots "${SNAPID}"
          break
        elif [[ -z ${confirm} || ${confirm,,} =~ ^no?$ ]] ; then
          break
        fi
      done
#    else
#      f_color_pr grn "AMI $IMAGEID is still ok"
    fi
  done 3< <( f_listMyAMIs ${instanceid} ${extrainstanceids} )
}

f_exec_pre(){
  f_color_pr cyn "Calculating mapping OS to aws device naming..."
  f_guessDeviceMapping
  f_color_pr cyn "Managing backups and image creation:"
  if ${backupeverything:-false} ; then
    f_color_pr grn "  Getting list of all volumes..."
    volumestobackup="$( f_listAllVolumes )"
  else
    f_color_pr grn "  Getting list of non root volumes..."
    volumestobackup="$( f_listNonRootVolumes )"
    f_color_pr grn "  Getting list of swap only volumes..."
    pre_volumestoignore="$( f_swapCheck ) $volumestoexclude"
    for v in ${pre_volumestoignore} ; do
      volumestoignore+="$( f_sysToAwsName "$v" ) "
    done
    for v in $volumestoignore ; do
      volumestobackup="$( fgrep -v $v <<< "$volumestobackup" )"
    done
  fi
  i=0
  eval $( awk -F'\t' '{print "DEVID[i]=\""$1"\"\nVOLIDARR[i++]=\""$2" \"\n"}' <<< "$volumestobackup" )
  exec_pre=true
}

f_exec_createimage(){
  if ${exec_pre:-false} ; then
    f_color_pr cyn "Creating AMI:"
    AMIID=$( f_createImage $( ${backupeverything:-false} || echo "${DEVID[@]}" $volumestoignore ) )
    if [[ ! -z ${AMIID} ]] ; then
      f_color_pr grn "  AMI $AMIID Created from current instance"
      f_tagResource "${AMIID}" "AMI" && f_color_pr grn "  TAG Applied for AMI ${AMIID}"
    fi
  else
    f_color_pr red "ERROR: Execute f_exec_pre first!"
  fi
}

f_exec_backupvolumes(){
  if ${exec_pre:-false} ; then
    if [[ -z ${DEVID[@]} ]] ; then
      f_color_pr red "  ERROR: No block device selected for backup"
    else
      f_color_pr cyn "Creating snapshots:"
      f_fsFrzUnfrz f "${DEVID[@]}"
      snapshottimestamp="$( date +%Y%m%d-%H%M%S )"
      for (( d = 0 ; d < i ; d++ )) ; do
        SNAPID=$( f_createSnapshot "${DEVID[d]}" "${VOLIDARR[d]}" | egrep -o 'snap-[0-9a-z]+' )
        if [[ ! -z ${SNAPID} ]] ; then
          f_color_pr grn "  Backup done for volume ${VOLIDARR[d]}with snapshot-id ${SNAPID}"
          ${preservebackup:-false} && CTV1="Preserve"
          f_tagResource "${SNAPID}" "Snapshot" && f_color_pr grn "  TAG Applied for snapshot ${SNAPID}"
          unset CTV1
        fi
        unset SNAPID
        ${dryrun:-false} || sleep 2
      done
      ${dryrun:-false} || sleep 5
      f_fsFrzUnfrz u
    fi
  else
    f_color_pr red "ERROR: Execute f_exec_pre first!"
  fi
}

f_exec_deletesnapshots(){
  if ${exec_pre:-false} ; then
    f_color_pr cyn "Deleting obsolete snapshots:"
    f_color_pr grn "  Getting list of related snapshots..."
    while read -u3 line ; do
      eval $( awk -F'\t' '{print "VOLID=\""$2"\"\nDATE=\""$3"\"\nSNAPID=\""$1"\"\n"}' <<< "$line" )
      creationts=$( f_dateToEpoch "$DATE" )
      if [[ $(( $( TZ=UTC date +%s ) - ${snapshotretentionsecs} )) -ge ${creationts} ]] ; then
        f_color_pr ylw "  Backup snapshot $SNAPID of volume $VOLID is older than ${snapshotretentiondays:-7} days and will be deleted"
        confirm="${autoyes:-X}"
        while ! [[ ${confirm,,} =~ ^(y(es)?)|(no?)$ && -z ${autoyes} ]] ; do
          [[ -z $autoyes ]] && read -p 'Confirm? [y/N] : ' 'confirm'
          if [[ ${confirm,,} =~ ^y(es)?$ ]] ; then
            f_delSnapshots "${SNAPID}"
            break
          elif [[ -z ${confirm} || ${confirm,,} =~ ^no?$ ]] ; then
            break
          fi
        done
      fi
    done 3< <( f_listSnapshots "${VOLIDARR[*]}" "${volumestoincludeinrotation}" )
  else
    f_color_pr red "ERROR: Execute f_exec_pre first!"
  fi
}

if [[ "$0" =~ ^-?bash$ ]] ; then
  f_color_pr ylw "Script executed in current shell:\n  functions loaded in current environment,\n  script execution stopped.\n"
  f_fetchInfo
  f_color_pr cyn '
interactive mode. You can use functions from command line:
  f_fetchInfo
  f_createImage           argX="volumes to exclude"
  f_tagResource           arg1="resource id to tag" arg2="resource type"
  f_fsFrzUnfrz            arg1=f arg2="devices mountpoints dependant"
  f_fsFrzUnfrz            arg1=u
  f_createSnapshot        arg1=devname arg2=volume-id
  f_listMyAMIs            argX=instance id
  f_swapCheck
  f_listAllVolumes
  f_listNonRootVolumes
  f_listSnapshots         argX="volume id X"
  f_delSnapshots          argX="snapshots to delete"
  f_delAMI                arg1="ami to delete"
  f_dateToEpoch           arg1="ISO format date"
  f_notify                arg1="mail subject" arg2="mail body"
  f_textCleaner           arg1="text to clean"
  f_guessDeviceMapping
  f_sysToAwsName          arg1="system block device"
  f_awsToSysName          arg1="aws virtual device"

Procedures:
  f_exec_deleteimage      AMI rotation
  f_exec_pre              use before f_exec_createimage, f_exec_backupvolumes or f_exec_deletesnapshots
  f_exec_createimage      AMI creation
  f_exec_backupvolumes    volume backup creation
  f_exec_deletesnapshots  snapshot rotation
  '
  return
fi

if ! ( ${createimage:-false} || \
       ${deleteimage:-false} || \
       ${backupvolumes:-false} || \
       ${deletesnapshots:-false} ) ; then
  f_color_pr red "ERROR: Options missing!"
  f_helpMsg
  exit 3
fi

f_fetchInfo

${deleteimage:-false} && f_exec_deleteimage

if ( ${backupvolumes:-false} || ${deletesnapshots:-false} || ${createimage:-false} ) ; then
  f_exec_pre
  ${createimage:-false} && f_exec_createimage
  ${backupvolumes:-false} && f_exec_backupvolumes
  ${deletesnapshots:-false} && f_exec_deletesnapshots
fi

f_color_pr cyn "-- Procedure complete --\n\n"

