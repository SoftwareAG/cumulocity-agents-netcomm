name             'cumulocity-backup-script'
maintainer       'Cumulocity GmbH'
maintainer_email 'you@example.com'
license          'All rights reserved'
description      'Installs/Configures cumulocity-backup-script'
long_description 'Installs/Configures cumulocity-backup-script'
version          '1.0.0'

depends           'yum-epel', '>= 0.0.0'
