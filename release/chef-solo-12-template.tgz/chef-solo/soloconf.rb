chef_server_url "https://dev-chef.creatary.com/"
cookbook_path "/var/chef-solo/cookbooks"
data_bag_path "/var/chef-solo/data_bags"
role_path "/var/chef-solo/roles"
environment_path "/var/chef-solo/environments"

run_list(
 "role[cumulocity-dev-singlenode]"
)
