#!/bin/bash

export thisscript="$( readlink -f ${BASH_SOURCE[0]} )"
export    thisdir="$( dirname ${thisscript} )"

(
  cd "$thisdir"
  chef-solo -c soloconf.rb -j runlist.json
)
