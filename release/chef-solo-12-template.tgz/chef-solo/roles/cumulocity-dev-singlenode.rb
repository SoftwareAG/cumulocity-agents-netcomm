require  File.expand_path(File.join(File.dirname(__FILE__), '..', '..', 'config', 'chef_config'))

name "cumulocity-dev-singlenode"
description "Cumulocity Singlenode (Sandbox)"

default_attributes(
  'yum' => {
    'repositories' => {
        'cumulocity' => {
	'url' => "https://cumulocity:ACceP=m+2m@yum.cumulocity.com/centos/$releasever/cumulocity/x86_64/",
	'name' => "cumulocity",
	'description' => "Cumulocity Repository",
	'enabled' => "1",
	'sslverify' => "0"
     }
  }
}
)

override_attributes(
  "environment" => {
     "address" => "server.domain.com"
  },
  "java" => {
     "jdk_version" => "8"
   },
  "domainname" => "domain.com",
    "ulimit" => {
    "root" => {
      "nofile" => {
        "soft" => "10240",
        "hard" => "20480"
      },
      "nproc" => {
        "soft" => "1024",
        "hard" => "2048"
      }
    },
    "karaf" => {
      "nofile" => {
        "soft" => "20240",
        "hard" => "30480"
      },
      "nproc" => {
        "soft" => "3072",
        "hard" => "5000"
      }
    },
    "nginx" => {
      "nofile" => {
        "soft" => "1024",
        "hard" => "8192"
      },
      "nproc" => {
        "soft" => "1024",
        "hard" => "2048"
      }
    }
  },
  "cumulocity-mongo" => {
      "mongodb.initUser" => "init-root",
      "mongodb.initPassword" => "SNinitrootPW"
  },
  "cumulocity-core" => {
    "properties" => {
#      "system.ssl.hostnameVerifier" => "ALLOW_ALL_HOSTNAME_VERIFIER",
      "migration.tomongo.default" => "MONGO_READ_WRITE",
      "dbinit.enabled" => "true",
#      "contextService.rdbmsUser" => "postgres",
#      "contextService.rdbmsPassword" => "postgresql-password",
#      "contextService.rdbmsURL" => "jdbc:postgresql://localhost",
#      "contextService.rdbmsDriver" => "org.postgresql.Driver",
      "contextService.tenantManagementDB" => "management",
      "mongodb.host" => "localhost",
      "mongodb.admindb" => "admin",
      "mongodb.user" => "c8y-root",
      "mongodb.password" => "mongodb-password",
      "management.admin.password" => "b9ffdcca5d8bde8d57562963de3572f2971a840a3c1d40c434738bed731bcb6c",	# admin-pass
      "admin.password" => "b9ffdcca5d8bde8d57562963de3572f2971a840a3c1d40c434738bed731bcb6c",			# admin-pass
      "sysadmin.password" => "ba150527caf1471b21bbe71ce4d95fcdf8597c865ab72523d42b65929f59b3ec",		# sysadmin-pass
      "cumulocity.environment" => "PRODUCTION",
      "auth.checkBlockingFromOutside" => "false",
      "errorMessageRepresentationBuilder.includeDebug" => "false"
    }
  },
  "cumulocity-karaf" => {
    "CUMULOCITY_LICENCE_KEY" => "77e1ed6601df0e7370ec8654fe63875e7b9ea168d14e55093d4ad97bfc79e3a55835c0730380bdc1c0bf39079e3058bcb325f24bbaea877b065ff6b72d4b3e8a",
    "notification" => true,
    "cep-server-enabled" => true,
    "version" => "___KARAFVERSION___", # 			<- put here the version of C8Y KARAF software
    "ssa-version" => "___AGENTSVERSION___", # 			<- put here the version of C8Y SERVER AGENTS
    "memory_left_for_system" => "1536" #	<- how much free RAM memory should left for the OS
  },
  "cumulocity-cep" => {
    "version" => "___CEPVERSION___", # 			<- put here the version of C8Y CEP software
  },
  "cumulocity-ssagents" => {
    "useTags" => false,
    "agent_daemon_list" => ["device-simulator-agent-server","smartrule-agent-server-esper"]
  },
  "cumulocity-external-lb" => {
    "vendon_simulator" => nil,
    "paas_redirection" => true,
    "useIPAddress" => true,
    "temp_chunkin" => false,
    "proxy_cache" => true,
    "usePostgresForPaaS" => false,
    "useMQTTsupport" => true,
    "nginx" => {
        "NGinxPort" => "openresty",
        "version" => "1.11.2.4-20.el7.centos.c8y.8.11.1"
    },
    "certificate_domain" => "domain.com",
    "landing_page" => "https://management.domain.com/apps/devicemanagement",
    "paas_default_page" => "https://$http_host/apps/$defapp"
  }
)

run_list(
  "role[cumulocity-base]",
  "recipe[cumulocity::mongo]",
  "recipe[cumulocity::core]",
  "recipe[cumulocity::core_cep]",
  "recipe[cumulocity::karaf_cep]",
  "recipe[cumulocity::karaf_dev-x-agents]",
  "recipe[cumulocity::external-lb]",
  "recipe[cumulocity-ssagents]"
)

